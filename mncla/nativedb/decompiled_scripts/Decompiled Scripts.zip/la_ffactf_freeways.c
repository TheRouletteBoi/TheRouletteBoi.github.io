﻿void main()
{
   auto var2, var3, var4, var5, var6, var7, var8, var9, var10, var11, var12, var13, var14, var15, var16, var17, var18, var19, var20, var21, var22, var23, var24, var25, var26, var27, var28, var29, var30, var31, var32, var33, var34, var35, var36, var37, var38, var39, var40, var41, var42, var43, var44, var45, var46, var47, var48, var49, var50, var51, var52, var53, var54, var55, var56, var57, var58, var59, var60, var61, var62, var63, var64, var65, var66, var67, var68, var69, var70, var71, var72, var73, var74, var75, var76, var77, var78, var79, var80, var81, var82, var83, var84, var85, var86, var87, var88, var89, var90, var91, var92, var93, var94, var95, var96, var97, var98, var99, var100, var101, var102, var103, var104, var105, var106, var107, var108, var109, var110, var111, var112, var113, var114, var115, var116, var117, var118, var119, var120, var121, var122, var123, var124, var125, var126, var127, var128, var129, var130, var131, var132, var133, var134, var135, var136, var137, var138, var139, var140, var141, var142, var143, var144, var145, var146, var147, var148, var149, var150, var151, var152, var153, var154, var155, var156, var157, var158, var159, var160, var161, var162, var163, var164, var165, var166, var167, var168, var169, var170, var171, var172, var173, var174, var175, var176, var177, var178, var179, var180, var181, var182, var183, var184, var185, var186, var187, var188, var189, var190, var191, var192, var193, var194, var195, var196, var197, var198, var199, var200, var201, var202, var203, var204, var205, var206, var207, var208, var209, var210, var211, var212, var213, var214, var215, var216, var217, var218, var219, var220, var221, var222, var223, var224, var225, var226, var227, var228, var229, var230, var231, var232, var233, var234, var235, var236, var237, var238, var239, var240, var241, var242, var243, var244, var245, var246, var247, var248, var249, var250, var251, var252, var253, var254, var255, var256, var257, var258, var259, var260, var261, var262, var263, var264, var265, var266, var267, var268, var269, var270, var271, var272, var273, var274, var275, var276, var277, var278, var279, var280, var281, var282, var283, var284, var285, var286, var287, var288, var289, var290, var291, var292, var293, var294, var295, var296, var297, var298, var299, var300, var301, var302, var303, var304, var305, var306, var307, var308, var309, var310, var311, var312, var313, var314, var315, var316, var317, var318, var319, var320, var321, var322, var323, var324, var325, var326, var327, var328, var329, var330, var331, var332, var333, var334, var335, var336, var337, var338, var339, var340, var341, var342, var343, var344, var345, var346, var347, var348, var349, var350, var351, var352, var353, var354, var355, var356, var357, var358, var359, var360, var361, var362, var363, var364, var365, var366, var367, var368, var369, var370, var371, var372, var373, var374, var375, var376, var377, var378, var379, var380, var381, var382, var383, var384, var385, var386, var387, var388, var389, var390, var391, var392, var393, var394, var395, var396, var397, var398, var399, var400, var401, var402, var403, var404, var405, var406, var407, var408, var409, var410, var411, var412, var413, var414, var415, var416, var417, var418, var419, var420, var421, var422, var423, var424, var425, var426, var427, var428, var429, var430, var431, var432, var433, var434, var435, var436, var437, var438, var439, var440, var441, var442, var443, var444, var445, var446, var447, var448, var449, var450, var451, var452, var453, var454, var455, var456, var457, var458, var459, var460, var461, var462, var463, var464, var465, var466, var467, var468, var469, var470, var471, var472, var473, var474, var475, var476, var477, var478, var479, var480, var481, var482, var483, var484, var485, var486, var487, var488, var489, var490, var491, var492, var493, var494, var495, var496, var497, var498, var499, var500, var501, var502, var503, var504, var505, var506, var507, var508, var509, var510, var511, var512, var513, var514;

   var2 = 16;
   var2[0 * 3].v0 = -127.737f;
   var2[0 * 3].v1 = 17.8414f;
   var2[0 * 3].v2 = -749.949f;
   var2[1 * 3].v0 = -122.737f;
   var2[1 * 3].v1 = 17.8414f;
   var2[1 * 3].v2 = -750.032f;
   var2[2 * 3].v0 = -132.236f;
   var2[2 * 3].v1 = 17.8414f;
   var2[2 * 3].v2 = -749.874f;
   var2[3 * 3].v0 = -118.238f;
   var2[3 * 3].v1 = 17.8414f;
   var2[3 * 3].v2 = -750.106f;
   var2[4 * 3].v0 = -122.878f;
   var2[4 * 3].v1 = 17.8414f;
   var2[4 * 3].v2 = -758.531f;
   var2[5 * 3].v0 = -132.377f;
   var2[5 * 3].v1 = 17.8414f;
   var2[5 * 3].v2 = -758.373f;
   var2[6 * 3].v0 = -118.379f;
   var2[6 * 3].v1 = 17.8414f;
   var2[6 * 3].v2 = -758.605f;
   var2[7 * 3].v0 = -127.878f;
   var2[7 * 3].v1 = 17.8414f;
   var2[7 * 3].v2 = -758.448f;
   var2[8 * 3].v0 = -123.019f;
   var2[8 * 3].v1 = 17.8414f;
   var2[8 * 3].v2 = -767.029f;
   var2[9 * 3].v0 = -132.518f;
   var2[9 * 3].v1 = 17.8414f;
   var2[9 * 3].v2 = -766.872f;
   var2[10 * 3].v0 = -128.019f;
   var2[10 * 3].v1 = 17.8414f;
   var2[10 * 3].v2 = -766.947f;
   var2[11 * 3].v0 = -118.52f;
   var2[11 * 3].v1 = 17.8414f;
   var2[11 * 3].v2 = -767.104f;
   var2[12 * 3].v0 = -123.16f;
   var2[12 * 3].v1 = 17.8414f;
   var2[12 * 3].v2 = -775.528f;
   var2[13 * 3].v0 = -132.659f;
   var2[13 * 3].v1 = 17.8414f;
   var2[13 * 3].v2 = -775.371f;
   var2[14 * 3].v0 = -118.661f;
   var2[14 * 3].v1 = 17.8414f;
   var2[14 * 3].v2 = -775.603f;
   var2[15 * 3].v0 = -128.16f;
   var2[15 * 3].v1 = 17.8414f;
   var2[15 * 3].v2 = -775.445f;
   var51 = 16;
   var51[0] = -179.049f;
   var51[1] = -179.049f;
   var51[2] = -179.049f;
   var51[3] = -179.049f;
   var51[4] = -179.049f;
   var51[5] = -179.049f;
   var51[6] = -179.049f;
   var51[7] = -179.049f;
   var51[8] = -179.049f;
   var51[9] = -179.049f;
   var51[10] = -179.049f;
   var51[11] = -179.049f;
   var51[12] = -179.049f;
   var51[13] = -179.049f;
   var51[14] = -179.049f;
   var51[15] = -179.049f;
   var68 = 88;
   var68[0 * 3].v0 = -2557.76f;
   var68[0 * 3].v1 = -15.2461f;
   var68[0 * 3].v2 = 639.967f;
   var68[1 * 3].v0 = -2604.76f;
   var68[1 * 3].v1 = -9.22632f;
   var68[1 * 3].v2 = 625.53f;
   var68[2 * 3].v0 = -2462.06f;
   var68[2 * 3].v1 = -6.22392f;
   var68[2 * 3].v2 = 602.209f;
   var68[3 * 3].v0 = -2464.36f;
   var68[3 * 3].v1 = -7.40734f;
   var68[3 * 3].v2 = 721.483f;
   var68[4 * 3].v0 = -2262.98f;
   var68[4 * 3].v1 = -11.266f;
   var68[4 * 3].v2 = 697.621f;
   var68[5 * 3].v0 = -1719.18f;
   var68[5 * 3].v1 = 1.09286f;
   var68[5 * 3].v2 = 722.35f;
   var68[6 * 3].v0 = -1407.25f;
   var68[6 * 3].v1 = -8.45506f;
   var68[6 * 3].v2 = 705.025f;
   var68[7 * 3].v0 = -1408.01f;
   var68[7 * 3].v1 = -10.0201f;
   var68[7 * 3].v2 = 772.478f;
   var68[8 * 3].v0 = -1063.15f;
   var68[8 * 3].v1 = -5.67287f;
   var68[8 * 3].v2 = 691.764f;
   var68[9 * 3].v0 = -849.342f;
   var68[9 * 3].v1 = -11.0597f;
   var68[9 * 3].v2 = 668.422f;
   var68[10 * 3].v0 = -847.756f;
   var68[10 * 3].v1 = -10.1149f;
   var68[10 * 3].v2 = 599.408f;
   var68[11 * 3].v0 = -617.295f;
   var68[11 * 3].v1 = -5.65243f;
   var68[11 * 3].v2 = 627.293f;
   var68[12 * 3].v0 = 33.7062f;
   var68[12 * 3].v1 = -16.325f;
   var68[12 * 3].v2 = 629.494f;
   var68[13 * 3].v0 = 180.972f;
   var68[13 * 3].v1 = -0.149994f;
   var68[13 * 3].v2 = 630.349f;
   var68[14 * 3].v0 = 181.23f;
   var68[14 * 3].v1 = -8.15f;
   var68[14 * 3].v2 = 624.281f;
   var68[15 * 3].v0 = 747.593f;
   var68[15 * 3].v1 = -2.39753f;
   var68[15 * 3].v2 = 627.101f;
   var68[16 * 3].v0 = 403.136f;
   var68[16 * 3].v1 = -15.0516f;
   var68[16 * 3].v2 = 629.777f;
   var68[17 * 3].v0 = 1084.44f;
   var68[17 * 3].v1 = 2.21043f;
   var68[17 * 3].v2 = 811.656f;
   var68[18 * 3].v0 = 1376.39f;
   var68[18 * 3].v1 = 5.59151f;
   var68[18 * 3].v2 = 1084.19f;
   var68[19 * 3].v0 = 1747.94f;
   var68[19 * 3].v1 = -9.99149f;
   var68[19 * 3].v2 = 1122.43f;
   var68[20 * 3].v0 = 1749.19f;
   var68[20 * 3].v1 = -9.99149f;
   var68[20 * 3].v2 = 1044.99f;
   var68[21 * 3].v0 = 2266.28f;
   var68[21 * 3].v1 = -7.71486f;
   var68[21 * 3].v2 = 841.144f;
   var68[22 * 3].v0 = 2225.09f;
   var68[22 * 3].v1 = -2.9827f;
   var68[22 * 3].v2 = 769.656f;
   var68[23 * 3].v0 = 2401.28f;
   var68[23 * 3].v1 = -11.9968f;
   var68[23 * 3].v2 = 620.05f;
   var68[24 * 3].v0 = 2475.13f;
   var68[24 * 3].v1 = -11.9996f;
   var68[24 * 3].v2 = 486.748f;
   var68[25 * 3].v0 = 2396.46f;
   var68[25 * 3].v1 = 6.74598f;
   var68[25 * 3].v2 = 544.268f;
   var68[26 * 3].v0 = 2351.97f;
   var68[26 * 3].v1 = -7.579f;
   var68[26 * 3].v2 = 569.235f;
   var68[27 * 3].v0 = 2395.23f;
   var68[27 * 3].v1 = -7.99794f;
   var68[27 * 3].v2 = 497.739f;
   var68[28 * 3].v0 = 2546.98f;
   var68[28 * 3].v1 = -11.8396f;
   var68[28 * 3].v2 = 359.488f;
   var68[29 * 3].v0 = 2627.49f;
   var68[29 * 3].v1 = -3.41416f;
   var68[29 * 3].v2 = 230.986f;
   var68[30 * 3].v0 = 2553.54f;
   var68[30 * 3].v1 = -2.41448f;
   var68[30 * 3].v2 = 187.831f;
   var68[31 * 3].v0 = 2694.91f;
   var68[31 * 3].v1 = -3.89816f;
   var68[31 * 3].v2 = -35.0108f;
   var68[32 * 3].v0 = 2744.56f;
   var68[32 * 3].v1 = 3.99813f;
   var68[32 * 3].v2 = -293.905f;
   var68[33 * 3].v0 = 2668.67f;
   var68[33 * 3].v1 = 3.99853f;
   var68[33 * 3].v2 = -293.664f;
   var68[34 * 3].v0 = 2702.17f;
   var68[34 * 3].v1 = -3.49214f;
   var68[34 * 3].v2 = -568.869f;
   var68[35 * 3].v0 = 2729.36f;
   var68[35 * 3].v1 = 0.416199f;
   var68[35 * 3].v2 = -987.905f;
   var68[36 * 3].v0 = 2697.3f;
   var68[36 * 3].v1 = -9.08203f;
   var68[36 * 3].v2 = -988.748f;
   var68[37 * 3].v0 = 2456.97f;
   var68[37 * 3].v1 = -3.49995f;
   var68[37 * 3].v2 = -1069.2f;
   var68[38 * 3].v0 = 2214.81f;
   var68[38 * 3].v1 = 3.84984f;
   var68[38 * 3].v2 = -1038.26f;
   var68[39 * 3].v0 = 2215.19f;
   var68[39 * 3].v1 = 3.8466f;
   var68[39 * 3].v2 = -1114.01f;
   var68[40 * 3].v0 = 1922.34f;
   var68[40 * 3].v1 = 6.84935f;
   var68[40 * 3].v2 = -1038.29f;
   var68[41 * 3].v0 = 1923.59f;
   var68[41 * 3].v1 = 6.84278f;
   var68[41 * 3].v2 = -1115.88f;
   var68[42 * 3].v0 = 1693.9f;
   var68[42 * 3].v1 = 3.4967f;
   var68[42 * 3].v2 = -1068.64f;
   var68[43 * 3].v0 = 1506.32f;
   var68[43 * 3].v1 = -3.17955f;
   var68[43 * 3].v2 = -868.416f;
   var68[44 * 3].v0 = 1484.85f;
   var68[44 * 3].v1 = -0.346451f;
   var68[44 * 3].v2 = -744.529f;
   var68[45 * 3].v0 = 1559.7f;
   var68[45 * 3].v1 = 0.263939f;
   var68[45 * 3].v2 = -705.074f;
   var68[46 * 3].v0 = 1532.33f;
   var68[46 * 3].v1 = 7.68838f;
   var68[46 * 3].v2 = -516.474f;
   var68[47 * 3].v0 = 1434.98f;
   var68[47 * 3].v1 = 11.3405f;
   var68[47 * 3].v2 = -589.647f;
   var68[48 * 3].v0 = 1323.92f;
   var68[48 * 3].v1 = 14.9845f;
   var68[48 * 3].v2 = -406.863f;
   var68[49 * 3].v0 = 1423.46f;
   var68[49 * 3].v1 = 10.0368f;
   var68[49 * 3].v2 = -346.477f;
   var68[50 * 3].v0 = 1234.45f;
   var68[50 * 3].v1 = -4.98866f;
   var68[50 * 3].v2 = -216.318f;
   var68[51 * 3].v0 = 1318.94f;
   var68[51 * 3].v1 = -3.51208f;
   var68[51 * 3].v2 = -209.549f;
   var68[52 * 3].v0 = 1147.77f;
   var68[52 * 3].v1 = -8.48342f;
   var68[52 * 3].v2 = -52.2363f;
   var68[53 * 3].v0 = 1228.05f;
   var68[53 * 3].v1 = -7.70863f;
   var68[53 * 3].v2 = -80.9926f;
   var68[54 * 3].v0 = 1176.57f;
   var68[54 * 3].v1 = -0.028748f;
   var68[54 * 3].v2 = 106.756f;
   var68[55 * 3].v0 = 1056.95f;
   var68[55 * 3].v1 = -3.94881f;
   var68[55 * 3].v2 = 107.823f;
   var68[56 * 3].v0 = 1084.59f;
   var68[56 * 3].v1 = -4.03436f;
   var68[56 * 3].v2 = 414.069f;
   var68[57 * 3].v0 = 1236.72f;
   var68[57 * 3].v1 = 16.8392f;
   var68[57 * 3].v2 = -1254.12f;
   var68[58 * 3].v0 = 1112.96f;
   var68[58 * 3].v1 = 28.9111f;
   var68[58 * 3].v2 = -1356.91f;
   var68[59 * 3].v0 = 862.374f;
   var68[59 * 3].v1 = 28.4314f;
   var68[59 * 3].v2 = -1825.12f;
   var68[60 * 3].v0 = 920.672f;
   var68[60 * 3].v1 = 31.9886f;
   var68[60 * 3].v2 = -1494.35f;
   var68[61 * 3].v0 = 971.031f;
   var68[61 * 3].v1 = 29.7513f;
   var68[61 * 3].v2 = -1576.18f;
   var68[62 * 3].v0 = 617.233f;
   var68[62 * 3].v1 = 21.9473f;
   var68[62 * 3].v2 = -2237.59f;
   var68[63 * 3].v0 = 305.249f;
   var68[63 * 3].v1 = 19.9996f;
   var68[63 * 3].v2 = -2225.67f;
   var68[64 * 3].v0 = 304.765f;
   var68[64 * 3].v1 = 19.983f;
   var68[64 * 3].v2 = -2323.59f;
   var68[65 * 3].v0 = 22.9303f;
   var68[65 * 3].v1 = 28.5876f;
   var68[65 * 3].v2 = -2254.36f;
   var68[66 * 3].v0 = -390.401f;
   var68[66 * 3].v1 = 36.7282f;
   var68[66 * 3].v2 = -2041.22f;
   var68[67 * 3].v0 = -595.127f;
   var68[67 * 3].v1 = 35.1588f;
   var68[67 * 3].v2 = -1930.47f;
   var68[68 * 3].v0 = -595.873f;
   var68[68 * 3].v1 = 34.8135f;
   var68[68 * 3].v2 = -2008.49f;
   var68[69 * 3].v0 = -806.311f;
   var68[69 * 3].v1 = 37.3662f;
   var68[69 * 3].v2 = -2036.08f;
   var68[70 * 3].v0 = -1098.66f;
   var68[70 * 3].v1 = 37.7775f;
   var68[70 * 3].v2 = -2202.1f;
   var68[71 * 3].v0 = -1425.63f;
   var68[71 * 3].v1 = 29.9236f;
   var68[71 * 3].v2 = -2183.6f;
   var68[72 * 3].v0 = -1425.63f;
   var68[72 * 3].v1 = 29.9111f;
   var68[72 * 3].v2 = -2277.33f;
   var68[73 * 3].v0 = -1733.86f;
   var68[73 * 3].v1 = 36.6587f;
   var68[73 * 3].v2 = -2201.59f;
   var68[74 * 3].v0 = -1996.88f;
   var68[74 * 3].v1 = 26.9801f;
   var68[74 * 3].v2 = -1953.35f;
   var68[75 * 3].v0 = -1987.99f;
   var68[75 * 3].v1 = 20.9798f;
   var68[75 * 3].v2 = -1712.1f;
   var68[76 * 3].v0 = -2073.94f;
   var68[76 * 3].v1 = 20.9819f;
   var68[76 * 3].v2 = -1712.33f;
   var68[77 * 3].v0 = -2035.96f;
   var68[77 * 3].v1 = 16.3896f;
   var68[77 * 3].v2 = -1501.72f;
   var68[78 * 3].v0 = -2081.97f;
   var68[78 * 3].v1 = 14.637f;
   var68[78 * 3].v2 = -1118.95f;
   var68[79 * 3].v0 = -2018.91f;
   var68[79 * 3].v1 = 11.0713f;
   var68[79 * 3].v2 = -1078.95f;
   var68[80 * 3].v0 = -2111.56f;
   var68[80 * 3].v1 = 10.7039f;
   var68[80 * 3].v2 = -823.822f;
   var68[81 * 3].v0 = -2181.02f;
   var68[81 * 3].v1 = 13.7621f;
   var68[81 * 3].v2 = -571.406f;
   var68[82 * 3].v0 = -2232.15f;
   var68[82 * 3].v1 = -0.209473f;
   var68[82 * 3].v2 = -300.769f;
   var68[83 * 3].v0 = -2162.93f;
   var68[83 * 3].v1 = -0.295044f;
   var68[83 * 3].v2 = -301.728f;
   var68[84 * 3].v0 = -2195.98f;
   var68[84 * 3].v1 = 6.31113f;
   var68[84 * 3].v2 = -51.476f;
   var68[85 * 3].v0 = -2226.19f;
   var68[85 * 3].v1 = -4.14847f;
   var68[85 * 3].v2 = 124.593f;
   var68[86 * 3].v0 = -2159.33f;
   var68[86 * 3].v1 = -4.1514f;
   var68[86 * 3].v2 = 122.288f;
   var68[87 * 3].v0 = -2116.29f;
   var68[87 * 3].v1 = 12.3279f;
   var68[87 * 3].v2 = 373.074f;
   var333 = 88;
   var333[0] = "PickUp_or_DropOff";
   var333[1] = "PickUp_or_DropOff";
   var333[2] = "PickUp_or_DropOff";
   var333[3] = "PickUp_or_DropOff";
   var333[4] = "PickUp_or_DropOff";
   var333[5] = "PickUp_or_DropOff";
   var333[6] = "PickUp_or_DropOff";
   var333[7] = "PickUp_or_DropOff";
   var333[8] = "PickUp_or_DropOff";
   var333[9] = "PickUp_or_DropOff";
   var333[10] = "PickUp_or_DropOff";
   var333[11] = "PickUp_or_DropOff";
   var333[12] = "PickUp_or_DropOff";
   var333[13] = "PickUp_or_DropOff";
   var333[14] = "PickUp_or_DropOff";
   var333[15] = "PickUp_or_DropOff";
   var333[16] = "PickUp_or_DropOff";
   var333[17] = "PickUp_or_DropOff";
   var333[18] = "PickUp_or_DropOff";
   var333[19] = "PickUp_or_DropOff";
   var333[20] = "PickUp_or_DropOff";
   var333[21] = "PickUp_or_DropOff";
   var333[22] = "PickUp_or_DropOff";
   var333[23] = "PickUp_or_DropOff";
   var333[24] = "PickUp_or_DropOff";
   var333[25] = "PickUp_or_DropOff";
   var333[26] = "PickUp_or_DropOff";
   var333[27] = "PickUp_or_DropOff";
   var333[28] = "PickUp_or_DropOff";
   var333[29] = "PickUp_or_DropOff";
   var333[30] = "PickUp_or_DropOff";
   var333[31] = "PickUp_or_DropOff";
   var333[32] = "PickUp_or_DropOff";
   var333[33] = "PickUp_or_DropOff";
   var333[34] = "PickUp_or_DropOff";
   var333[35] = "PickUp_or_DropOff";
   var333[36] = "PickUp_or_DropOff";
   var333[37] = "PickUp_or_DropOff";
   var333[38] = "PickUp_or_DropOff";
   var333[39] = "PickUp_or_DropOff";
   var333[40] = "PickUp_or_DropOff";
   var333[41] = "PickUp_or_DropOff";
   var333[42] = "PickUp_or_DropOff";
   var333[43] = "PickUp_or_DropOff";
   var333[44] = "PickUp_or_DropOff";
   var333[45] = "PickUp_or_DropOff";
   var333[46] = "PickUp_or_DropOff";
   var333[47] = "PickUp_or_DropOff";
   var333[48] = "PickUp_or_DropOff";
   var333[49] = "PickUp_or_DropOff";
   var333[50] = "PickUp_or_DropOff";
   var333[51] = "PickUp_or_DropOff";
   var333[52] = "PickUp_or_DropOff";
   var333[53] = "PickUp_or_DropOff";
   var333[54] = "PickUp_or_DropOff";
   var333[55] = "PickUp_or_DropOff";
   var333[56] = "PickUp_or_DropOff";
   var333[57] = "PickUp_or_DropOff";
   var333[58] = "PickUp_or_DropOff";
   var333[59] = "PickUp_or_DropOff";
   var333[60] = "PickUp_or_DropOff";
   var333[61] = "PickUp_or_DropOff";
   var333[62] = "PickUp_or_DropOff";
   var333[63] = "PickUp_or_DropOff";
   var333[64] = "PickUp_or_DropOff";
   var333[65] = "PickUp_or_DropOff";
   var333[66] = "PickUp_or_DropOff";
   var333[67] = "PickUp_or_DropOff";
   var333[68] = "PickUp_or_DropOff";
   var333[69] = "PickUp_or_DropOff";
   var333[70] = "PickUp_or_DropOff";
   var333[71] = "PickUp_or_DropOff";
   var333[72] = "PickUp_or_DropOff";
   var333[73] = "PickUp_or_DropOff";
   var333[74] = "PickUp_or_DropOff";
   var333[75] = "PickUp_or_DropOff";
   var333[76] = "PickUp_or_DropOff";
   var333[77] = "PickUp_or_DropOff";
   var333[78] = "PickUp_or_DropOff";
   var333[79] = "PickUp_or_DropOff";
   var333[80] = "PickUp_or_DropOff";
   var333[81] = "PickUp_or_DropOff";
   var333[82] = "PickUp_or_DropOff";
   var333[83] = "PickUp_or_DropOff";
   var333[84] = "PickUp_or_DropOff";
   var333[85] = "PickUp_or_DropOff";
   var333[86] = "PickUp_or_DropOff";
   var333[87] = "PickUp_or_DropOff";
   var422 = 88;
   var422[0] = 0;
   var422[1] = 0;
   var422[2] = 0;
   var422[3] = 0;
   var422[4] = 0;
   var422[5] = 0;
   var422[6] = 0;
   var422[7] = 0;
   var422[8] = 0;
   var422[9] = 0;
   var422[10] = 0;
   var422[11] = 0;
   var422[12] = 0;
   var422[13] = 0;
   var422[14] = 0;
   var422[15] = 0;
   var422[16] = 0;
   var422[17] = 0;
   var422[18] = 0;
   var422[19] = 0;
   var422[20] = 0;
   var422[21] = 0;
   var422[22] = 0;
   var422[23] = 0;
   var422[24] = 0;
   var422[25] = 0;
   var422[26] = 0;
   var422[27] = 0;
   var422[28] = 0;
   var422[29] = 0;
   var422[30] = 0;
   var422[31] = 0;
   var422[32] = 0;
   var422[33] = 0;
   var422[34] = 0;
   var422[35] = 0;
   var422[36] = 0;
   var422[37] = 0;
   var422[38] = 0;
   var422[39] = 0;
   var422[40] = 0;
   var422[41] = 0;
   var422[42] = 0;
   var422[43] = 0;
   var422[44] = 0;
   var422[45] = 0;
   var422[46] = 0;
   var422[47] = 0;
   var422[48] = 0;
   var422[49] = 0;
   var422[50] = 0;
   var422[51] = 0;
   var422[52] = 0;
   var422[53] = 0;
   var422[54] = 0;
   var422[55] = 0;
   var422[56] = 0;
   var422[57] = 0;
   var422[58] = 0;
   var422[59] = 0;
   var422[60] = 0;
   var422[61] = 0;
   var422[62] = 0;
   var422[63] = 0;
   var422[64] = 0;
   var422[65] = 0;
   var422[66] = 0;
   var422[67] = 0;
   var422[68] = 0;
   var422[69] = 0;
   var422[70] = 0;
   var422[71] = 0;
   var422[72] = 0;
   var422[73] = 0;
   var422[74] = 0;
   var422[75] = 0;
   var422[76] = 0;
   var422[77] = 0;
   var422[78] = 0;
   var422[79] = 0;
   var422[80] = 0;
   var422[81] = 0;
   var422[82] = 0;
   var422[83] = 0;
   var422[84] = 0;
   var422[85] = 0;
   var422[86] = 0;
   var422[87] = 0;
   var511 = 0;
   var512 = Ctf_GetMap(L[0].v801);
   CtfMap_Init(var512, 88, 88);
   var511 = 0;
   while (var511 < 88)
   {
       CtfMap_AddItem(var512, var333[var511], &(var68[var511 * 3]), var422[var511]);
       var511 = var511 + 1;
   }
   var513 = 0;
   var514 = Race_GetRaceGrid(L[0].v3, 0);
   var513 = 0;
   while (var513 < 16)
   {
       RaceGrid_SetPosition(var514, var513, &(var2[var513 * 3]), var51[var513]);
       var513 = var513 + 1;
   }
   sub_1a29(&L[0]);
}

void sub_1a29(var0)
{
   auto var3, var4, var5, var6, var7, var8, var9, var10, var11, var12, var13, var14, var15, var16;

   var8.v0 = (float)0;
   var8.v1 = (float)1;
   var8.v2 = (float)0;
   var11.v0 = (float)0;
   var11.v1 = (float)0;
   var11.v2 = (float)-1;
   RaceGrid_GetPosition(Race_GetRaceGrid(*(var0 + 12), 0), 0, &var4, &var7);
   Math_VecRotateY(&var11, &var11, var7);
   var11.v0 = var4.v0 + var11.v0;
   var11.v1 = var4.v1 + var11.v1;
   var11.v2 = var4.v2 + var11.v2;
   var8.v0 = var4.v0 + var8.v0;
   var8.v1 = var4.v1 + var8.v1;
   var8.v2 = var4.v2 + var8.v2;
   UILogic_LockStreaming(&var4, &var8, &var11);
   var3 = 0;
   while (var3 < *((var0 + 16) + 3080))
   {
       Racer_SetStreamingLockedIn((*((var0 + 16) + 4))[var3 * 48].v0);
       var3 = var3 + 1;
   }
   var14 = 1;
   while (var14 > 0)
   {
       var14 = *((var0 + 16) + 3080);
       var3 = 0;
       while (var3 < *((var0 + 16) + 3080))
       {
           if (Racer_IsSimStreamed((*((var0 + 16) + 4))[var3 * 48].v0))
           {
               var14 = var14 - 1;
           }
           var3 = var3 + 1;
       }
       if (var14 > 0)
       {
           if (!*((var0 + 16) + 3132))
           {
               sub_1b40(1, 0, 0x3f800000, 0);
           }
           WAIT(100);
       }
   }
   while (OpponentManager_StillStreamingOut())
   {
       WAIT(30);
   }
   var3 = 0;
   while (var3 < *((var0 + 16) + 3080))
   {
       if ((*((var0 + 16) + 4))[var3 * 48].v2 == 2)
       {
           PRINTSTRING(" BRAIN CREATED!");
           (*((var0 + 16) + 4))[var3 * 48].v3 = BrainFactory_CreateBrainRacing((*((var0 + 16) + 4))[var3 * 48].v0);
       }
       var3 = var3 + 1;
   }
   var15 = START_NEW_SCRIPT_WITH_ARGS("game/racetypes/BaseWarCore", var0, 802, 1500);
   while (!IsChildFinished(var15))
   {
       WAIT(30);
   }
   var3 = 0;
   while (var3 < *((var0 + 16) + 3080))
   {
       if ((*((var0 + 16) + 4))[var3 * 48].v2 == 2)
       {
           BrainFactory_DeleteBrain((*((var0 + 16) + 4))[var3 * 48].v0);
       }
       var3 = var3 + 1;
   }
}

void sub_1b40(var0, var1, var2, var3)
{
   auto var6, var7, var8, var9, var10, var11, var12, var13;

   var6 = null;
   while (var6 == null)
   {
       var6 = UIManager_FindMovie("TRANSITIONMOVIE");
       if (var6 == null)
       {
           PRINTSTRING("SCRIPT: waiting for transition movie to stream in...\n");
           WAITUNWARPED(10);
       }
   }
   var7 = 0;
   var8 = 0;
   var9 = 0;
   FlashHelper_GetGlobalInt(var6, "StartOfTransitionout", &var7);
   FlashHelper_GetGlobalInt(var6, "StartOfTransitionin", &var8);
   FlashHelper_GetGlobalInt(var6, "TransitionOutisReady", &var9);
   PRINTSTRING("FADE DOWN REPORT\n");
   PRINTSTRING("================\n");
   PRINTSTRING("TransitionOut: ");
   PRINTINT(var7);
   PRINTSTRING("\nTransitionIn: ");
   PRINTINT(var8);
   PRINTSTRING("\nnTransitionReady: ");
   PRINTINT(var9);
   PRINTSTRING("\n");
   if ((var8 == 0) && ((var9 == 0) || ((var7 == 1) && (var9 == 2))))
   {
       FlashHelper_SetMovieEnabled(var6, 1);
       FlashHelper_SetGlobalInt(var6, "cur_visibility", 1);
       FlashHelper_SetGlobalInt(var6, "mask_color", var3);
       if (var1)
       {
           FlashHelper_SetGlobalInt(var6, "transition_type", 0);
       }
       else
       {
           FlashHelper_SetGlobalInt(var6, "transition_type", 1);
       }
       FlashHelper_SetGlobalFloat(var6, "fade_speed_in", var2);
       FlashHelper_SetGlobalFloat(var6, "fade_speed_out", 0.01f);
       FlashHelper_SetGlobalInt(var6, "StartOfTransitionout", 0);
       FlashHelper_SetGlobalInt(var6, "TransitionOutisReady", 0);
       FlashHelper_SetGlobalInt(var6, "StartOfTransitionin", 1);
       if (var0)
       {
           var8 = 1;
           while (var8 == 1)
           {
               FlashHelper_GetGlobalInt(var6, "StartOfTransitionin", &var8);
               if (var8 == 1)
               {
                   WAITUNWARPED(10);
               }
           }
       }
   }
}

