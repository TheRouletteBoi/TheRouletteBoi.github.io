void main()
{
    string[16] sVar2;
    vector[16] vVar19;
    unknown uVar36;
    unknown uVar37;
    unknown uVar38;
    unknown uVar39;
    unknown uVar40;
    unknown uVar41;
    unknown uVar42;
    unknown uVar43;
    unknown uVar44;
    unknown uVar45;
    unknown uVar46;
    unknown uVar47;
    unknown uVar48;
    unknown uVar49;
    unknown uVar50;
    unknown uVar51;
    unknown uVar52;
    unknown uVar53;
    unknown uVar54;
    unknown uVar55;
    unknown uVar56;
    unknown uVar57;
    unknown uVar58;
    unknown uVar59;
    unknown uVar60;
    unknown uVar61;
    unknown uVar62;
    unknown uVar63;
    unknown uVar64;
    unknown uVar65;
    unknown uVar66;
    unknown uVar67;
    float[16] fVar68;
    unknown[16] uVar85;
    unknown[16] uVar102;
    unknown[16] uVar119;
    unknown uVar136;
    int I;
    vector vVar138;
    vector vVar141;

    l_U0 = "drv_mp_01_set";
    l_U1 = "drv_mp_01_lod02_set";
    l_U2 = "drv_ma_03_set";
    l_U3 = "drv_ma_02_set";
    l_U4 = "drv_ma_001_set";
    l_U5 = "drv_fa_001_set";
    l_U6 = "drv_mb_02_set";
    l_U7 = "drv_mb_03_set";
    l_U8 = "drv_mb_04_set";
    l_U9 = "drv_mb_05_set";
    l_U10 = "drv_mb_007_set";
    l_U11 = "drv_mb_008_set";
    l_U12 = "drv_mb_010_set";
    l_U13 = "drv_mb_001_set";
    l_U14 = "drv_mb_009_set";
    l_U15 = "drv_mb_06_set";
    l_U16 = "drv_fb_01_set";
    l_U17 = "drv_mc_02_set";
    l_U18 = "drv_mc_06_set";
    l_U19 = "drv_mc_07_set";
    l_U20 = "drv_mc_003_set";
    l_U21 = "drv_mc_05_set";
    l_U22 = "drv_mc_001_set";
    l_U23 = "drv_fc_002_set";
    l_U24 = "drv_mh_01_set";
    l_U25 = "drv_mh_02_set";
    l_U26 = "drv_mh_003_set";
    l_U27 = "drv_mh_005_set";
    l_U28 = "drv_mh_04_set";
    l_U29 = "drv_mh_006_set";
    l_U30 = "drv_fh_001_set";
    l_U31 = "mec_mc_01_set";
    l_U32 = "ped_ma_001_set";
    l_U33 = "ped_mb_001_set";
    l_U34 = "ped_mc_001_set";
    l_U35 = "ped_mh_001_set";
    l_U36 = "pol_mc_01_set";
    Graphics_WarpToTimeOfDay( 1.00000000, 50.00000000 );
    array(ref sVar2, 16);
    sVar2[0] = "vp_kaw_ninja_zx14_06";
    sVar2[1] = "vp_kaw_ninja_zx14_06";
    sVar2[2] = "vp_kaw_ninja_zx14_06";
    sVar2[3] = "vp_kaw_ninja_zx14_06";
    sVar2[4] = "vp_kaw_ninja_zx14_06";
    sVar2[5] = "vp_kaw_ninja_zx14_06";
    sVar2[6] = "vp_kaw_ninja_zx14_06";
    sVar2[7] = "vp_kaw_ninja_zx14_06";
    sVar2[8] = "vp_duc_monster_s4r_07";
    sVar2[9] = "vp_duc_monster_s4r_07";
    sVar2[10] = "vp_duc_monster_s4r_07";
    sVar2[11] = "vp_duc_monster_s4r_07";
    sVar2[12] = "vp_duc_monster_s4r_07";
    sVar2[13] = "vp_duc_monster_s4r_07";
    sVar2[14] = "vp_duc_monster_s4r_07";
    sVar2[15] = "vp_duc_monster_s4r_07";
    array(ref vVar19, 16);
    vVar19[0] = {-193.70000000, 18.70000000, -758.80000000};
    vVar19[1] = {-178.00000000, 18.27000000, -759.20000000};
    vVar19[2] = {-188.90000000, 18.60000000, -764.80000000};
    vVar19[3] = {-183.14000000, 18.29000000, -755.85000000};
    vVar19[4] = {-172.70000000, 20.00000000, -762.80000000};
    vVar19[5] = {-174.70000000, 20.00000000, -762.80000000};
    vVar19[6] = {-176.70000000, 20.00000000, -762.80000000};
    vVar19[7] = {-178.70000000, 20.00000000, -762.80000000};
    vVar19[8] = {-172.70000000, 20.00000000, -760.80000000};
    vVar19[9] = {-174.70000000, 20.00000000, -760.80000000};
    vVar19[10] = {-176.70000000, 20.00000000, -760.80000000};
    vVar19[11] = {-178.70000000, 20.00000000, -760.80000000};
    vVar19[12] = {-172.70000000, 20.00000000, -758.80000000};
    vVar19[13] = {-174.70000000, 20.00000000, -758.80000000};
    vVar19[14] = {-176.70000000, 20.00000000, -758.80000000};
    vVar19[15] = {-178.70000000, 20.00000000, -758.80000000};
    array(ref fVar68, 16);
    fVar68[0] = 284.00000000;
    fVar68[1] = 209.13000000;
    fVar68[2] = 284.00000000;
    fVar68[3] = 210.00000000;
    fVar68[4] = 284.00000000;
    fVar68[5] = 284.00000000;
    fVar68[6] = 284.00000000;
    fVar68[7] = 284.00000000;
    fVar68[8] = 284.00000000;
    fVar68[9] = 284.00000000;
    fVar68[10] = 284.00000000;
    fVar68[11] = 284.00000000;
    fVar68[12] = 284.00000000;
    fVar68[13] = 284.00000000;
    fVar68[14] = 284.00000000;
    fVar68[15] = 284.00000000;
    array(ref uVar85, 16);
    array(ref uVar102, 16);
    array(ref uVar119, 16);
    for ( I = 0; I < 16; I++ )
    {
        if (I > 0)
        {
            uVar119[I] = mcCarConfig_Create( sVar2[I] );
            LayerPlayer_LoadRemotePlayer( I, uVar119[I], ref vVar19[I], fVar68[I], -1, 1 );
        }
        uVar85[I] = Player_FindObject( I );
        uVar102[I] = Player_GetRacer( uVar85[I] );
        Racer_InitializeResetPosition( uVar102[I], ref vVar19[I], fVar68[I] );
        if (I == 0)
        {
            ;
        }
        else
        {
            Racer_SetUIDAndCharacterName( uVar102[I], 50 + I, l_U0 );
        }
        Racer_Reset( uVar102[I] );
    }
    vVar138 = {65363, 21.90000000, -738.20000000};
    vVar141 = {-183.14000000, 18.29000000, -755.85000000};
    sub_2184( 1, 1, 1065353216, 0 );
    Game_SetCamera( ref vVar138, ref vVar141, 25.00000000, 0, 0, 0 );
    WAIT( 30000 );
    return;
}

void sub_2184(boolean bParam0, boolean bParam1, unknown uParam2, unknown uParam3)
{
    int iVar6;
    int iVar7;
    int iVar8;
    int iVar9;

    iVar6 = nil;
    while (iVar6 == nil)
    {
        iVar6 = UIManager_FindMovie( "TRANSITIONMOVIE" );
        if (iVar6 == nil)
        {
            WAITUNWARPED( 10 );
        }
    }
    iVar7 = 0;
    iVar8 = 0;
    iVar9 = 0;
    FlashHelper_GetGlobalInt( iVar6, "StartOfTransitionout", ref iVar7 );
    FlashHelper_GetGlobalInt( iVar6, "StartOfTransitionin", ref iVar8 );
    FlashHelper_GetGlobalInt( iVar6, "TransitionOutisReady", ref iVar9 );
    PRINTSTRING( "FADE UP REPORT\n" );
    PRINTSTRING( "==============\n" );
    PRINTSTRING( "TransitionOut: " );
    PRINTINT( iVar7 );
    PRINTSTRING( "\nTransitionIn: " );
    PRINTINT( iVar8 );
    PRINTSTRING( "\nnTransitionReady: " );
    PRINTINT( iVar9 );
    PRINTSTRING( "\n" );
    if ((iVar7 == 0) AND ((iVar8 != 0) || (iVar9 != 0)))
    {
        FlashHelper_SetMovieEnabled( iVar6, 1 );
        FlashHelper_SetGlobalInt( iVar6, "cur_visibility", 1 );
        FlashHelper_SetGlobalInt( iVar6, "mask_color", uParam3 );
        if (bParam1)
        {
            FlashHelper_SetGlobalInt( iVar6, "transition_type", 0 );
        }
        else
        {
            FlashHelper_SetGlobalInt( iVar6, "transition_type", 1 );
        }
        FlashHelper_SetGlobalFloat( iVar6, "fade_speed_in", 0.01000000 );
        FlashHelper_SetGlobalFloat( iVar6, "fade_speed_out", uParam2 );
        FlashHelper_SetGlobalInt( iVar6, "StartOfTransitionin", 0 );
        FlashHelper_SetGlobalInt( iVar6, "TransitionOutisReady", 2 );
        FlashHelper_SetGlobalInt( iVar6, "StartOfTransitionout", 1 );
        if (bParam0)
        {
            iVar7 = 1;
            while (iVar7 == 1)
            {
                FlashHelper_GetGlobalInt( iVar6, "StartOfTransitionout", ref iVar7 );
                if (iVar7 == 1)
                {
                    PRINTSTRING( "SCRIPT: waiting for transition movie transition up...\n" );
                    WAITUNWARPED( 10 );
                }
            }
        }
    }
    return;
}
