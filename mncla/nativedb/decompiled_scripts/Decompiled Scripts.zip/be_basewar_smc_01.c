﻿void main()
{
   auto var2, var3, var4, var5, var6, var7, var8, var9, var10, var11, var12, var13, var14, var15, var16, var17, var18, var19, var20, var21, var22, var23, var24, var25, var26, var27, var28, var29, var30, var31, var32, var33, var34, var35, var36, var37, var38, var39, var40, var41, var42, var43, var44, var45, var46, var47, var48, var49, var50, var51, var52, var53, var54, var55, var56, var57, var58, var59, var60, var61, var62, var63, var64, var65, var66, var67, var68, var69, var70, var71, var72, var73, var74, var75, var76, var77, var78, var79, var80, var81, var82, var83, var84, var85, var86, var87, var88, var89, var90, var91, var92, var93, var94, var95, var96, var97, var98, var99, var100, var101, var102, var103, var104, var105, var106, var107, var108, var109, var110, var111, var112, var113, var114, var115, var116, var117, var118, var119, var120, var121, var122, var123, var124, var125, var126, var127, var128, var129, var130, var131, var132, var133, var134, var135, var136, var137, var138, var139, var140, var141, var142, var143, var144, var145, var146, var147, var148, var149, var150, var151, var152, var153, var154, var155, var156, var157, var158, var159, var160, var161, var162, var163, var164, var165, var166, var167, var168, var169, var170, var171, var172, var173, var174, var175, var176, var177, var178, var179, var180, var181, var182, var183, var184, var185, var186, var187, var188, var189, var190, var191, var192;

   var2 = 4;
   var2[0] = (float)12;
   var2[1] = 13.5f;
   var2[2] = (float)14;
   var2[3] = (float)14;
   var7 = 4;
   var7[0 * 3].v0 = -2182.9f;
   var7[0 * 3].v1 = -0.103638f;
   var7[0 * 3].v2 = -110.71f;
   var7[1 * 3].v0 = -2619.68f;
   var7[1 * 3].v1 = -4.80694f;
   var7[1 * 3].v2 = 20.9805f;
   var7[2 * 3].v0 = -2617.07f;
   var7[2 * 3].v1 = -4.6067f;
   var7[2 * 3].v2 = -186.596f;
   var7[3 * 3].v0 = -2916.47f;
   var7[3 * 3].v1 = -4.78804f;
   var7[3 * 3].v2 = -74.948f;
   var20 = 4;
   var20[0 * 3].v0 = -2182.41f;
   var20[0 * 3].v1 = -0.103638f;
   var20[0 * 3].v2 = -127.979f;
   var20[1 * 3].v0 = -2639.66f;
   var20[1 * 3].v1 = -4.69404f;
   var20[1 * 3].v2 = 2.8981f;
   var20[2 * 3].v0 = -2638.32f;
   var20[2 * 3].v1 = -4.59721f;
   var20[2 * 3].v2 = -165.975f;
   var20[3 * 3].v0 = -2916.47f;
   var20[3 * 3].v1 = -4.78804f;
   var20[3 * 3].v2 = -99.3266f;
   var33 = 16;
   var33[0 * 3].v0 = -2620.61f;
   var33[0 * 3].v1 = 0.195f;
   var33[0 * 3].v2 = -379.593f;
   var33[1 * 3].v0 = -2615.62f;
   var33[1 * 3].v1 = 0.195f;
   var33[1 * 3].v2 = -379.635f;
   var33[2 * 3].v0 = -2625.11f;
   var33[2 * 3].v1 = 0.195f;
   var33[2 * 3].v2 = -379.556f;
   var33[3 * 3].v0 = -2611.12f;
   var33[3 * 3].v1 = 0.195f;
   var33[3 * 3].v2 = -379.673f;
   var33[4 * 3].v0 = -2615.69f;
   var33[4 * 3].v1 = 0.195f;
   var33[4 * 3].v2 = -388.135f;
   var33[5 * 3].v0 = -2625.19f;
   var33[5 * 3].v1 = 0.195f;
   var33[5 * 3].v2 = -388.055f;
   var33[6 * 3].v0 = -2611.19f;
   var33[6 * 3].v1 = 0.195f;
   var33[6 * 3].v2 = -388.173f;
   var33[7 * 3].v0 = -2620.69f;
   var33[7 * 3].v1 = 0.195f;
   var33[7 * 3].v2 = -388.093f;
   var33[8 * 3].v0 = -2615.76f;
   var33[8 * 3].v1 = 0.195f;
   var33[8 * 3].v2 = -396.635f;
   var33[9 * 3].v0 = -2625.26f;
   var33[9 * 3].v1 = 0.195f;
   var33[9 * 3].v2 = -396.555f;
   var33[10 * 3].v0 = -2620.76f;
   var33[10 * 3].v1 = 0.195f;
   var33[10 * 3].v2 = -396.593f;
   var33[11 * 3].v0 = -2611.26f;
   var33[11 * 3].v1 = 0.195f;
   var33[11 * 3].v2 = -396.673f;
   var33[12 * 3].v0 = -2615.83f;
   var33[12 * 3].v1 = 0.195f;
   var33[12 * 3].v2 = -405.134f;
   var33[13 * 3].v0 = -2625.33f;
   var33[13 * 3].v1 = 0.195f;
   var33[13 * 3].v2 = -405.055f;
   var33[14 * 3].v0 = -2611.33f;
   var33[14 * 3].v1 = 0.195f;
   var33[14 * 3].v2 = -405.172f;
   var33[15 * 3].v0 = -2620.83f;
   var33[15 * 3].v1 = 0.195f;
   var33[15 * 3].v2 = -405.092f;
   var82 = 16;
   var82[0] = -179.518f;
   var82[1] = -179.518f;
   var82[2] = -179.518f;
   var82[3] = -179.518f;
   var82[4] = -179.518f;
   var82[5] = -179.518f;
   var82[6] = -179.518f;
   var82[7] = -179.518f;
   var82[8] = -179.518f;
   var82[9] = -179.518f;
   var82[10] = -179.518f;
   var82[11] = -179.518f;
   var82[12] = -179.518f;
   var82[13] = -179.518f;
   var82[14] = -179.518f;
   var82[15] = -179.518f;
   var99 = 16;
   var99[0 * 3].v0 = -2615.26f;
   var99[0 * 3].v1 = -9.79774f;
   var99[0 * 3].v2 = 209.831f;
   var99[1 * 3].v0 = -2620.26f;
   var99[1 * 3].v1 = -9.79774f;
   var99[1 * 3].v2 = 209.831f;
   var99[2 * 3].v0 = -2610.76f;
   var99[2 * 3].v1 = -9.79774f;
   var99[2 * 3].v2 = 209.831f;
   var99[3 * 3].v0 = -2624.76f;
   var99[3 * 3].v1 = -9.79774f;
   var99[3 * 3].v2 = 209.831f;
   var99[4 * 3].v0 = -2620.26f;
   var99[4 * 3].v1 = -9.79774f;
   var99[4 * 3].v2 = 218.331f;
   var99[5 * 3].v0 = -2610.76f;
   var99[5 * 3].v1 = -9.79774f;
   var99[5 * 3].v2 = 218.331f;
   var99[6 * 3].v0 = -2624.76f;
   var99[6 * 3].v1 = -9.79774f;
   var99[6 * 3].v2 = 218.331f;
   var99[7 * 3].v0 = -2615.26f;
   var99[7 * 3].v1 = -9.79774f;
   var99[7 * 3].v2 = 218.331f;
   var99[8 * 3].v0 = -2620.26f;
   var99[8 * 3].v1 = -9.79774f;
   var99[8 * 3].v2 = 226.831f;
   var99[9 * 3].v0 = -2610.76f;
   var99[9 * 3].v1 = -9.79774f;
   var99[9 * 3].v2 = 226.831f;
   var99[10 * 3].v0 = -2615.26f;
   var99[10 * 3].v1 = -9.79774f;
   var99[10 * 3].v2 = 226.831f;
   var99[11 * 3].v0 = -2624.76f;
   var99[11 * 3].v1 = -9.79774f;
   var99[11 * 3].v2 = 226.831f;
   var99[12 * 3].v0 = -2620.26f;
   var99[12 * 3].v1 = -9.79774f;
   var99[12 * 3].v2 = 235.331f;
   var99[13 * 3].v0 = -2610.76f;
   var99[13 * 3].v1 = -9.79774f;
   var99[13 * 3].v2 = 235.331f;
   var99[14 * 3].v0 = -2624.76f;
   var99[14 * 3].v1 = -9.79774f;
   var99[14 * 3].v2 = 235.331f;
   var99[15 * 3].v0 = -2615.26f;
   var99[15 * 3].v1 = -9.79774f;
   var99[15 * 3].v2 = 235.331f;
   var148 = 16;
   var148[0] = (float)0;
   var148[1] = (float)0;
   var148[2] = (float)0;
   var148[3] = (float)0;
   var148[4] = (float)0;
   var148[5] = (float)0;
   var148[6] = (float)0;
   var148[7] = (float)0;
   var148[8] = (float)0;
   var148[9] = (float)0;
   var148[10] = (float)0;
   var148[11] = (float)0;
   var148[12] = (float)0;
   var148[13] = (float)0;
   var148[14] = (float)0;
   var148[15] = (float)0;
   var165 = 4;
   var165[0 * 3].v0 = -2462.27f;
   var165[0 * 3].v1 = 0.194183f;
   var165[0 * 3].v2 = -358.794f;
   var165[1 * 3].v0 = -2462.27f;
   var165[1 * 3].v1 = 0.194183f;
   var165[1 * 3].v2 = -358.794f;
   var165[2 * 3].v0 = -2461.85f;
   var165[2 * 3].v1 = -9.8061f;
   var165[2 * 3].v2 = 215.632f;
   var165[3 * 3].v0 = -2461.85f;
   var165[3 * 3].v1 = -9.8061f;
   var165[3 * 3].v2 = 215.632f;
   var178 = 4;
   var178[0] = "PickUp";
   var178[1] = "DropOff";
   var178[2] = "PickUp";
   var178[3] = "DropOff";
   var183 = 4;
   var183[0] = 2;
   var183[1] = 2;
   var183[2] = 1;
   var183[3] = 1;
   var188 = 0;
   var189 = Ctf_GetMap(L[0].v801);
   CtfMap_Init(var189, 2, 2);
   var188 = 0;
   while (var188 < 4)
   {
       CtfMap_AddItem(var189, var178[var188], &(var165[var188 * 3]), var183[var188]);
       var188 = var188 + 1;
   }
   var190 = 0;
   var191 = Race_GetRaceGrid(L[0].v3, 0);
   var192 = Race_GetRaceGrid(L[0].v3, 1);
   var190 = 0;
   while (var190 < 16)
   {
       RaceGrid_SetPosition(var191, var190, &(var33[var190 * 3]), var82[var190]);
       RaceGrid_SetPosition(var192, var190, &(var99[var190 * 3]), var148[var190]);
       var190 = var190 + 1;
   }
   L[0].v2 = PickUpManager_CreatePowerUpSources(4);
   var188 = 0;
   while (var188 < 4)
   {
       PickUpManager_AddPowerUpSource(L[0].v2, &(var7[var188 * 3]), var2[var188], &(var20[var188 * 3]));
       var188 = var188 + 1;
   }
   sub_828(&L[0]);
}

void sub_828(var0)
{
   auto var3, var4, var5, var6, var7, var8, var9, var10, var11, var12, var13, var14, var15, var16;

   var8.v0 = (float)0;
   var8.v1 = (float)1;
   var8.v2 = (float)0;
   var11.v0 = (float)0;
   var11.v1 = (float)0;
   var11.v2 = (float)-1;
   RaceGrid_GetPosition(Race_GetRaceGrid(*(var0 + 12), 0), 0, &var4, &var7);
   Math_VecRotateY(&var11, &var11, var7);
   var11.v0 = var4.v0 + var11.v0;
   var11.v1 = var4.v1 + var11.v1;
   var11.v2 = var4.v2 + var11.v2;
   var8.v0 = var4.v0 + var8.v0;
   var8.v1 = var4.v1 + var8.v1;
   var8.v2 = var4.v2 + var8.v2;
   UILogic_LockStreaming(&var4, &var8, &var11);
   var3 = 0;
   while (var3 < *((var0 + 16) + 3080))
   {
       Racer_SetStreamingLockedIn((*((var0 + 16) + 4))[var3 * 48].v0);
       var3 = var3 + 1;
   }
   var14 = 1;
   while (var14 > 0)
   {
       var14 = *((var0 + 16) + 3080);
       var3 = 0;
       while (var3 < *((var0 + 16) + 3080))
       {
           if (Racer_IsSimStreamed((*((var0 + 16) + 4))[var3 * 48].v0))
           {
               var14 = var14 - 1;
           }
           var3 = var3 + 1;
       }
       if (var14 > 0)
       {
           if (!*((var0 + 16) + 3132))
           {
               sub_93f(1, 0, 0x3f800000, 0);
           }
           WAIT(100);
       }
   }
   while (OpponentManager_StillStreamingOut())
   {
       WAIT(30);
   }
   var3 = 0;
   while (var3 < *((var0 + 16) + 3080))
   {
       if ((*((var0 + 16) + 4))[var3 * 48].v2 == 2)
       {
           PRINTSTRING(" BRAIN CREATED!");
           (*((var0 + 16) + 4))[var3 * 48].v3 = BrainFactory_CreateBrainRacing((*((var0 + 16) + 4))[var3 * 48].v0);
       }
       var3 = var3 + 1;
   }
   var15 = START_NEW_SCRIPT_WITH_ARGS("game/racetypes/BaseWarCore", var0, 802, 1500);
   while (!IsChildFinished(var15))
   {
       WAIT(30);
   }
   var3 = 0;
   while (var3 < *((var0 + 16) + 3080))
   {
       if ((*((var0 + 16) + 4))[var3 * 48].v2 == 2)
       {
           BrainFactory_DeleteBrain((*((var0 + 16) + 4))[var3 * 48].v0);
       }
       var3 = var3 + 1;
   }
}

void sub_93f(var0, var1, var2, var3)
{
   auto var6, var7, var8, var9, var10, var11, var12, var13;

   var6 = null;
   while (var6 == null)
   {
       var6 = UIManager_FindMovie("TRANSITIONMOVIE");
       if (var6 == null)
       {
           PRINTSTRING("SCRIPT: waiting for transition movie to stream in...\n");
           WAITUNWARPED(10);
       }
   }
   var7 = 0;
   var8 = 0;
   var9 = 0;
   FlashHelper_GetGlobalInt(var6, "StartOfTransitionout", &var7);
   FlashHelper_GetGlobalInt(var6, "StartOfTransitionin", &var8);
   FlashHelper_GetGlobalInt(var6, "TransitionOutisReady", &var9);
   PRINTSTRING("FADE DOWN REPORT\n");
   PRINTSTRING("================\n");
   PRINTSTRING("TransitionOut: ");
   PRINTINT(var7);
   PRINTSTRING("\nTransitionIn: ");
   PRINTINT(var8);
   PRINTSTRING("\nnTransitionReady: ");
   PRINTINT(var9);
   PRINTSTRING("\n");
   if ((var8 == 0) && ((var9 == 0) || ((var7 == 1) && (var9 == 2))))
   {
       FlashHelper_SetMovieEnabled(var6, 1);
       FlashHelper_SetGlobalInt(var6, "cur_visibility", 1);
       FlashHelper_SetGlobalInt(var6, "mask_color", var3);
       if (var1)
       {
           FlashHelper_SetGlobalInt(var6, "transition_type", 0);
       }
       else
       {
           FlashHelper_SetGlobalInt(var6, "transition_type", 1);
       }
       FlashHelper_SetGlobalFloat(var6, "fade_speed_in", var2);
       FlashHelper_SetGlobalFloat(var6, "fade_speed_out", 0.01f);
       FlashHelper_SetGlobalInt(var6, "StartOfTransitionout", 0);
       FlashHelper_SetGlobalInt(var6, "TransitionOutisReady", 0);
       FlashHelper_SetGlobalInt(var6, "StartOfTransitionin", 1);
       if (var0)
       {
           var8 = 1;
           while (var8 == 1)
           {
               FlashHelper_GetGlobalInt(var6, "StartOfTransitionin", &var8);
               if (var8 == 1)
               {
                   WAITUNWARPED(10);
               }
           }
       }
   }
}

