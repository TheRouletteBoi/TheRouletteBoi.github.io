﻿void main()
{
   auto var2, var3, var4, var5, var6, var7, var8, var9, var10, var11, var12, var13, var14, var15, var16, var17, var18, var19, var20, var21, var22, var23, var24, var25, var26, var27, var28, var29, var30, var31, var32, var33, var34, var35, var36, var37, var38, var39, var40, var41, var42, var43, var44, var45, var46, var47, var48, var49, var50, var51, var52, var53, var54, var55, var56, var57, var58, var59, var60, var61, var62, var63, var64, var65, var66, var67, var68, var69, var70, var71, var72, var73, var74, var75, var76, var77, var78, var79, var80, var81, var82, var83, var84, var85, var86, var87, var88, var89, var90, var91, var92, var93, var94, var95, var96, var97, var98, var99, var100, var101, var102, var103, var104, var105, var106, var107, var108, var109, var110, var111, var112, var113, var114, var115, var116, var117, var118, var119, var120, var121, var122, var123, var124, var125, var126, var127, var128, var129, var130, var131, var132, var133, var134, var135, var136, var137, var138, var139, var140, var141, var142, var143, var144, var145, var146, var147, var148, var149, var150, var151, var152, var153, var154, var155, var156, var157, var158, var159, var160, var161, var162, var163, var164, var165, var166, var167, var168, var169, var170, var171, var172, var173, var174, var175, var176, var177, var178, var179, var180, var181, var182, var183, var184, var185, var186, var187, var188, var189, var190, var191, var192, var193, var194, var195, var196, var197, var198, var199, var200, var201, var202, var203, var204;

   var2 = 5;
   var2[0] = (float)14;
   var2[1] = (float)15;
   var2[2] = (float)7;
   var2[3] = (float)17;
   var2[4] = (float)15;
   var8 = 5;
   var8[0 * 3].v0 = -2619.78f;
   var8[0 * 3].v1 = -4.80762f;
   var8[0 * 3].v2 = 20.3488f;
   var8[1 * 3].v0 = -2617.2f;
   var8[1 * 3].v1 = -4.60825f;
   var8[1 * 3].v2 = -186.81f;
   var8[2 * 3].v0 = -2182.75f;
   var8[2 * 3].v1 = -0.103645f;
   var8[2 * 3].v2 = -110.949f;
   var8[3 * 3].v0 = -2808.21f;
   var8[3 * 3].v1 = -4.80293f;
   var8[3 * 3].v2 = -386.669f;
   var8[4 * 3].v0 = -2898.69f;
   var8[4 * 3].v1 = -4.7885f;
   var8[4 * 3].v2 = 215.359f;
   var24 = 5;
   var24[0 * 3].v0 = -2638.69f;
   var24[0 * 3].v1 = -4.69479f;
   var24[0 * 3].v2 = -1.2627f;
   var24[1 * 3].v0 = -2637.58f;
   var24[1 * 3].v1 = -4.5889f;
   var24[1 * 3].v2 = -169.48f;
   var24[2 * 3].v0 = -2183.2f;
   var24[2 * 3].v1 = -0.426253f;
   var24[2 * 3].v2 = -66.646f;
   var24[3 * 3].v0 = -2835.65f;
   var24[3 * 3].v1 = -4.65012f;
   var24[3 * 3].v2 = -376.055f;
   var24[4 * 3].v0 = -2946.49f;
   var24[4 * 3].v1 = -4.74091f;
   var24[4 * 3].v2 = 185.337f;
   var40 = 16;
   var40[0 * 3].v0 = -2465.54f;
   var40[0 * 3].v1 = 0.196091f;
   var40[0 * 3].v2 = -362.383f;
   var40[1 * 3].v0 = -2467.12f;
   var40[1 * 3].v1 = 0.196091f;
   var40[1 * 3].v2 = -357.638f;
   var40[2 * 3].v0 = -2464.13f;
   var40[2 * 3].v1 = 0.196091f;
   var40[2 * 3].v2 = -366.654f;
   var40[3 * 3].v0 = -2468.54f;
   var40[3 * 3].v1 = 0.196091f;
   var40[3 * 3].v2 = -353.368f;
   var40[4 * 3].v0 = -2459.06f;
   var40[4 * 3].v1 = 0.196091f;
   var40[4 * 3].v2 = -354.958f;
   var40[5 * 3].v0 = -2456.06f;
   var40[5 * 3].v1 = 0.196091f;
   var40[5 * 3].v2 = -363.973f;
   var40[6 * 3].v0 = -2460.47f;
   var40[6 * 3].v1 = 0.196091f;
   var40[6 * 3].v2 = -350.688f;
   var40[7 * 3].v0 = -2457.48f;
   var40[7 * 3].v1 = 0.196091f;
   var40[7 * 3].v2 = -359.703f;
   var40[8 * 3].v0 = -2450.99f;
   var40[8 * 3].v1 = 0.196091f;
   var40[8 * 3].v2 = -352.278f;
   var40[9 * 3].v0 = -2447.99f;
   var40[9 * 3].v1 = 0.196091f;
   var40[9 * 3].v2 = -361.293f;
   var40[10 * 3].v0 = -2449.41f;
   var40[10 * 3].v1 = 0.196091f;
   var40[10 * 3].v2 = -357.023f;
   var40[11 * 3].v0 = -2452.41f;
   var40[11 * 3].v1 = 0.196091f;
   var40[11 * 3].v2 = -348.007f;
   var40[12 * 3].v0 = -2442.92f;
   var40[12 * 3].v1 = 0.196091f;
   var40[12 * 3].v2 = -349.598f;
   var40[13 * 3].v0 = -2439.93f;
   var40[13 * 3].v1 = 0.196091f;
   var40[13 * 3].v2 = -358.613f;
   var40[14 * 3].v0 = -2444.34f;
   var40[14 * 3].v1 = 0.196091f;
   var40[14 * 3].v2 = -345.327f;
   var40[15 * 3].v0 = -2441.35f;
   var40[15 * 3].v1 = 0.196091f;
   var40[15 * 3].v2 = -354.342f;
   var89 = 16;
   var89[0] = 71.6197f;
   var89[1] = 71.6197f;
   var89[2] = 71.6197f;
   var89[3] = 71.6197f;
   var89[4] = 71.6197f;
   var89[5] = 71.6197f;
   var89[6] = 71.6197f;
   var89[7] = 71.6197f;
   var89[8] = 71.6197f;
   var89[9] = 71.6197f;
   var89[10] = 71.6197f;
   var89[11] = 71.6197f;
   var89[12] = 71.6197f;
   var89[13] = 71.6197f;
   var89[14] = 71.6197f;
   var89[15] = 71.6197f;
   var106 = 16;
   var106[0 * 3].v0 = -2466.2f;
   var106[0 * 3].v1 = -9.80589f;
   var106[0 * 3].v2 = 212.915f;
   var106[1 * 3].v0 = -2466.18f;
   var106[1 * 3].v1 = -9.80589f;
   var106[1 * 3].v2 = 217.915f;
   var106[2 * 3].v0 = -2466.22f;
   var106[2 * 3].v1 = -9.80589f;
   var106[2 * 3].v2 = 208.415f;
   var106[3 * 3].v0 = -2466.16f;
   var106[3 * 3].v1 = -9.80589f;
   var106[3 * 3].v2 = 222.415f;
   var106[4 * 3].v0 = -2457.68f;
   var106[4 * 3].v1 = -9.80589f;
   var106[4 * 3].v2 = 217.879f;
   var106[5 * 3].v0 = -2457.72f;
   var106[5 * 3].v1 = -9.80589f;
   var106[5 * 3].v2 = 208.379f;
   var106[6 * 3].v0 = -2457.66f;
   var106[6 * 3].v1 = -9.80589f;
   var106[6 * 3].v2 = 222.379f;
   var106[7 * 3].v0 = -2457.7f;
   var106[7 * 3].v1 = -9.80589f;
   var106[7 * 3].v2 = 212.879f;
   var106[8 * 3].v0 = -2449.18f;
   var106[8 * 3].v1 = -9.80589f;
   var106[8 * 3].v2 = 217.843f;
   var106[9 * 3].v0 = -2449.22f;
   var106[9 * 3].v1 = -9.80589f;
   var106[9 * 3].v2 = 208.344f;
   var106[10 * 3].v0 = -2449.2f;
   var106[10 * 3].v1 = -9.80589f;
   var106[10 * 3].v2 = 212.843f;
   var106[11 * 3].v0 = -2449.16f;
   var106[11 * 3].v1 = -9.80589f;
   var106[11 * 3].v2 = 222.343f;
   var106[12 * 3].v0 = -2440.68f;
   var106[12 * 3].v1 = -9.80589f;
   var106[12 * 3].v2 = 217.808f;
   var106[13 * 3].v0 = -2440.72f;
   var106[13 * 3].v1 = -9.80589f;
   var106[13 * 3].v2 = 208.308f;
   var106[14 * 3].v0 = -2440.66f;
   var106[14 * 3].v1 = -9.80589f;
   var106[14 * 3].v2 = 222.308f;
   var106[15 * 3].v0 = -2440.7f;
   var106[15 * 3].v1 = -9.80589f;
   var106[15 * 3].v2 = 212.808f;
   var155 = 16;
   var155[0] = 90.2408f;
   var155[1] = 90.2408f;
   var155[2] = 90.2408f;
   var155[3] = 90.2408f;
   var155[4] = 90.2408f;
   var155[5] = 90.2408f;
   var155[6] = 90.2408f;
   var155[7] = 90.2408f;
   var155[8] = 90.2408f;
   var155[9] = 90.2408f;
   var155[10] = 90.2408f;
   var155[11] = 90.2408f;
   var155[12] = 90.2408f;
   var155[13] = 90.2408f;
   var155[14] = 90.2408f;
   var155[15] = 90.2408f;
   var172 = 5;
   var172[0 * 3].v0 = -2914.81f;
   var172[0 * 3].v1 = -4.78787f;
   var172[0 * 3].v2 = -90.8519f;
   var172[1 * 3].v0 = -2462.27f;
   var172[1 * 3].v1 = 0.194183f;
   var172[1 * 3].v2 = -358.794f;
   var172[2 * 3].v0 = -2461.85f;
   var172[2 * 3].v1 = -9.8061f;
   var172[2 * 3].v2 = 215.632f;
   var172[3 * 3].v0 = -2812.02f;
   var172[3 * 3].v1 = -4.63113f;
   var172[3 * 3].v2 = -89.8894f;
   var172[4 * 3].v0 = -2182.75f;
   var172[4 * 3].v1 = -0.103645f;
   var172[4 * 3].v2 = -110.949f;
   var188 = 5;
   var188[0] = "PickUp";
   var188[1] = "DropOff";
   var188[2] = "DropOff";
   var188[3] = "PickUp";
   var188[4] = "PickUp";
   var194 = 5;
   var194[0] = 0;
   var194[1] = 2;
   var194[2] = 1;
   var194[3] = 0;
   var194[4] = 0;
   var200 = 0;
   var201 = Ctf_GetMap(L[0].v801);
   CtfMap_Init(var201, 3, 2);
   var200 = 0;
   while (var200 < 5)
   {
       CtfMap_AddItem(var201, var188[var200], &(var172[var200 * 3]), var194[var200]);
       var200 = var200 + 1;
   }
   var202 = 0;
   var203 = Race_GetRaceGrid(L[0].v3, 0);
   var204 = Race_GetRaceGrid(L[0].v3, 1);
   var202 = 0;
   while (var202 < 16)
   {
       RaceGrid_SetPosition(var203, var202, &(var40[var202 * 3]), var89[var202]);
       RaceGrid_SetPosition(var204, var202, &(var106[var202 * 3]), var155[var202]);
       var202 = var202 + 1;
   }
   L[0].v2 = PickUpManager_CreatePowerUpSources(5);
   var200 = 0;
   while (var200 < 5)
   {
       PickUpManager_AddPowerUpSource(L[0].v2, &(var8[var200 * 3]), var2[var200], &(var24[var200 * 3]));
       var200 = var200 + 1;
   }
   sub_8ba(&L[0]);
}

void sub_8ba(var0)
{
   auto var3, var4, var5, var6, var7, var8, var9, var10, var11, var12, var13, var14, var15, var16;

   var8.v0 = (float)0;
   var8.v1 = (float)1;
   var8.v2 = (float)0;
   var11.v0 = (float)0;
   var11.v1 = (float)0;
   var11.v2 = (float)-1;
   RaceGrid_GetPosition(Race_GetRaceGrid(*(var0 + 12), 0), 0, &var4, &var7);
   Math_VecRotateY(&var11, &var11, var7);
   var11.v0 = var4.v0 + var11.v0;
   var11.v1 = var4.v1 + var11.v1;
   var11.v2 = var4.v2 + var11.v2;
   var8.v0 = var4.v0 + var8.v0;
   var8.v1 = var4.v1 + var8.v1;
   var8.v2 = var4.v2 + var8.v2;
   UILogic_LockStreaming(&var4, &var8, &var11);
   var3 = 0;
   while (var3 < *((var0 + 16) + 3080))
   {
       Racer_SetStreamingLockedIn((*((var0 + 16) + 4))[var3 * 48].v0);
       var3 = var3 + 1;
   }
   var14 = 1;
   while (var14 > 0)
   {
       var14 = *((var0 + 16) + 3080);
       var3 = 0;
       while (var3 < *((var0 + 16) + 3080))
       {
           if (Racer_IsSimStreamed((*((var0 + 16) + 4))[var3 * 48].v0))
           {
               var14 = var14 - 1;
           }
           var3 = var3 + 1;
       }
       if (var14 > 0)
       {
           if (!*((var0 + 16) + 3132))
           {
               sub_9d1(1, 0, 0x3f800000, 0);
           }
           WAIT(100);
       }
   }
   while (OpponentManager_StillStreamingOut())
   {
       WAIT(30);
   }
   var3 = 0;
   while (var3 < *((var0 + 16) + 3080))
   {
       if ((*((var0 + 16) + 4))[var3 * 48].v2 == 2)
       {
           PRINTSTRING(" BRAIN CREATED!");
           (*((var0 + 16) + 4))[var3 * 48].v3 = BrainFactory_CreateBrainRacing((*((var0 + 16) + 4))[var3 * 48].v0);
       }
       var3 = var3 + 1;
   }
   var15 = START_NEW_SCRIPT_WITH_ARGS("game/racetypes/BaseWarCore", var0, 802, 1500);
   while (!IsChildFinished(var15))
   {
       WAIT(30);
   }
   var3 = 0;
   while (var3 < *((var0 + 16) + 3080))
   {
       if ((*((var0 + 16) + 4))[var3 * 48].v2 == 2)
       {
           BrainFactory_DeleteBrain((*((var0 + 16) + 4))[var3 * 48].v0);
       }
       var3 = var3 + 1;
   }
}

void sub_9d1(var0, var1, var2, var3)
{
   auto var6, var7, var8, var9, var10, var11, var12, var13;

   var6 = null;
   while (var6 == null)
   {
       var6 = UIManager_FindMovie("TRANSITIONMOVIE");
       if (var6 == null)
       {
           PRINTSTRING("SCRIPT: waiting for transition movie to stream in...\n");
           WAITUNWARPED(10);
       }
   }
   var7 = 0;
   var8 = 0;
   var9 = 0;
   FlashHelper_GetGlobalInt(var6, "StartOfTransitionout", &var7);
   FlashHelper_GetGlobalInt(var6, "StartOfTransitionin", &var8);
   FlashHelper_GetGlobalInt(var6, "TransitionOutisReady", &var9);
   PRINTSTRING("FADE DOWN REPORT\n");
   PRINTSTRING("================\n");
   PRINTSTRING("TransitionOut: ");
   PRINTINT(var7);
   PRINTSTRING("\nTransitionIn: ");
   PRINTINT(var8);
   PRINTSTRING("\nnTransitionReady: ");
   PRINTINT(var9);
   PRINTSTRING("\n");
   if ((var8 == 0) && ((var9 == 0) || ((var7 == 1) && (var9 == 2))))
   {
       FlashHelper_SetMovieEnabled(var6, 1);
       FlashHelper_SetGlobalInt(var6, "cur_visibility", 1);
       FlashHelper_SetGlobalInt(var6, "mask_color", var3);
       if (var1)
       {
           FlashHelper_SetGlobalInt(var6, "transition_type", 0);
       }
       else
       {
           FlashHelper_SetGlobalInt(var6, "transition_type", 1);
       }
       FlashHelper_SetGlobalFloat(var6, "fade_speed_in", var2);
       FlashHelper_SetGlobalFloat(var6, "fade_speed_out", 0.01f);
       FlashHelper_SetGlobalInt(var6, "StartOfTransitionout", 0);
       FlashHelper_SetGlobalInt(var6, "TransitionOutisReady", 0);
       FlashHelper_SetGlobalInt(var6, "StartOfTransitionin", 1);
       if (var0)
       {
           var8 = 1;
           while (var8 == 1)
           {
               FlashHelper_GetGlobalInt(var6, "StartOfTransitionin", &var8);
               if (var8 == 1)
               {
                   WAITUNWARPED(10);
               }
           }
       }
   }
}

