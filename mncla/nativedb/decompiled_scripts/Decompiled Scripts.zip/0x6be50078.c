void main()
{
    while (true)
    {
        PRINTSTRING( "Script: hello world2\n" );
        WAITUNWARPED( 1000 );
    }
    return;
}
