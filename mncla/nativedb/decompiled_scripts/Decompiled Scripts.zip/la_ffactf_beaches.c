﻿void main()
{
   auto var2, var3, var4, var5, var6, var7, var8, var9, var10, var11, var12, var13, var14, var15, var16, var17, var18, var19, var20, var21, var22, var23, var24, var25, var26, var27, var28, var29, var30, var31, var32, var33, var34, var35, var36, var37, var38, var39, var40, var41, var42, var43, var44, var45, var46, var47, var48, var49, var50, var51, var52, var53, var54, var55, var56, var57, var58, var59, var60, var61, var62, var63, var64, var65, var66, var67, var68, var69, var70, var71, var72, var73, var74, var75, var76, var77, var78, var79, var80, var81, var82, var83, var84, var85, var86, var87, var88, var89, var90, var91, var92, var93, var94, var95, var96, var97, var98, var99, var100, var101, var102, var103, var104, var105, var106, var107, var108, var109, var110, var111, var112, var113, var114, var115, var116, var117, var118, var119, var120, var121, var122, var123, var124, var125, var126, var127, var128, var129, var130, var131, var132, var133, var134, var135, var136, var137, var138, var139, var140, var141, var142, var143, var144, var145, var146, var147, var148, var149, var150, var151, var152, var153, var154, var155, var156, var157, var158, var159, var160, var161, var162, var163, var164, var165, var166, var167, var168, var169, var170, var171, var172, var173, var174, var175, var176, var177, var178, var179, var180, var181, var182, var183, var184, var185, var186, var187, var188, var189, var190, var191, var192, var193, var194, var195, var196, var197, var198, var199, var200, var201, var202, var203, var204, var205, var206, var207, var208, var209, var210, var211, var212, var213, var214, var215, var216, var217, var218, var219, var220, var221, var222, var223, var224, var225, var226, var227, var228, var229, var230, var231, var232, var233, var234, var235, var236, var237, var238, var239, var240, var241, var242, var243, var244, var245, var246, var247, var248, var249, var250, var251, var252, var253, var254, var255, var256, var257, var258, var259, var260, var261, var262, var263, var264, var265, var266, var267, var268, var269, var270, var271, var272, var273, var274, var275, var276, var277, var278, var279, var280, var281, var282, var283, var284, var285, var286, var287, var288, var289, var290, var291, var292, var293, var294, var295, var296, var297, var298, var299, var300, var301, var302, var303, var304, var305, var306, var307, var308, var309, var310, var311, var312, var313, var314, var315, var316, var317, var318, var319, var320, var321, var322, var323, var324, var325, var326, var327, var328, var329, var330, var331, var332, var333, var334, var335, var336, var337, var338, var339, var340, var341, var342, var343, var344, var345, var346, var347, var348, var349, var350, var351, var352, var353, var354, var355, var356, var357, var358, var359, var360, var361, var362, var363, var364, var365, var366, var367, var368, var369, var370, var371, var372, var373, var374, var375, var376, var377, var378, var379, var380, var381, var382, var383, var384, var385, var386, var387, var388, var389, var390, var391, var392, var393, var394, var395, var396, var397, var398, var399, var400, var401, var402, var403, var404, var405, var406, var407, var408, var409, var410, var411, var412, var413, var414, var415, var416, var417, var418, var419, var420, var421, var422, var423, var424, var425, var426, var427, var428, var429, var430, var431, var432, var433, var434, var435, var436, var437, var438, var439, var440, var441, var442, var443, var444, var445, var446, var447, var448, var449, var450, var451, var452, var453, var454, var455, var456, var457, var458, var459, var460, var461, var462, var463, var464, var465, var466, var467;

   var2 = 25;
   var2[0] = (float)17;
   var2[1] = (float)12;
   var2[2] = (float)12;
   var2[3] = 12.5f;
   var2[4] = (float)12;
   var2[5] = 13.5f;
   var2[6] = (float)12;
   var2[7] = (float)13;
   var2[8] = (float)13;
   var2[9] = (float)14;
   var2[10] = (float)12;
   var2[11] = 14.5f;
   var2[12] = (float)13;
   var2[13] = 12.5f;
   var2[14] = 13.5f;
   var2[15] = (float)12;
   var2[16] = (float)9;
   var2[17] = 11.5f;
   var2[18] = (float)16;
   var2[19] = 13.5f;
   var2[20] = 14.5f;
   var2[21] = (float)10;
   var2[22] = 12.5f;
   var2[23] = 10.5f;
   var2[24] = (float)15;
   var28 = 25;
   var28[0 * 3].v0 = -2539.89f;
   var28[0 * 3].v1 = -11.6027f;
   var28[0 * 3].v2 = -1034.64f;
   var28[1 * 3].v0 = -2183.27f;
   var28[1 * 3].v1 = 15.1924f;
   var28[1 * 3].v2 = -1113.02f;
   var28[2 * 3].v0 = -2781.69f;
   var28[2 * 3].v1 = -29.741f;
   var28[2 * 3].v2 = -756.244f;
   var28[3 * 3].v0 = -2282.96f;
   var28[3 * 3].v1 = 3.84892f;
   var28[3 * 3].v2 = -674.324f;
   var28[4 * 3].v0 = -2543.2f;
   var28[4 * 3].v1 = 0.194458f;
   var28[4 * 3].v2 = -597.751f;
   var28[5 * 3].v0 = -2462.7f;
   var28[5 * 3].v1 = 0.188553f;
   var28[5 * 3].v2 = -357.747f;
   var28[6 * 3].v0 = -2812.16f;
   var28[6 * 3].v1 = -4.80286f;
   var28[6 * 3].v2 = -389.255f;
   var28[7 * 3].v0 = -2977.46f;
   var28[7 * 3].v1 = -25.396f;
   var28[7 * 3].v2 = -300.598f;
   var28[8 * 3].v0 = -2617.31f;
   var28[8 * 3].v1 = -4.60819f;
   var28[8 * 3].v2 = -187.875f;
   var28[9 * 3].v0 = -2915.41f;
   var28[9 * 3].v1 = -4.78803f;
   var28[9 * 3].v2 = -89.4434f;
   var28[10 * 3].v0 = -2618.13f;
   var28[10 * 3].v1 = -4.80869f;
   var28[10 * 3].v2 = 19.3596f;
   var28[11 * 3].v0 = -2898.22f;
   var28[11 * 3].v1 = -4.78851f;
   var28[11 * 3].v2 = 215.621f;
   var28[12 * 3].v0 = -2461.15f;
   var28[12 * 3].v1 = -9.80646f;
   var28[12 * 3].v2 = 216.456f;
   var28[13 * 3].v0 = -2712.4f;
   var28[13 * 3].v1 = -7.79575f;
   var28[13 * 3].v2 = 363.186f;
   var28[14 * 3].v0 = -2807.91f;
   var28[14 * 3].v1 = -6.80516f;
   var28[14 * 3].v2 = 514.994f;
   var28[15 * 3].v0 = -2462.76f;
   var28[15 * 3].v1 = -4.84597f;
   var28[15 * 3].v2 = 514.928f;
   var28[16 * 3].v0 = -2603.79f;
   var28[16 * 3].v1 = -9.20416f;
   var28[16 * 3].v2 = 625.074f;
   var28[17 * 3].v0 = -2805.11f;
   var28[17 * 3].v1 = -14.6194f;
   var28[17 * 3].v2 = 716.811f;
   var28[18 * 3].v0 = -2463.79f;
   var28[18 * 3].v1 = -7.25346f;
   var28[18 * 3].v2 = 716.341f;
   var28[19 * 3].v0 = -2718.6f;
   var28[19 * 3].v1 = -19.7946f;
   var28[19 * 3].v2 = 886.217f;
   var28[20 * 3].v0 = -3080.71f;
   var28[20 * 3].v1 = -29.3607f;
   var28[20 * 3].v2 = 1005.49f;
   var28[21 * 3].v0 = -3032.95f;
   var28[21 * 3].v1 = -19.7348f;
   var28[21 * 3].v2 = 561.643f;
   var28[22 * 3].v0 = -3291.35f;
   var28[22 * 3].v1 = -30.8766f;
   var28[22 * 3].v2 = 561.228f;
   var28[23 * 3].v0 = -3449.06f;
   var28[23 * 3].v1 = -24.6379f;
   var28[23 * 3].v2 = 558.071f;
   var28[24 * 3].v0 = -3166.73f;
   var28[24 * 3].v1 = -26.9827f;
   var28[24 * 3].v2 = 153.002f;
   var104 = 25;
   var104[0 * 3].v0 = (float)0;
   var104[0 * 3].v1 = (float)0;
   var104[0 * 3].v2 = (float)0;
   var104[1 * 3].v0 = (float)0;
   var104[1 * 3].v1 = (float)0;
   var104[1 * 3].v2 = (float)0;
   var104[2 * 3].v0 = (float)0;
   var104[2 * 3].v1 = (float)0;
   var104[2 * 3].v2 = (float)0;
   var104[3 * 3].v0 = (float)0;
   var104[3 * 3].v1 = (float)0;
   var104[3 * 3].v2 = (float)0;
   var104[4 * 3].v0 = (float)0;
   var104[4 * 3].v1 = (float)0;
   var104[4 * 3].v2 = (float)0;
   var104[5 * 3].v0 = (float)0;
   var104[5 * 3].v1 = (float)0;
   var104[5 * 3].v2 = (float)0;
   var104[6 * 3].v0 = (float)0;
   var104[6 * 3].v1 = (float)0;
   var104[6 * 3].v2 = (float)0;
   var104[7 * 3].v0 = (float)0;
   var104[7 * 3].v1 = (float)0;
   var104[7 * 3].v2 = (float)0;
   var104[8 * 3].v0 = (float)0;
   var104[8 * 3].v1 = (float)0;
   var104[8 * 3].v2 = (float)0;
   var104[9 * 3].v0 = (float)0;
   var104[9 * 3].v1 = (float)0;
   var104[9 * 3].v2 = (float)0;
   var104[10 * 3].v0 = (float)0;
   var104[10 * 3].v1 = (float)0;
   var104[10 * 3].v2 = (float)0;
   var104[11 * 3].v0 = (float)0;
   var104[11 * 3].v1 = (float)0;
   var104[11 * 3].v2 = (float)0;
   var104[12 * 3].v0 = (float)0;
   var104[12 * 3].v1 = (float)0;
   var104[12 * 3].v2 = (float)0;
   var104[13 * 3].v0 = (float)0;
   var104[13 * 3].v1 = (float)0;
   var104[13 * 3].v2 = (float)0;
   var104[14 * 3].v0 = (float)0;
   var104[14 * 3].v1 = (float)0;
   var104[14 * 3].v2 = (float)0;
   var104[15 * 3].v0 = (float)0;
   var104[15 * 3].v1 = (float)0;
   var104[15 * 3].v2 = (float)0;
   var104[16 * 3].v0 = (float)0;
   var104[16 * 3].v1 = (float)0;
   var104[16 * 3].v2 = (float)0;
   var104[17 * 3].v0 = (float)0;
   var104[17 * 3].v1 = (float)0;
   var104[17 * 3].v2 = (float)0;
   var104[18 * 3].v0 = (float)0;
   var104[18 * 3].v1 = (float)0;
   var104[18 * 3].v2 = (float)0;
   var104[19 * 3].v0 = (float)0;
   var104[19 * 3].v1 = (float)0;
   var104[19 * 3].v2 = (float)0;
   var104[20 * 3].v0 = (float)0;
   var104[20 * 3].v1 = (float)0;
   var104[20 * 3].v2 = (float)0;
   var104[21 * 3].v0 = (float)0;
   var104[21 * 3].v1 = (float)0;
   var104[21 * 3].v2 = (float)0;
   var104[22 * 3].v0 = (float)0;
   var104[22 * 3].v1 = (float)0;
   var104[22 * 3].v2 = (float)0;
   var104[23 * 3].v0 = (float)0;
   var104[23 * 3].v1 = (float)0;
   var104[23 * 3].v2 = (float)0;
   var104[24 * 3].v0 = (float)0;
   var104[24 * 3].v1 = (float)0;
   var104[24 * 3].v2 = (float)0;
   var180 = 16;
   var180[0 * 3].v0 = -2418.74f;
   var180[0 * 3].v1 = 0.230782f;
   var180[0 * 3].v2 = -384.402f;
   var180[1 * 3].v0 = -2416.53f;
   var180[1 * 3].v1 = 0.230782f;
   var180[1 * 3].v2 = -380.479f;
   var180[2 * 3].v0 = -2420.94f;
   var180[2 * 3].v1 = 0.230782f;
   var180[2 * 3].v2 = -388.324f;
   var180[3 * 3].v0 = -2423.39f;
   var180[3 * 3].v1 = 0.230782f;
   var180[3 * 3].v2 = -392.682f;
   var180[4 * 3].v0 = -2414.08f;
   var180[4 * 3].v1 = 0.230782f;
   var180[4 * 3].v2 = -376.122f;
   var180[5 * 3].v0 = -2425.6f;
   var180[5 * 3].v1 = 0.230782f;
   var180[5 * 3].v2 = -396.604f;
   var180[6 * 3].v0 = -2411.87f;
   var180[6 * 3].v1 = 0.230782f;
   var180[6 * 3].v2 = -372.199f;
   var180[7 * 3].v0 = -2409.67f;
   var180[7 * 3].v1 = 0.230782f;
   var180[7 * 3].v2 = -368.277f;
   var180[8 * 3].v0 = -2409.12f;
   var180[8 * 3].v1 = 0.230782f;
   var180[8 * 3].v2 = -384.647f;
   var180[9 * 3].v0 = -2411.33f;
   var180[9 * 3].v1 = 0.230782f;
   var180[9 * 3].v2 = -388.569f;
   var180[10 * 3].v0 = -2413.53f;
   var180[10 * 3].v1 = 0.230782f;
   var180[10 * 3].v2 = -392.491f;
   var180[11 * 3].v0 = -2406.67f;
   var180[11 * 3].v1 = 0.230782f;
   var180[11 * 3].v2 = -380.289f;
   var180[12 * 3].v0 = -2415.99f;
   var180[12 * 3].v1 = 0.230782f;
   var180[12 * 3].v2 = -396.849f;
   var180[13 * 3].v0 = -2404.46f;
   var180[13 * 3].v1 = 0.230782f;
   var180[13 * 3].v2 = -376.367f;
   var180[14 * 3].v0 = -2418.19f;
   var180[14 * 3].v1 = 0.230782f;
   var180[14 * 3].v2 = -400.771f;
   var180[15 * 3].v0 = -2402.26f;
   var180[15 * 3].v1 = 0.230782f;
   var180[15 * 3].v2 = -372.445f;
   var229 = 16;
   var229[0] = 119.358f;
   var229[1] = 119.358f;
   var229[2] = 119.358f;
   var229[3] = 119.358f;
   var229[4] = 119.358f;
   var229[5] = 119.358f;
   var229[6] = 119.358f;
   var229[7] = 119.358f;
   var229[8] = 119.358f;
   var229[9] = 119.358f;
   var229[10] = 119.358f;
   var229[11] = 119.358f;
   var229[12] = 119.358f;
   var229[13] = 119.358f;
   var229[14] = 119.358f;
   var229[15] = 119.358f;
   var246 = 43;
   var246[0 * 3].v0 = -2183.27f;
   var246[0 * 3].v1 = 15.1926f;
   var246[0 * 3].v2 = -1113.03f;
   var246[1 * 3].v0 = -2543.46f;
   var246[1 * 3].v1 = -12.1894f;
   var246[1 * 3].v2 = -1024.91f;
   var246[2 * 3].v0 = -2809.47f;
   var246[2 * 3].v1 = -29.7891f;
   var246[2 * 3].v2 = -1009.66f;
   var246[3 * 3].v0 = -2543.54f;
   var246[3 * 3].v1 = 0.193321f;
   var246[3 * 3].v2 = -597.755f;
   var246[4 * 3].v0 = -2391.96f;
   var246[4 * 3].v1 = 2.36291f;
   var246[4 * 3].v2 = -564.05f;
   var246[5 * 3].v0 = -2283.31f;
   var246[5 * 3].v1 = 3.84826f;
   var246[5 * 3].v2 = -674.345f;
   var246[6 * 3].v0 = -2462.79f;
   var246[6 * 3].v1 = 0.187424f;
   var246[6 * 3].v2 = -357.443f;
   var246[7 * 3].v0 = -2616.79f;
   var246[7 * 3].v1 = 0.193573f;
   var246[7 * 3].v2 = -383.59f;
   var246[8 * 3].v0 = -2617.09f;
   var246[8 * 3].v1 = -4.60593f;
   var246[8 * 3].v2 = -187.865f;
   var246[9 * 3].v0 = -2811.81f;
   var246[9 * 3].v1 = -4.80423f;
   var246[9 * 3].v2 = -389.285f;
   var246[10 * 3].v0 = -2899.38f;
   var246[10 * 3].v1 = -4.78913f;
   var246[10 * 3].v2 = -186.008f;
   var246[11 * 3].v0 = -2782.23f;
   var246[11 * 3].v1 = -29.7399f;
   var246[11 * 3].v2 = -756.147f;
   var246[12 * 3].v0 = -2912.03f;
   var246[12 * 3].v1 = -4.78914f;
   var246[12 * 3].v2 = 19.7947f;
   var246[13 * 3].v0 = -2617.91f;
   var246[13 * 3].v1 = -4.80965f;
   var246[13 * 3].v2 = 19.1216f;
   var246[14 * 3].v0 = -2461.6f;
   var246[14 * 3].v1 = -9.80782f;
   var246[14 * 3].v2 = 216.467f;
   var246[15 * 3].v0 = -2617.03f;
   var246[15 * 3].v1 = -9.79944f;
   var246[15 * 3].v2 = 215.597f;
   var246[16 * 3].v0 = -2898.72f;
   var246[16 * 3].v1 = -4.78914f;
   var246[16 * 3].v2 = 215.359f;
   var246[17 * 3].v0 = -2710.55f;
   var246[17 * 3].v1 = -6.80901f;
   var246[17 * 3].v2 = 216.973f;
   var246[18 * 3].v0 = -2819.88f;
   var246[18 * 3].v1 = -4.78913f;
   var246[18 * 3].v2 = 363.531f;
   var246[19 * 3].v0 = -2711.54f;
   var246[19 * 3].v1 = -7.79553f;
   var246[19 * 3].v2 = 363.439f;
   var246[20 * 3].v0 = -2808.13f;
   var246[20 * 3].v1 = -6.80622f;
   var246[20 * 3].v2 = 514.653f;
   var246[21 * 3].v0 = -2711.17f;
   var246[21 * 3].v1 = -9.79848f;
   var246[21 * 3].v2 = 514.648f;
   var246[22 * 3].v0 = -2603.94f;
   var246[22 * 3].v1 = -9.79404f;
   var246[22 * 3].v2 = 515.695f;
   var246[23 * 3].v0 = -2462.41f;
   var246[23 * 3].v1 = -4.84672f;
   var246[23 * 3].v2 = 514.964f;
   var246[24 * 3].v0 = -2809.52f;
   var246[24 * 3].v1 = -9.72063f;
   var246[24 * 3].v2 = 611.037f;
   var246[25 * 3].v0 = -2804.58f;
   var246[25 * 3].v1 = -14.6231f;
   var246[25 * 3].v2 = 716.82f;
   var246[26 * 3].v0 = -2603.12f;
   var246[26 * 3].v1 = -14.7775f;
   var246[26 * 3].v2 = 716.019f;
   var246[27 * 3].v0 = -2718.73f;
   var246[27 * 3].v1 = -19.7956f;
   var246[27 * 3].v2 = 886.172f;
   var246[28 * 3].v0 = -2843.5f;
   var246[28 * 3].v1 = -24.8816f;
   var246[28 * 3].v2 = 957.387f;
   var246[29 * 3].v0 = -2637.16f;
   var246[29 * 3].v1 = -19.7946f;
   var246[29 * 3].v2 = 1013.36f;
   var246[30 * 3].v0 = -2463.44f;
   var246[30 * 3].v1 = -7.2639f;
   var246[30 * 3].v2 = 716.414f;
   var246[31 * 3].v0 = -2462.01f;
   var246[31 * 3].v1 = -6.21974f;
   var246[31 * 3].v2 = 602.672f;
   var246[32 * 3].v0 = -2177.82f;
   var246[32 * 3].v1 = -0.150024f;
   var246[32 * 3].v2 = 396.487f;
   var246[33 * 3].v0 = -2909.03f;
   var246[33 * 3].v1 = -24.7906f;
   var246[33 * 3].v2 = 848.013f;
   var246[34 * 3].v0 = -3031.18f;
   var246[34 * 3].v1 = -19.7355f;
   var246[34 * 3].v2 = 520.517f;
   var246[35 * 3].v0 = -3030.03f;
   var246[35 * 3].v1 = -19.7355f;
   var246[35 * 3].v2 = 607.598f;
   var246[36 * 3].v0 = -3257.17f;
   var246[36 * 3].v1 = -19.7355f;
   var246[36 * 3].v2 = 561.291f;
   var246[37 * 3].v0 = -2986.16f;
   var246[37 * 3].v1 = -25.9626f;
   var246[37 * 3].v2 = 310.711f;
   var246[38 * 3].v0 = -3028.76f;
   var246[38 * 3].v1 = -27.8943f;
   var246[38 * 3].v2 = -14.6646f;
   var246[39 * 3].v0 = -2371.69f;
   var246[39 * 3].v1 = 1.48779f;
   var246[39 * 3].v2 = -1105.74f;
   var246[40 * 3].v0 = -2595.39f;
   var246[40 * 3].v1 = -4.17868f;
   var246[40 * 3].v2 = -845.068f;
   var246[41 * 3].v0 = -2892.57f;
   var246[41 * 3].v1 = -26.0402f;
   var246[41 * 3].v2 = -488.6f;
   var246[42 * 3].v0 = -2255.25f;
   var246[42 * 3].v1 = 5.78168f;
   var246[42 * 3].v2 = -890.226f;
   var376 = 43;
   var376[0] = "PickUp_or_DropOff";
   var376[1] = "PickUp_or_DropOff";
   var376[2] = "PickUp_or_DropOff";
   var376[3] = "PickUp_or_DropOff";
   var376[4] = "PickUp_or_DropOff";
   var376[5] = "PickUp_or_DropOff";
   var376[6] = "PickUp_or_DropOff";
   var376[7] = "PickUp_or_DropOff";
   var376[8] = "PickUp_or_DropOff";
   var376[9] = "PickUp_or_DropOff";
   var376[10] = "PickUp_or_DropOff";
   var376[11] = "PickUp_or_DropOff";
   var376[12] = "PickUp_or_DropOff";
   var376[13] = "PickUp_or_DropOff";
   var376[14] = "PickUp_or_DropOff";
   var376[15] = "PickUp_or_DropOff";
   var376[16] = "PickUp_or_DropOff";
   var376[17] = "PickUp_or_DropOff";
   var376[18] = "PickUp_or_DropOff";
   var376[19] = "PickUp_or_DropOff";
   var376[20] = "PickUp_or_DropOff";
   var376[21] = "PickUp_or_DropOff";
   var376[22] = "PickUp_or_DropOff";
   var376[23] = "PickUp_or_DropOff";
   var376[24] = "PickUp_or_DropOff";
   var376[25] = "PickUp_or_DropOff";
   var376[26] = "PickUp_or_DropOff";
   var376[27] = "PickUp_or_DropOff";
   var376[28] = "PickUp_or_DropOff";
   var376[29] = "PickUp_or_DropOff";
   var376[30] = "PickUp_or_DropOff";
   var376[31] = "PickUp_or_DropOff";
   var376[32] = "PickUp_or_DropOff";
   var376[33] = "PickUp_or_DropOff";
   var376[34] = "PickUp_or_DropOff";
   var376[35] = "PickUp_or_DropOff";
   var376[36] = "PickUp_or_DropOff";
   var376[37] = "PickUp_or_DropOff";
   var376[38] = "PickUp_or_DropOff";
   var376[39] = "PickUp_or_DropOff";
   var376[40] = "PickUp_or_DropOff";
   var376[41] = "PickUp_or_DropOff";
   var376[42] = "PickUp_or_DropOff";
   var420 = 43;
   var420[0] = 0;
   var420[1] = 0;
   var420[2] = 0;
   var420[3] = 0;
   var420[4] = 0;
   var420[5] = 0;
   var420[6] = 0;
   var420[7] = 0;
   var420[8] = 0;
   var420[9] = 0;
   var420[10] = 0;
   var420[11] = 0;
   var420[12] = 0;
   var420[13] = 0;
   var420[14] = 0;
   var420[15] = 0;
   var420[16] = 0;
   var420[17] = 0;
   var420[18] = 0;
   var420[19] = 0;
   var420[20] = 0;
   var420[21] = 0;
   var420[22] = 0;
   var420[23] = 0;
   var420[24] = 0;
   var420[25] = 0;
   var420[26] = 0;
   var420[27] = 0;
   var420[28] = 0;
   var420[29] = 0;
   var420[30] = 0;
   var420[31] = 0;
   var420[32] = 0;
   var420[33] = 0;
   var420[34] = 0;
   var420[35] = 0;
   var420[36] = 0;
   var420[37] = 0;
   var420[38] = 0;
   var420[39] = 0;
   var420[40] = 0;
   var420[41] = 0;
   var420[42] = 0;
   var464 = 0;
   var465 = Ctf_GetMap(L[0].v801);
   CtfMap_Init(var465, 43, 43);
   var464 = 0;
   while (var464 < 43)
   {
       CtfMap_AddItem(var465, var376[var464], &(var246[var464 * 3]), var420[var464]);
       var464 = var464 + 1;
   }
   var466 = 0;
   var467 = Race_GetRaceGrid(L[0].v3, 0);
   var466 = 0;
   while (var466 < 16)
   {
       RaceGrid_SetPosition(var467, var466, &(var180[var466 * 3]), var229[var466]);
       var466 = var466 + 1;
   }
   L[0].v2 = PickUpManager_CreatePowerUpSources(25);
   var464 = 0;
   while (var464 < 25)
   {
       PickUpManager_AddPowerUpSource(L[0].v2, &(var28[var464 * 3]), var2[var464], &(var104[var464 * 3]));
       var464 = var464 + 1;
   }
   sub_1371(&L[0]);
}

void sub_1371(var0)
{
   auto var3, var4, var5, var6, var7, var8, var9, var10, var11, var12, var13, var14, var15, var16;

   var8.v0 = (float)0;
   var8.v1 = (float)1;
   var8.v2 = (float)0;
   var11.v0 = (float)0;
   var11.v1 = (float)0;
   var11.v2 = (float)-1;
   RaceGrid_GetPosition(Race_GetRaceGrid(*(var0 + 12), 0), 0, &var4, &var7);
   Math_VecRotateY(&var11, &var11, var7);
   var11.v0 = var4.v0 + var11.v0;
   var11.v1 = var4.v1 + var11.v1;
   var11.v2 = var4.v2 + var11.v2;
   var8.v0 = var4.v0 + var8.v0;
   var8.v1 = var4.v1 + var8.v1;
   var8.v2 = var4.v2 + var8.v2;
   UILogic_LockStreaming(&var4, &var8, &var11);
   var3 = 0;
   while (var3 < *((var0 + 16) + 3080))
   {
       Racer_SetStreamingLockedIn((*((var0 + 16) + 4))[var3 * 48].v0);
       var3 = var3 + 1;
   }
   var14 = 1;
   while (var14 > 0)
   {
       var14 = *((var0 + 16) + 3080);
       var3 = 0;
       while (var3 < *((var0 + 16) + 3080))
       {
           if (Racer_IsSimStreamed((*((var0 + 16) + 4))[var3 * 48].v0))
           {
               var14 = var14 - 1;
           }
           var3 = var3 + 1;
       }
       if (var14 > 0)
       {
           if (!*((var0 + 16) + 3132))
           {
               sub_1488(1, 0, 0x3f800000, 0);
           }
           WAIT(100);
       }
   }
   while (OpponentManager_StillStreamingOut())
   {
       WAIT(30);
   }
   var3 = 0;
   while (var3 < *((var0 + 16) + 3080))
   {
       if ((*((var0 + 16) + 4))[var3 * 48].v2 == 2)
       {
           PRINTSTRING(" BRAIN CREATED!");
           (*((var0 + 16) + 4))[var3 * 48].v3 = BrainFactory_CreateBrainRacing((*((var0 + 16) + 4))[var3 * 48].v0);
       }
       var3 = var3 + 1;
   }
   var15 = START_NEW_SCRIPT_WITH_ARGS("game/racetypes/BaseWarCore", var0, 802, 1500);
   while (!IsChildFinished(var15))
   {
       WAIT(30);
   }
   var3 = 0;
   while (var3 < *((var0 + 16) + 3080))
   {
       if ((*((var0 + 16) + 4))[var3 * 48].v2 == 2)
       {
           BrainFactory_DeleteBrain((*((var0 + 16) + 4))[var3 * 48].v0);
       }
       var3 = var3 + 1;
   }
}

void sub_1488(var0, var1, var2, var3)
{
   auto var6, var7, var8, var9, var10, var11, var12, var13;

   var6 = null;
   while (var6 == null)
   {
       var6 = UIManager_FindMovie("TRANSITIONMOVIE");
       if (var6 == null)
       {
           PRINTSTRING("SCRIPT: waiting for transition movie to stream in...\n");
           WAITUNWARPED(10);
       }
   }
   var7 = 0;
   var8 = 0;
   var9 = 0;
   FlashHelper_GetGlobalInt(var6, "StartOfTransitionout", &var7);
   FlashHelper_GetGlobalInt(var6, "StartOfTransitionin", &var8);
   FlashHelper_GetGlobalInt(var6, "TransitionOutisReady", &var9);
   PRINTSTRING("FADE DOWN REPORT\n");
   PRINTSTRING("================\n");
   PRINTSTRING("TransitionOut: ");
   PRINTINT(var7);
   PRINTSTRING("\nTransitionIn: ");
   PRINTINT(var8);
   PRINTSTRING("\nnTransitionReady: ");
   PRINTINT(var9);
   PRINTSTRING("\n");
   if ((var8 == 0) && ((var9 == 0) || ((var7 == 1) && (var9 == 2))))
   {
       FlashHelper_SetMovieEnabled(var6, 1);
       FlashHelper_SetGlobalInt(var6, "cur_visibility", 1);
       FlashHelper_SetGlobalInt(var6, "mask_color", var3);
       if (var1)
       {
           FlashHelper_SetGlobalInt(var6, "transition_type", 0);
       }
       else
       {
           FlashHelper_SetGlobalInt(var6, "transition_type", 1);
       }
       FlashHelper_SetGlobalFloat(var6, "fade_speed_in", var2);
       FlashHelper_SetGlobalFloat(var6, "fade_speed_out", 0.01f);
       FlashHelper_SetGlobalInt(var6, "StartOfTransitionout", 0);
       FlashHelper_SetGlobalInt(var6, "TransitionOutisReady", 0);
       FlashHelper_SetGlobalInt(var6, "StartOfTransitionin", 1);
       if (var0)
       {
           var8 = 1;
           while (var8 == 1)
           {
               FlashHelper_GetGlobalInt(var6, "StartOfTransitionin", &var8);
               if (var8 == 1)
               {
                   WAITUNWARPED(10);
               }
           }
       }
   }
}

