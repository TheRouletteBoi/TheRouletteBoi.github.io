﻿void main()
{
   auto var2, var3, var4, var5, var6, var7, var8, var9, var10, var11, var12, var13, var14, var15, var16, var17, var18, var19, var20, var21, var22, var23, var24, var25, var26, var27, var28, var29, var30, var31, var32, var33, var34, var35, var36, var37, var38, var39, var40, var41, var42, var43, var44, var45, var46, var47, var48, var49, var50, var51, var52, var53, var54, var55, var56, var57, var58, var59, var60, var61, var62, var63, var64, var65, var66, var67, var68, var69, var70, var71, var72, var73, var74, var75, var76, var77, var78, var79, var80, var81, var82, var83, var84, var85, var86, var87, var88, var89, var90, var91, var92, var93, var94, var95, var96, var97, var98, var99, var100, var101, var102, var103, var104, var105, var106, var107, var108, var109, var110, var111, var112, var113, var114, var115, var116, var117, var118, var119, var120, var121, var122, var123, var124, var125;

   var2 = 52;
   var2[0] = "character/drv_fa_001_set";
   var2[1] = "character/drv_fb_01_set";
   var2[2] = "character/drv_fc_002_set";
   var2[3] = "character/drv_fc_002_set_hackedscale";
   var2[4] = "character/drv_fc_003_set";
   var2[5] = "character/drv_fc_003_set_hackedscale";
   var2[6] = "character/drv_fh_001_mot_set";
   var2[7] = "character/drv_fh_001_set";
   var2[8] = "character/drv_ma_001_set";
   var2[9] = "character/drv_ma_001_set_hackedscale";
   var2[10] = "character/drv_ma_02_set";
   var2[11] = "character/drv_ma_03_mot_set";
   var2[12] = "character/drv_ma_03_set";
   var2[13] = "character/drv_ma_03_set_hackedscale";
   var2[14] = "character/drv_mb_001_mot_set";
   var2[15] = "character/drv_mb_001_set";
   var2[16] = "character/drv_mb_001_set_hackedscale";
   var2[17] = "character/drv_mb_007_set";
   var2[18] = "character/drv_mb_008_set";
   var2[19] = "character/drv_mb_008_set_hackedscale";
   var2[20] = "character/drv_mb_009_mot_set";
   var2[21] = "character/drv_mb_009_set";
   var2[22] = "character/drv_mb_010_set";
   var2[23] = "character/drv_mb_02_set";
   var2[24] = "character/drv_mb_03_set";
   var2[25] = "character/drv_mb_04_set";
   var2[26] = "character/drv_mb_04_set_hackedscale";
   var2[27] = "character/drv_mb_05_set";
   var2[28] = "character/drv_mb_06_set";
   var2[29] = "character/drv_mc_001_mot_set";
   var2[30] = "character/drv_mc_001_set";
   var2[31] = "character/drv_mc_001_set_hackedscale";
   var2[32] = "character/drv_mc_003_set";
   var2[33] = "character/drv_mc_003_set_hackedscale";
   var2[34] = "character/drv_mc_02_set";
   var2[35] = "character/drv_mc_02_set_hackedscale";
   var2[36] = "character/drv_mc_05_set";
   var2[37] = "character/drv_mc_06_set";
   var2[38] = "character/drv_mc_07_mot_set";
   var2[39] = "character/drv_mc_07_set";
   var2[40] = "character/drv_mh_003_set";
   var2[41] = "character/drv_mh_005_mot_set";
   var2[42] = "character/drv_mh_005_set";
   var2[43] = "character/drv_mh_006_set";
   var2[44] = "character/drv_mh_006_set_hackedscale";
   var2[45] = "character/drv_mh_01_set";
   var2[46] = "character/drv_mh_02_set";
   var2[47] = "character/drv_mh_02_set_hackedscale";
   var2[48] = "character/drv_mh_04_set";
   var2[49] = "character/drv_mp_01_mot_set";
   var2[50] = "character/drv_mp_01_set";
   var2[51] = "character/drv_mp_01_set_hackedscale";
   var55 = 52;
   var55[0] = "drv_fa_001_set";
   var55[1] = "drv_fb_01_set";
   var55[2] = "drv_fc_002_set";
   var55[3] = "drv_fc_002_set_hackedscale";
   var55[4] = "drv_fc_003_set";
   var55[5] = "drv_fc_003_set_hackedscale";
   var55[6] = "drv_fh_001_mot_set";
   var55[7] = "drv_fh_001_set";
   var55[8] = "drv_ma_001_set";
   var55[9] = "drv_ma_001_set_hackedscale";
   var55[10] = "drv_ma_02_set";
   var55[11] = "drv_ma_03_mot_set";
   var55[12] = "drv_ma_03_set";
   var55[13] = "drv_ma_03_set_hackedscale";
   var55[14] = "drv_mb_001_mot_set";
   var55[15] = "drv_mb_001_set";
   var55[16] = "drv_mb_001_set_hackedscale";
   var55[17] = "drv_mb_007_set";
   var55[18] = "drv_mb_008_set";
   var55[19] = "drv_mb_008_set_hackedscale";
   var55[20] = "drv_mb_009_mot_set";
   var55[21] = "drv_mb_009_set";
   var55[22] = "drv_mb_010_set";
   var55[23] = "drv_mb_02_set";
   var55[24] = "drv_mb_03_set";
   var55[25] = "drv_mb_04_set";
   var55[26] = "drv_mb_04_set_hackedscale";
   var55[27] = "drv_mb_05_set";
   var55[28] = "drv_mb_06_set";
   var55[29] = "drv_mc_001_mot_set";
   var55[30] = "drv_mc_001_set";
   var55[31] = "drv_mc_001_set_hackedscale";
   var55[32] = "drv_mc_003_set";
   var55[33] = "drv_mc_003_set_hackedscale";
   var55[34] = "drv_mc_02_set";
   var55[35] = "drv_mc_02_set_hackedscale";
   var55[36] = "drv_mc_05_set";
   var55[37] = "drv_mc_06_set";
   var55[38] = "drv_mc_07_mot_set";
   var55[39] = "drv_mc_07_set";
   var55[40] = "drv_mh_003_set";
   var55[41] = "drv_mh_005_mot_set";
   var55[42] = "drv_mh_005_set";
   var55[43] = "drv_mh_006_set";
   var55[44] = "drv_mh_006_set_hackedscale";
   var55[45] = "drv_mh_01_set";
   var55[46] = "drv_mh_02_set";
   var55[47] = "drv_mh_02_set_hackedscale";
   var55[48] = "drv_mh_04_set";
   var55[49] = "drv_mp_01_mot_set";
   var55[50] = "drv_mp_01_set";
   var55[51] = "drv_mp_01_set_hackedscale";
   var108 = "anim/Extras/male";
   var109 = 1;
   var109[0] = "Mped_Idle";
   var111 = "anim/Extras/female";
   var112 = "FPed_Idle";
   var113 = 0;
   var114 = 0;
   while (!var114)
   {
       var114 = 1;
       var113 = 0;
       while (var113 < 32)
       {
           if (((20 + var113) != 20) && ((20 + var113) != 29))
           {
               var114 = var114 && CineScript_Characters_LoadType(var2[20 + var113], var55[20 + var113]);
           }
           var113 = var113 + 1;
       }
       WAITUNWARPED(100);
   }
   var113 = 0;
   while (var113 < 1)
   {
       var114 = var114 && CineScript_Characters_LoadAnimation(var108, var109[var113]);
       var113 = var113 + 1;
   }
   var114 = var114 && CineScript_Characters_LoadAnimation(var111, var112);
   if (!var114)
   {
       PRINTSTRING("Script 'test_lineup.sc' failed to load\n");
       BREAKPOINT();
   }
   var119.v0 = 464.8f;
   var119.v1 = 24.0f;
   var119.v2 = -884.1f;
   var122.v0 = 0.5f;
   var122.v1 = 0.0f;
   var122.v2 = 0.0f;
   Math_VecRotateY(&var122, &var122, -140.0f * 0.01745329f);
   var115.v0.v0 = var119.v0;
   var115.v0.v1 = var119.v1;
   var115.v0.v2 = var119.v2;
   var115.v3 = -140.0f;
   var113 = 0;
   while (var113 < 32)
   {
       if (((20 + var113) != 20) && ((20 + var113) != 29))
       {
           var125 = CineScript_Characters_LaunchAnimAt(var2[20 + var113], var55[20 + var113], var108, var109[(20 + var113) % 1], &var115, -1);
           var115.v0.v0 = var122.v0 + var115.v0.v0;
           var115.v0.v1 = var122.v1 + var115.v0.v1;
           var115.v0.v2 = var122.v2 + var115.v0.v2;
           CineScript_PushKillBuffer(var125, 0);
       }
       var113 = var113 + 1;
   }
   sub_fec(L[0]);
}

void sub_fec(var0)
{
   auto var3;

   var0.v0 = 3;
}

