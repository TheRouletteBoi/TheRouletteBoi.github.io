﻿void main()
{
   auto var2, var3, var4, var5, var6, var7, var8, var9, var10, var11, var12, var13, var14, var15, var16, var17, var18, var19, var20, var21, var22, var23, var24, var25, var26, var27, var28, var29, var30, var31, var32, var33, var34, var35, var36, var37, var38, var39, var40, var41, var42, var43, var44, var45, var46, var47, var48, var49, var50, var51, var52, var53, var54, var55, var56, var57, var58, var59, var60, var61, var62, var63, var64, var65, var66, var67, var68, var69, var70, var71, var72, var73, var74, var75, var76, var77, var78, var79, var80, var81, var82, var83, var84, var85, var86, var87, var88, var89, var90, var91, var92, var93, var94, var95, var96, var97, var98, var99, var100, var101, var102, var103, var104, var105, var106, var107, var108, var109, var110, var111, var112, var113, var114, var115, var116, var117, var118, var119, var120, var121, var122, var123, var124, var125, var126, var127, var128, var129, var130, var131, var132, var133, var134, var135, var136, var137, var138, var139, var140, var141, var142, var143, var144, var145, var146, var147, var148, var149, var150, var151, var152, var153, var154, var155, var156, var157, var158, var159, var160, var161, var162, var163, var164, var165, var166, var167, var168, var169, var170, var171, var172, var173, var174, var175, var176, var177, var178, var179, var180, var181, var182, var183, var184, var185, var186, var187, var188, var189, var190, var191, var192, var193, var194, var195, var196, var197, var198, var199;

   var2 = 5;
   var2[0] = (float)6;
   var2[1] = (float)9;
   var2[2] = 13.5f;
   var2[3] = (float)16;
   var2[4] = (float)15;
   var8 = 5;
   var8[0 * 3].v0 = -3029.43f;
   var8[0 * 3].v1 = -19.7345f;
   var8[0 * 3].v2 = 562.723f;
   var8[1 * 3].v0 = -3295.01f;
   var8[1 * 3].v1 = -31.0527f;
   var8[1 * 3].v2 = 561.704f;
   var8[2 * 3].v0 = -3257.47f;
   var8[2 * 3].v1 = -19.7348f;
   var8[2 * 3].v2 = 561.351f;
   var8[3 * 3].v0 = -3087.92f;
   var8[3 * 3].v1 = -27.9071f;
   var8[3 * 3].v2 = 836.871f;
   var8[4 * 3].v0 = -3086.66f;
   var8[4 * 3].v1 = -25.8274f;
   var8[4 * 3].v2 = 319.607f;
   var24 = 5;
   var24[0 * 3].v0 = -3029.43f;
   var24[0 * 3].v1 = -19.7345f;
   var24[0 * 3].v2 = 548.019f;
   var24[1 * 3].v0 = -3295.01f;
   var24[1 * 3].v1 = -31.0096f;
   var24[1 * 3].v2 = 531.678f;
   var24[2 * 3].v0 = -3257.47f;
   var24[2 * 3].v1 = -19.7347f;
   var24[2 * 3].v2 = 534.022f;
   var24[3 * 3].v0 = (float)0;
   var24[3 * 3].v1 = (float)0;
   var24[3 * 3].v2 = (float)0;
   var24[4 * 3].v0 = (float)0;
   var24[4 * 3].v1 = (float)0;
   var24[4 * 3].v2 = (float)0;
   var40 = 16;
   var40[0 * 3].v0 = -3081.33f;
   var40[0 * 3].v1 = -24.6831f;
   var40[0 * 3].v2 = 248.571f;
   var40[1 * 3].v0 = -3076.33f;
   var40[1 * 3].v1 = -24.6831f;
   var40[1 * 3].v2 = 248.613f;
   var40[2 * 3].v0 = -3085.83f;
   var40[2 * 3].v1 = -24.6831f;
   var40[2 * 3].v2 = 248.533f;
   var40[3 * 3].v0 = -3071.83f;
   var40[3 * 3].v1 = -24.6831f;
   var40[3 * 3].v2 = 248.65f;
   var40[4 * 3].v0 = -3076.26f;
   var40[4 * 3].v1 = -24.6831f;
   var40[4 * 3].v2 = 240.113f;
   var40[5 * 3].v0 = -3085.76f;
   var40[5 * 3].v1 = -24.6831f;
   var40[5 * 3].v2 = 240.033f;
   var40[6 * 3].v0 = -3071.76f;
   var40[6 * 3].v1 = -24.6831f;
   var40[6 * 3].v2 = 240.151f;
   var40[7 * 3].v0 = -3081.26f;
   var40[7 * 3].v1 = -24.6831f;
   var40[7 * 3].v2 = 240.071f;
   var40[8 * 3].v0 = -3076.19f;
   var40[8 * 3].v1 = -24.6831f;
   var40[8 * 3].v2 = 231.613f;
   var40[9 * 3].v0 = -3085.68f;
   var40[9 * 3].v1 = -24.6831f;
   var40[9 * 3].v2 = 231.533f;
   var40[10 * 3].v0 = -3081.19f;
   var40[10 * 3].v1 = -24.6831f;
   var40[10 * 3].v2 = 231.571f;
   var40[11 * 3].v0 = -3071.69f;
   var40[11 * 3].v1 = -24.6831f;
   var40[11 * 3].v2 = 231.651f;
   var40[12 * 3].v0 = -3076.11f;
   var40[12 * 3].v1 = -24.6831f;
   var40[12 * 3].v2 = 223.114f;
   var40[13 * 3].v0 = -3085.61f;
   var40[13 * 3].v1 = -24.6831f;
   var40[13 * 3].v2 = 223.034f;
   var40[14 * 3].v0 = -3071.61f;
   var40[14 * 3].v1 = -24.6831f;
   var40[14 * 3].v2 = 223.151f;
   var40[15 * 3].v0 = -3081.11f;
   var40[15 * 3].v1 = -24.6831f;
   var40[15 * 3].v2 = 223.072f;
   var89 = 16;
   var89[0] = 179.518f;
   var89[1] = 179.518f;
   var89[2] = 179.518f;
   var89[3] = 179.518f;
   var89[4] = 179.518f;
   var89[5] = 179.518f;
   var89[6] = 179.518f;
   var89[7] = 179.518f;
   var89[8] = 179.518f;
   var89[9] = 179.518f;
   var89[10] = 179.518f;
   var89[11] = 179.518f;
   var89[12] = 179.518f;
   var89[13] = 179.518f;
   var89[14] = 179.518f;
   var89[15] = 179.518f;
   var106 = 16;
   var106[0 * 3].v0 = -3084.7f;
   var106[0 * 3].v1 = -28.6472f;
   var106[0 * 3].v2 = 908.929f;
   var106[1 * 3].v0 = -3089.7f;
   var106[1 * 3].v1 = -28.6472f;
   var106[1 * 3].v2 = 908.929f;
   var106[2 * 3].v0 = -3080.2f;
   var106[2 * 3].v1 = -28.6472f;
   var106[2 * 3].v2 = 908.929f;
   var106[3 * 3].v0 = -3094.2f;
   var106[3 * 3].v1 = -28.6472f;
   var106[3 * 3].v2 = 908.929f;
   var106[4 * 3].v0 = -3089.7f;
   var106[4 * 3].v1 = -28.6472f;
   var106[4 * 3].v2 = 917.429f;
   var106[5 * 3].v0 = -3080.2f;
   var106[5 * 3].v1 = -28.6472f;
   var106[5 * 3].v2 = 917.429f;
   var106[6 * 3].v0 = -3094.2f;
   var106[6 * 3].v1 = -28.6472f;
   var106[6 * 3].v2 = 917.429f;
   var106[7 * 3].v0 = -3084.7f;
   var106[7 * 3].v1 = -28.6472f;
   var106[7 * 3].v2 = 917.429f;
   var106[8 * 3].v0 = -3089.7f;
   var106[8 * 3].v1 = -28.6472f;
   var106[8 * 3].v2 = 925.929f;
   var106[9 * 3].v0 = -3080.2f;
   var106[9 * 3].v1 = -28.6472f;
   var106[9 * 3].v2 = 925.929f;
   var106[10 * 3].v0 = -3084.7f;
   var106[10 * 3].v1 = -28.6472f;
   var106[10 * 3].v2 = 925.929f;
   var106[11 * 3].v0 = -3094.2f;
   var106[11 * 3].v1 = -28.6472f;
   var106[11 * 3].v2 = 925.929f;
   var106[12 * 3].v0 = -3089.7f;
   var106[12 * 3].v1 = -28.6472f;
   var106[12 * 3].v2 = 934.429f;
   var106[13 * 3].v0 = -3080.2f;
   var106[13 * 3].v1 = -28.6472f;
   var106[13 * 3].v2 = 934.429f;
   var106[14 * 3].v0 = -3094.2f;
   var106[14 * 3].v1 = -28.6472f;
   var106[14 * 3].v2 = 934.429f;
   var106[15 * 3].v0 = -3084.7f;
   var106[15 * 3].v1 = -28.6472f;
   var106[15 * 3].v2 = 934.429f;
   var155 = 16;
   var155[0] = (float)0;
   var155[1] = (float)0;
   var155[2] = (float)0;
   var155[3] = (float)0;
   var155[4] = (float)0;
   var155[5] = (float)0;
   var155[6] = (float)0;
   var155[7] = (float)0;
   var155[8] = (float)0;
   var155[9] = (float)0;
   var155[10] = (float)0;
   var155[11] = (float)0;
   var155[12] = (float)0;
   var155[13] = (float)0;
   var155[14] = (float)0;
   var155[15] = (float)0;
   var172 = 4;
   var172[0 * 3].v0 = -3079.3f;
   var172[0 * 3].v1 = -24.679f;
   var172[0 * 3].v2 = 244.334f;
   var172[1 * 3].v0 = -3079.3f;
   var172[1 * 3].v1 = -24.679f;
   var172[1 * 3].v2 = 244.334f;
   var172[2 * 3].v0 = -3087.18f;
   var172[2 * 3].v1 = -28.7131f;
   var172[2 * 3].v2 = 912.67f;
   var172[3 * 3].v0 = -3087.18f;
   var172[3 * 3].v1 = -28.7131f;
   var172[3 * 3].v2 = 912.67f;
   var185 = 4;
   var185[0] = "PickUp";
   var185[1] = "DropOff";
   var185[2] = "PickUp";
   var185[3] = "DropOff";
   var190 = 4;
   var190[0] = 2;
   var190[1] = 2;
   var190[2] = 1;
   var190[3] = 1;
   var195 = 0;
   var196 = Ctf_GetMap(L[0].v801);
   CtfMap_Init(var196, 2, 2);
   var195 = 0;
   while (var195 < 4)
   {
       CtfMap_AddItem(var196, var185[var195], &(var172[var195 * 3]), var190[var195]);
       var195 = var195 + 1;
   }
   var197 = 0;
   var198 = Race_GetRaceGrid(L[0].v3, 0);
   var199 = Race_GetRaceGrid(L[0].v3, 1);
   var197 = 0;
   while (var197 < 16)
   {
       RaceGrid_SetPosition(var198, var197, &(var40[var197 * 3]), var89[var197]);
       RaceGrid_SetPosition(var199, var197, &(var106[var197 * 3]), var155[var197]);
       var197 = var197 + 1;
   }
   L[0].v2 = PickUpManager_CreatePowerUpSources(5);
   var195 = 0;
   while (var195 < 5)
   {
       PickUpManager_AddPowerUpSource(L[0].v2, &(var8[var195 * 3]), var2[var195], &(var24[var195 * 3]));
       var195 = var195 + 1;
   }
   sub_839(&L[0]);
}

void sub_839(var0)
{
   auto var3, var4, var5, var6, var7, var8, var9, var10, var11, var12, var13, var14, var15, var16;

   var8.v0 = (float)0;
   var8.v1 = (float)1;
   var8.v2 = (float)0;
   var11.v0 = (float)0;
   var11.v1 = (float)0;
   var11.v2 = (float)-1;
   RaceGrid_GetPosition(Race_GetRaceGrid(*(var0 + 12), 0), 0, &var4, &var7);
   Math_VecRotateY(&var11, &var11, var7);
   var11.v0 = var4.v0 + var11.v0;
   var11.v1 = var4.v1 + var11.v1;
   var11.v2 = var4.v2 + var11.v2;
   var8.v0 = var4.v0 + var8.v0;
   var8.v1 = var4.v1 + var8.v1;
   var8.v2 = var4.v2 + var8.v2;
   UILogic_LockStreaming(&var4, &var8, &var11);
   var3 = 0;
   while (var3 < *((var0 + 16) + 3080))
   {
       Racer_SetStreamingLockedIn((*((var0 + 16) + 4))[var3 * 48].v0);
       var3 = var3 + 1;
   }
   var14 = 1;
   while (var14 > 0)
   {
       var14 = *((var0 + 16) + 3080);
       var3 = 0;
       while (var3 < *((var0 + 16) + 3080))
       {
           if (Racer_IsSimStreamed((*((var0 + 16) + 4))[var3 * 48].v0))
           {
               var14 = var14 - 1;
           }
           var3 = var3 + 1;
       }
       if (var14 > 0)
       {
           if (!*((var0 + 16) + 3132))
           {
               sub_950(1, 0, 0x3f800000, 0);
           }
           WAIT(100);
       }
   }
   while (OpponentManager_StillStreamingOut())
   {
       WAIT(30);
   }
   var3 = 0;
   while (var3 < *((var0 + 16) + 3080))
   {
       if ((*((var0 + 16) + 4))[var3 * 48].v2 == 2)
       {
           PRINTSTRING(" BRAIN CREATED!");
           (*((var0 + 16) + 4))[var3 * 48].v3 = BrainFactory_CreateBrainRacing((*((var0 + 16) + 4))[var3 * 48].v0);
       }
       var3 = var3 + 1;
   }
   var15 = START_NEW_SCRIPT_WITH_ARGS("game/racetypes/BaseWarCore", var0, 802, 1500);
   while (!IsChildFinished(var15))
   {
       WAIT(30);
   }
   var3 = 0;
   while (var3 < *((var0 + 16) + 3080))
   {
       if ((*((var0 + 16) + 4))[var3 * 48].v2 == 2)
       {
           BrainFactory_DeleteBrain((*((var0 + 16) + 4))[var3 * 48].v0);
       }
       var3 = var3 + 1;
   }
}

void sub_950(var0, var1, var2, var3)
{
   auto var6, var7, var8, var9, var10, var11, var12, var13;

   var6 = null;
   while (var6 == null)
   {
       var6 = UIManager_FindMovie("TRANSITIONMOVIE");
       if (var6 == null)
       {
           PRINTSTRING("SCRIPT: waiting for transition movie to stream in...\n");
           WAITUNWARPED(10);
       }
   }
   var7 = 0;
   var8 = 0;
   var9 = 0;
   FlashHelper_GetGlobalInt(var6, "StartOfTransitionout", &var7);
   FlashHelper_GetGlobalInt(var6, "StartOfTransitionin", &var8);
   FlashHelper_GetGlobalInt(var6, "TransitionOutisReady", &var9);
   PRINTSTRING("FADE DOWN REPORT\n");
   PRINTSTRING("================\n");
   PRINTSTRING("TransitionOut: ");
   PRINTINT(var7);
   PRINTSTRING("\nTransitionIn: ");
   PRINTINT(var8);
   PRINTSTRING("\nnTransitionReady: ");
   PRINTINT(var9);
   PRINTSTRING("\n");
   if ((var8 == 0) && ((var9 == 0) || ((var7 == 1) && (var9 == 2))))
   {
       FlashHelper_SetMovieEnabled(var6, 1);
       FlashHelper_SetGlobalInt(var6, "cur_visibility", 1);
       FlashHelper_SetGlobalInt(var6, "mask_color", var3);
       if (var1)
       {
           FlashHelper_SetGlobalInt(var6, "transition_type", 0);
       }
       else
       {
           FlashHelper_SetGlobalInt(var6, "transition_type", 1);
       }
       FlashHelper_SetGlobalFloat(var6, "fade_speed_in", var2);
       FlashHelper_SetGlobalFloat(var6, "fade_speed_out", 0.01f);
       FlashHelper_SetGlobalInt(var6, "StartOfTransitionout", 0);
       FlashHelper_SetGlobalInt(var6, "TransitionOutisReady", 0);
       FlashHelper_SetGlobalInt(var6, "StartOfTransitionin", 1);
       if (var0)
       {
           var8 = 1;
           while (var8 == 1)
           {
               FlashHelper_GetGlobalInt(var6, "StartOfTransitionin", &var8);
               if (var8 == 1)
               {
                   WAITUNWARPED(10);
               }
           }
       }
   }
}

