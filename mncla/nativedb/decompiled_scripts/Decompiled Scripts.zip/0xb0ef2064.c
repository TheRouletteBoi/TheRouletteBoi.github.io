﻿void main()
{
   auto var2, var3, var4, var5, var6, var7, var8, var9, var10, var11, var12, var13, var14, var15, var16, var17, var18, var19, var20, var21, var22, var23, var24, var25, var26, var27, var28, var29, var30, var31, var32, var33, var34, var35, var36, var37, var38, var39, var40, var41, var42, var43, var44, var45, var46, var47, var48, var49, var50, var51, var52, var53, var54, var55, var56, var57, var58, var59, var60, var61, var62, var63, var64, var65, var66, var67, var68, var69, var70, var71, var72, var73, var74, var75, var76, var77, var78, var79, var80, var81, var82, var83, var84, var85, var86, var87, var88, var89, var90, var91, var92, var93, var94, var95, var96, var97;

   var2 = 17;
   var2[0 * 3].v0 = -621.94f;
   var2[0 * 3].v1 = 9.98f;
   var2[0 * 3].v2 = -481.06f;
   var2[1 * 3].v0 = -609.77f;
   var2[1 * 3].v1 = 1.99f;
   var2[1 * 3].v2 = -173.25f;
   var2[2 * 3].v0 = -590.93f;
   var2[2 * 3].v1 = -6.03f;
   var2[2 * 3].v2 = 142.0f;
   var2[3 * 3].v0 = -678.0f;
   var2[3 * 3].v1 = -10.03f;
   var2[3 * 3].v2 = 372.81f;
   var2[4 * 3].v0 = -971.99f;
   var2[4 * 3].v1 = -4.09f;
   var2[4 * 3].v2 = 376.06f;
   var2[5 * 3].v0 = -1022.38f;
   var2[5 * 3].v1 = -7.14f;
   var2[5 * 3].v2 = 168.81f;
   var2[6 * 3].v0 = -849.02f;
   var2[6 * 3].v1 = -9.98f;
   var2[6 * 3].v2 = 167.11f;
   var2[7 * 3].v0 = -611.87f;
   var2[7 * 3].v1 = -6.03f;
   var2[7 * 3].v2 = 174.78f;
   var2[8 * 3].v0 = -448.49f;
   var2[8 * 3].v1 = -11.72f;
   var2[8 * 3].v2 = 172.97f;
   var2[9 * 3].v0 = -441.57f;
   var2[9 * 3].v1 = -3.02f;
   var2[9 * 3].v2 = -5.27f;
   var2[10 * 3].v0 = -333.78f;
   var2[10 * 3].v1 = 2.03f;
   var2[10 * 3].v2 = -239.47f;
   var2[11 * 3].v0 = -362.08f;
   var2[11 * 3].v1 = 7.9f;
   var2[11 * 3].v2 = -490.15f;
   var2[12 * 3].v0 = -486.38f;
   var2[12 * 3].v1 = 25.97f;
   var2[12 * 3].v2 = -749.29f;
   var2[13 * 3].v0 = -706.41f;
   var2[13 * 3].v1 = 29.06f;
   var2[13 * 3].v2 = -782.9f;
   var2[14 * 3].v0 = -985.39f;
   var2[14 * 3].v1 = 33.02f;
   var2[14 * 3].v2 = -788.18f;
   var2[15 * 3].v0 = -1061.54f;
   var2[15 * 3].v1 = 9.99f;
   var2[15 * 3].v2 = -553.26f;
   var2[16 * 3].v0 = -1079.89f;
   var2[16 * 3].v1 = 3.01f;
   var2[16 * 3].v2 = -218.27f;
   var54 = 17;
   var54[0] = 30.0f;
   var54[1] = 30.0f;
   var54[2] = 30.0f;
   var54[3] = 30.0f;
   var54[4] = 30.0f;
   var54[5] = 30.0f;
   var54[6] = 30.0f;
   var54[7] = 30.0f;
   var54[8] = 30.0f;
   var54[9] = 30.0f;
   var54[10] = 30.0f;
   var54[11] = 30.0f;
   var54[12] = 30.0f;
   var54[13] = 30.0f;
   var54[14] = 30.0f;
   var54[15] = 30.0f;
   var54[16] = 30.0f;
   var72 = 5;
   var72[0 * 3].v0 = -619.62f;
   var72[0 * 3].v1 = 17.96f;
   var72[0 * 3].v2 = -661.85f;
   var72[1 * 3].v0 = -623.62f;
   var72[1 * 3].v1 = 17.96f;
   var72[1 * 3].v2 = -661.85f;
   var72[2 * 3].v0 = -627.62f;
   var72[2 * 3].v1 = 17.96f;
   var72[2 * 3].v2 = -661.85f;
   var72[3 * 3].v0 = -615.62f;
   var72[3 * 3].v1 = 17.96f;
   var72[3 * 3].v2 = -661.85f;
   var72[4 * 3].v0 = -611.62f;
   var72[4 * 3].v1 = 17.96f;
   var72[4 * 3].v2 = -661.85f;
   var88 = 5;
   var88[0] = (float)177;
   var88[1] = (float)177;
   var88[2] = (float)177;
   var88[3] = (float)177;
   var88[4] = (float)177;
   var94 = Race_GetCheckpointList(L[0].v3);
   CheckpointList_ResizeList(var94, 17);
   var96 = null;
   var95 = 0;
   while (var95 < 17)
   {
       var96 = CheckpointList_GetCheckpoint(var94, var95);
       Checkpoint_SetPosition(var96, &(var2[var95 * 3]));
       Checkpoint_SetActivationRadius(var96, var54[var95]);
       var95 = var95 + 1;
   }
   var97 = Race_GetRaceGrid(L[0].v3, 0);
   var95 = 0;
   while (var95 < 5)
   {
       RaceGrid_SetPosition(var97, var95, &(var72[var95 * 3]), var88[var95]);
       var95 = var95 + 1;
   }
   L[0].v4.v770 = 5;
   sub_438(&L[0]);
}

void sub_438(var0)
{
   auto var3, var4, var5, var6, var7, var8, var9, var10, var11, var12, var13, var14, var15, var16;

   PRINTSTRING("LOADING RACE with ");
   PRINTINT(*((var0 + 16) + 3080));
   PRINTSTRING(" racers\n");
   var8.v0 = (float)0;
   var8.v1 = (float)1;
   var8.v2 = (float)0;
   var11.v0 = (float)0;
   var11.v1 = (float)0;
   var11.v2 = (float)-1;
   RaceGrid_GetPosition(Race_GetRaceGrid(*(var0 + 12), 0), 0, &var4, &var7);
   Math_VecRotateY(&var11, &var11, var7);
   var11.v0 = var4.v0 + var11.v0;
   var11.v1 = var4.v1 + var11.v1;
   var11.v2 = var4.v2 + var11.v2;
   var8.v0 = var4.v0 + var8.v0;
   var8.v1 = var4.v1 + var8.v1;
   var8.v2 = var4.v2 + var8.v2;
   UILogic_LockStreaming(&var4, &var8, &var11);
   var3 = 0;
   while (var3 < *((var0 + 16) + 3080))
   {
       PRINTSTRING("Racer - ");
       PRINTINT(var3);
       PRINTSTRING("\n");
       Racer_SetStreamingLockedIn((*((var0 + 16) + 4))[var3 * 48].v0);
       var3 = var3 + 1;
   }
   var14 = 1;
   while (var14 > 0)
   {
       var14 = *((var0 + 16) + 3080);
       var3 = 0;
       while (var3 < *((var0 + 16) + 3080))
       {
           if (Racer_IsCarStreamed((*((var0 + 16) + 4))[var3 * 48].v0))
           {
               var14 = var14 - 1;
           }
           var3 = var3 + 1;
       }
       if (var14 > 0)
       {
           WAITUNWARPED(30);
       }
   }
   while (!PoliceManager_IsAllStreamedIn())
   {
       WAITUNWARPED(30);
   }
   while (OpponentManager_StillStreamingOut())
   {
       WAITUNWARPED(30);
   }
   var3 = 0;
   while (var3 < *((var0 + 16) + 3080))
   {
       if ((*((var0 + 16) + 4))[var3 * 48].v2 == 2)
       {
           PRINTSTRING(" BRAIN CREATED! \n");
           (*((var0 + 16) + 4))[var3 * 48].v3 = BrainFactory_CreateBrainRacing((*((var0 + 16) + 4))[var3 * 48].v0);
       }
       var3 = var3 + 1;
   }
   var15 = START_NEW_SCRIPT_WITH_ARGS("Game/RaceTypes/OrderedCheckpointCore", var0, 802, 3800);
   while (!IsChildFinished(var15))
   {
       WAITUNWARPED(30);
   }
   var3 = 0;
   while (var3 < *((var0 + 16) + 3080))
   {
       if ((*((var0 + 16) + 4))[var3 * 48].v2 == 2)
       {
           BrainFactory_DeleteBrain((*((var0 + 16) + 4))[var3 * 48].v0);
       }
       var3 = var3 + 1;
   }
}

