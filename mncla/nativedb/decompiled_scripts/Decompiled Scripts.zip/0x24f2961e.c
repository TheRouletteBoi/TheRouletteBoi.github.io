﻿void main()
{
   auto var2, var3, var4, var5, var6, var7, var8, var9, var10, var11, var12, var13, var14, var15, var16, var17, var18, var19, var20, var21, var22, var23, var24, var25, var26, var27, var28, var29, var30, var31, var32, var33, var34, var35, var36, var37, var38, var39, var40, var41, var42, var43, var44, var45, var46, var47, var48, var49, var50, var51, var52, var53, var54, var55, var56, var57, var58, var59, var60, var61, var62, var63, var64, var65, var66, var67, var68, var69, var70, var71, var72, var73, var74, var75, var76, var77, var78, var79, var80, var81, var82, var83, var84, var85, var86, var87, var88, var89, var90, var91, var92, var93, var94, var95, var96, var97, var98, var99, var100, var101, var102, var103, var104, var105, var106, var107, var108, var109, var110, var111, var112, var113, var114, var115, var116, var117, var118, var119, var120, var121, var122, var123, var124, var125, var126, var127, var128, var129, var130, var131, var132, var133, var134, var135, var136, var137, var138, var139, var140, var141, var142, var143, var144, var145, var146, var147, var148, var149, var150, var151, var152, var153, var154, var155, var156, var157, var158, var159, var160, var161, var162, var163, var164, var165, var166, var167, var168, var169, var170, var171, var172, var173, var174, var175, var176, var177, var178, var179, var180, var181, var182, var183, var184, var185, var186, var187, var188, var189, var190, var191, var192, var193, var194, var195, var196, var197, var198, var199, var200, var201, var202, var203, var204, var205, var206, var207, var208, var209, var210, var211, var212, var213, var214, var215, var216, var217, var218, var219, var220, var221, var222, var223, var224, var225, var226, var227, var228, var229, var230, var231, var232, var233, var234, var235, var236, var237, var238, var239, var240, var241, var242, var243, var244, var245, var246, var247, var248, var249, var250, var251, var252, var253, var254, var255, var256, var257, var258, var259, var260, var261, var262, var263, var264, var265, var266, var267, var268, var269, var270, var271, var272, var273, var274, var275, var276, var277, var278, var279, var280, var281, var282, var283, var284, var285, var286, var287, var288, var289, var290, var291, var292, var293, var294, var295, var296, var297, var298, var299, var300, var301, var302, var303, var304, var305, var306, var307, var308, var309, var310, var311, var312, var313, var314, var315, var316, var317, var318, var319, var320, var321, var322, var323, var324, var325, var326, var327, var328, var329, var330, var331, var332, var333, var334, var335, var336, var337, var338, var339, var340, var341, var342, var343, var344, var345, var346, var347, var348, var349, var350, var351, var352;

   var2 = "game/cinescripts/source/core_rolling_prototype";
   var3 = 10;
   var14.v5 = 20;
   var14.v5.v127 = 10;
   var14.v5.v127.v179 = 20;
   var14.v1 = "cutscene/hangout/cut_hangout_08_ent_02";
   var14.v2 = "";
   CineScript_SetSceneName("hangout/cut_hangout_08_ent_02");
   CineScript_RequestPreraceTauntScenarioAudio("hangout/cut_hangout_08_ent_02");
   CineScript_UseRacerNativeCharacter(0);
   var14.v321 = 1;
   var14.v322 = 0;
   var14.v323 = 0;
   var14.v4 = 0;
   var350 = Player_FindObject(0);
   var344 = Player_GetRacer(var350);
   var14.v127[0 * 5].v1 = var344;
   var14.v127[0 * 5].v0 = "mover_drv00_car";
   var14.v127[0 * 5].v2 = 1;
   var14.v127[0 * 5].v4 = "mover_drv00_car";
   var14.v127[0 * 5].v3 = "cutscene/hangout/cut_hangout_08_ent_02/Entity/mover_drv00_car";
   var3[0] = Racer_GetStreamLockState(var344);
   Racer_SetStreamingLockedIn(var344);
   var14.v126 = 1;
   var14.v178 = 0;
   var351 = START_NEW_SCRIPT_WITH_ARGS(var2, &var14, 324, 0);
   while (!IsChildFinished(var351))
   {
       WAIT(10);
   }
   var352 = 0;
   while (var352 < var14.v126)
   {
       Racer_SetStreamLockState(var14.v127[var352 * 5].v1, var3[var352]);
       var352 = var352 + 1;
   }
   sub_273(L[0]);
}

void sub_273(var0)
{
   auto var3;

   var0.v0 = 3;
}

