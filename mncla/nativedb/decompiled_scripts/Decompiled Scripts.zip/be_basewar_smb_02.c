﻿void main()
{
   auto var2, var3, var4, var5, var6, var7, var8, var9, var10, var11, var12, var13, var14, var15, var16, var17, var18, var19, var20, var21, var22, var23, var24, var25, var26, var27, var28, var29, var30, var31, var32, var33, var34, var35, var36, var37, var38, var39, var40, var41, var42, var43, var44, var45, var46, var47, var48, var49, var50, var51, var52, var53, var54, var55, var56, var57, var58, var59, var60, var61, var62, var63, var64, var65, var66, var67, var68, var69, var70, var71, var72, var73, var74, var75, var76, var77, var78, var79, var80, var81, var82, var83, var84, var85, var86, var87, var88, var89, var90, var91, var92, var93, var94, var95, var96, var97, var98, var99, var100, var101, var102, var103, var104, var105, var106, var107, var108, var109, var110, var111, var112, var113, var114, var115, var116, var117, var118, var119, var120, var121, var122, var123, var124, var125, var126, var127, var128, var129, var130, var131, var132, var133, var134, var135, var136, var137, var138, var139, var140, var141, var142, var143, var144, var145, var146, var147, var148, var149, var150, var151, var152, var153, var154, var155, var156, var157, var158, var159, var160, var161, var162, var163, var164, var165, var166, var167, var168, var169, var170, var171, var172, var173, var174, var175, var176, var177, var178, var179, var180, var181, var182, var183, var184, var185, var186, var187, var188, var189, var190, var191, var192, var193, var194, var195, var196, var197, var198, var199;

   var2 = 5;
   var2[0] = 14.5f;
   var2[1] = 12.5f;
   var2[2] = (float)18;
   var2[3] = (float)11;
   var2[4] = (float)12;
   var8 = 5;
   var8[0 * 3].v0 = -3051.05f;
   var8[0 * 3].v1 = -28.169f;
   var8[0 * 3].v2 = -371.223f;
   var8[1 * 3].v0 = -2960.81f;
   var8[1 * 3].v1 = -24.8815f;
   var8[1 * 3].v2 = -323.23f;
   var8[2 * 3].v0 = -2886.98f;
   var8[2 * 3].v1 = -4.57224f;
   var8[2 * 3].v2 = -260.014f;
   var8[3 * 3].v0 = -3004.48f;
   var8[3 * 3].v1 = -25.0561f;
   var8[3 * 3].v2 = 271.524f;
   var8[4 * 3].v0 = -2766.35f;
   var8[4 * 3].v1 = -29.7876f;
   var8[4 * 3].v2 = -802.57f;
   var24 = 5;
   var24[0 * 3].v0 = (float)0;
   var24[0 * 3].v1 = (float)0;
   var24[0 * 3].v2 = (float)0;
   var24[1 * 3].v0 = -2940.76f;
   var24[1 * 3].v1 = -25.4047f;
   var24[1 * 3].v2 = -353.786f;
   var24[2 * 3].v0 = (float)0;
   var24[2 * 3].v1 = (float)0;
   var24[2 * 3].v2 = (float)0;
   var24[3 * 3].v0 = (float)0;
   var24[3 * 3].v1 = (float)0;
   var24[3 * 3].v2 = (float)0;
   var24[4 * 3].v0 = (float)0;
   var24[4 * 3].v1 = (float)0;
   var24[4 * 3].v2 = (float)0;
   var40 = 16;
   var40[0 * 3].v0 = -2800.24f;
   var40[0 * 3].v1 = -29.2942f;
   var40[0 * 3].v2 = -740.444f;
   var40[1 * 3].v0 = -2795.75f;
   var40[1 * 3].v1 = -29.2942f;
   var40[1 * 3].v2 = -738.231f;
   var40[2 * 3].v0 = -2804.27f;
   var40[2 * 3].v1 = -29.2942f;
   var40[2 * 3].v2 = -742.435f;
   var40[3 * 3].v0 = -2791.72f;
   var40[3 * 3].v1 = -29.2942f;
   var40[3 * 3].v2 = -736.24f;
   var40[4 * 3].v0 = -2791.99f;
   var40[4 * 3].v1 = -29.2942f;
   var40[4 * 3].v2 = -745.854f;
   var40[5 * 3].v0 = -2800.51f;
   var40[5 * 3].v1 = -29.2942f;
   var40[5 * 3].v2 = -750.058f;
   var40[6 * 3].v0 = -2787.96f;
   var40[6 * 3].v1 = -29.2942f;
   var40[6 * 3].v2 = -743.862f;
   var40[7 * 3].v0 = -2796.48f;
   var40[7 * 3].v1 = -29.2942f;
   var40[7 * 3].v2 = -748.066f;
   var40[8 * 3].v0 = -2788.23f;
   var40[8 * 3].v1 = -29.2942f;
   var40[8 * 3].v2 = -753.476f;
   var40[9 * 3].v0 = -2796.75f;
   var40[9 * 3].v1 = -29.2942f;
   var40[9 * 3].v2 = -757.68f;
   var40[10 * 3].v0 = -2792.72f;
   var40[10 * 3].v1 = -29.2942f;
   var40[10 * 3].v2 = -755.689f;
   var40[11 * 3].v0 = -2784.2f;
   var40[11 * 3].v1 = -29.2942f;
   var40[11 * 3].v2 = -751.485f;
   var40[12 * 3].v0 = -2784.47f;
   var40[12 * 3].v1 = -29.2942f;
   var40[12 * 3].v2 = -761.099f;
   var40[13 * 3].v0 = -2792.99f;
   var40[13 * 3].v1 = -29.2942f;
   var40[13 * 3].v2 = -765.302f;
   var40[14 * 3].v0 = -2780.43f;
   var40[14 * 3].v1 = -29.2942f;
   var40[14 * 3].v2 = -759.107f;
   var40[15 * 3].v0 = -2788.95f;
   var40[15 * 3].v1 = -29.2942f;
   var40[15 * 3].v2 = -763.311f;
   var89 = 16;
   var89[0] = 153.735f;
   var89[1] = 153.735f;
   var89[2] = 153.735f;
   var89[3] = 153.735f;
   var89[4] = 153.735f;
   var89[5] = 153.735f;
   var89[6] = 153.735f;
   var89[7] = 153.735f;
   var89[8] = 153.735f;
   var89[9] = 153.735f;
   var89[10] = 153.735f;
   var89[11] = 153.735f;
   var89[12] = 153.735f;
   var89[13] = 153.735f;
   var89[14] = 153.735f;
   var89[15] = 153.735f;
   var106 = 16;
   var106[0 * 3].v0 = -3019.2f;
   var106[0 * 3].v1 = -24.7907f;
   var106[0 * 3].v2 = 218.026f;
   var106[1 * 3].v0 = -3024.07f;
   var106[1 * 3].v1 = -24.7907f;
   var106[1 * 3].v2 = 219.141f;
   var106[2 * 3].v0 = -3014.81f;
   var106[2 * 3].v1 = -24.7907f;
   var106[2 * 3].v2 = 217.022f;
   var106[3 * 3].v0 = -3028.46f;
   var106[3 * 3].v1 = -24.7907f;
   var106[3 * 3].v2 = 220.145f;
   var106[4 * 3].v0 = -3022.18f;
   var106[4 * 3].v1 = -24.7907f;
   var106[4 * 3].v2 = 227.427f;
   var106[5 * 3].v0 = -3012.92f;
   var106[5 * 3].v1 = -24.7907f;
   var106[5 * 3].v2 = 225.307f;
   var106[6 * 3].v0 = -3026.56f;
   var106[6 * 3].v1 = -24.7907f;
   var106[6 * 3].v2 = 228.431f;
   var106[7 * 3].v0 = -3017.3f;
   var106[7 * 3].v1 = -24.7907f;
   var106[7 * 3].v2 = 226.311f;
   var106[8 * 3].v0 = -3020.28f;
   var106[8 * 3].v1 = -24.7907f;
   var106[8 * 3].v2 = 235.713f;
   var106[9 * 3].v0 = -3011.02f;
   var106[9 * 3].v1 = -24.7907f;
   var106[9 * 3].v2 = 233.593f;
   var106[10 * 3].v0 = -3015.41f;
   var106[10 * 3].v1 = -24.7907f;
   var106[10 * 3].v2 = 234.597f;
   var106[11 * 3].v0 = -3024.67f;
   var106[11 * 3].v1 = -24.7907f;
   var106[11 * 3].v2 = 236.717f;
   var106[12 * 3].v0 = -3018.38f;
   var106[12 * 3].v1 = -24.7907f;
   var106[12 * 3].v2 = 243.999f;
   var106[13 * 3].v0 = -3009.12f;
   var106[13 * 3].v1 = -24.7907f;
   var106[13 * 3].v2 = 241.879f;
   var106[14 * 3].v0 = -3022.77f;
   var106[14 * 3].v1 = -24.7907f;
   var106[14 * 3].v2 = 245.002f;
   var106[15 * 3].v0 = -3013.51f;
   var106[15 * 3].v1 = -24.7907f;
   var106[15 * 3].v2 = 242.883f;
   var155 = 16;
   var155[0] = 12.8915f;
   var155[1] = 12.8915f;
   var155[2] = 12.8915f;
   var155[3] = 12.8915f;
   var155[4] = 12.8915f;
   var155[5] = 12.8915f;
   var155[6] = 12.8915f;
   var155[7] = 12.8915f;
   var155[8] = 12.8915f;
   var155[9] = 12.8915f;
   var155[10] = 12.8915f;
   var155[11] = 12.8915f;
   var155[12] = 12.8915f;
   var155[13] = 12.8915f;
   var155[14] = 12.8915f;
   var155[15] = 12.8915f;
   var172 = 4;
   var172[0 * 3].v0 = -2795.89f;
   var172[0 * 3].v1 = -29.4435f;
   var172[0 * 3].v2 = -743.172f;
   var172[1 * 3].v0 = -2795.89f;
   var172[1 * 3].v1 = -29.4435f;
   var172[1 * 3].v2 = -743.172f;
   var172[2 * 3].v0 = -3020.47f;
   var172[2 * 3].v1 = -24.79f;
   var172[2 * 3].v2 = 222.612f;
   var172[3 * 3].v0 = -3020.47f;
   var172[3 * 3].v1 = -24.79f;
   var172[3 * 3].v2 = 222.612f;
   var185 = 4;
   var185[0] = "PickUp";
   var185[1] = "DropOff";
   var185[2] = "PickUp";
   var185[3] = "DropOff";
   var190 = 4;
   var190[0] = 2;
   var190[1] = 2;
   var190[2] = 1;
   var190[3] = 1;
   var195 = 0;
   var196 = Ctf_GetMap(L[0].v801);
   CtfMap_Init(var196, 2, 2);
   var195 = 0;
   while (var195 < 4)
   {
       CtfMap_AddItem(var196, var185[var195], &(var172[var195 * 3]), var190[var195]);
       var195 = var195 + 1;
   }
   var197 = 0;
   var198 = Race_GetRaceGrid(L[0].v3, 0);
   var199 = Race_GetRaceGrid(L[0].v3, 1);
   var197 = 0;
   while (var197 < 16)
   {
       RaceGrid_SetPosition(var198, var197, &(var40[var197 * 3]), var89[var197]);
       RaceGrid_SetPosition(var199, var197, &(var106[var197 * 3]), var155[var197]);
       var197 = var197 + 1;
   }
   L[0].v2 = PickUpManager_CreatePowerUpSources(5);
   var195 = 0;
   while (var195 < 5)
   {
       PickUpManager_AddPowerUpSource(L[0].v2, &(var8[var195 * 3]), var2[var195], &(var24[var195 * 3]));
       var195 = var195 + 1;
   }
   sub_86d(&L[0]);
}

void sub_86d(var0)
{
   auto var3, var4, var5, var6, var7, var8, var9, var10, var11, var12, var13, var14, var15, var16;

   var8.v0 = (float)0;
   var8.v1 = (float)1;
   var8.v2 = (float)0;
   var11.v0 = (float)0;
   var11.v1 = (float)0;
   var11.v2 = (float)-1;
   RaceGrid_GetPosition(Race_GetRaceGrid(*(var0 + 12), 0), 0, &var4, &var7);
   Math_VecRotateY(&var11, &var11, var7);
   var11.v0 = var4.v0 + var11.v0;
   var11.v1 = var4.v1 + var11.v1;
   var11.v2 = var4.v2 + var11.v2;
   var8.v0 = var4.v0 + var8.v0;
   var8.v1 = var4.v1 + var8.v1;
   var8.v2 = var4.v2 + var8.v2;
   UILogic_LockStreaming(&var4, &var8, &var11);
   var3 = 0;
   while (var3 < *((var0 + 16) + 3080))
   {
       Racer_SetStreamingLockedIn((*((var0 + 16) + 4))[var3 * 48].v0);
       var3 = var3 + 1;
   }
   var14 = 1;
   while (var14 > 0)
   {
       var14 = *((var0 + 16) + 3080);
       var3 = 0;
       while (var3 < *((var0 + 16) + 3080))
       {
           if (Racer_IsSimStreamed((*((var0 + 16) + 4))[var3 * 48].v0))
           {
               var14 = var14 - 1;
           }
           var3 = var3 + 1;
       }
       if (var14 > 0)
       {
           if (!*((var0 + 16) + 3132))
           {
               sub_984(1, 0, 0x3f800000, 0);
           }
           WAIT(100);
       }
   }
   while (OpponentManager_StillStreamingOut())
   {
       WAIT(30);
   }
   var3 = 0;
   while (var3 < *((var0 + 16) + 3080))
   {
       if ((*((var0 + 16) + 4))[var3 * 48].v2 == 2)
       {
           PRINTSTRING(" BRAIN CREATED!");
           (*((var0 + 16) + 4))[var3 * 48].v3 = BrainFactory_CreateBrainRacing((*((var0 + 16) + 4))[var3 * 48].v0);
       }
       var3 = var3 + 1;
   }
   var15 = START_NEW_SCRIPT_WITH_ARGS("game/racetypes/BaseWarCore", var0, 802, 1500);
   while (!IsChildFinished(var15))
   {
       WAIT(30);
   }
   var3 = 0;
   while (var3 < *((var0 + 16) + 3080))
   {
       if ((*((var0 + 16) + 4))[var3 * 48].v2 == 2)
       {
           BrainFactory_DeleteBrain((*((var0 + 16) + 4))[var3 * 48].v0);
       }
       var3 = var3 + 1;
   }
}

void sub_984(var0, var1, var2, var3)
{
   auto var6, var7, var8, var9, var10, var11, var12, var13;

   var6 = null;
   while (var6 == null)
   {
       var6 = UIManager_FindMovie("TRANSITIONMOVIE");
       if (var6 == null)
       {
           PRINTSTRING("SCRIPT: waiting for transition movie to stream in...\n");
           WAITUNWARPED(10);
       }
   }
   var7 = 0;
   var8 = 0;
   var9 = 0;
   FlashHelper_GetGlobalInt(var6, "StartOfTransitionout", &var7);
   FlashHelper_GetGlobalInt(var6, "StartOfTransitionin", &var8);
   FlashHelper_GetGlobalInt(var6, "TransitionOutisReady", &var9);
   PRINTSTRING("FADE DOWN REPORT\n");
   PRINTSTRING("================\n");
   PRINTSTRING("TransitionOut: ");
   PRINTINT(var7);
   PRINTSTRING("\nTransitionIn: ");
   PRINTINT(var8);
   PRINTSTRING("\nnTransitionReady: ");
   PRINTINT(var9);
   PRINTSTRING("\n");
   if ((var8 == 0) && ((var9 == 0) || ((var7 == 1) && (var9 == 2))))
   {
       FlashHelper_SetMovieEnabled(var6, 1);
       FlashHelper_SetGlobalInt(var6, "cur_visibility", 1);
       FlashHelper_SetGlobalInt(var6, "mask_color", var3);
       if (var1)
       {
           FlashHelper_SetGlobalInt(var6, "transition_type", 0);
       }
       else
       {
           FlashHelper_SetGlobalInt(var6, "transition_type", 1);
       }
       FlashHelper_SetGlobalFloat(var6, "fade_speed_in", var2);
       FlashHelper_SetGlobalFloat(var6, "fade_speed_out", 0.01f);
       FlashHelper_SetGlobalInt(var6, "StartOfTransitionout", 0);
       FlashHelper_SetGlobalInt(var6, "TransitionOutisReady", 0);
       FlashHelper_SetGlobalInt(var6, "StartOfTransitionin", 1);
       if (var0)
       {
           var8 = 1;
           while (var8 == 1)
           {
               FlashHelper_GetGlobalInt(var6, "StartOfTransitionin", &var8);
               if (var8 == 1)
               {
                   WAITUNWARPED(10);
               }
           }
       }
   }
}

