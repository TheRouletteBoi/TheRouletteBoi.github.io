﻿void main()
{
   auto var2, var3, var4, var5, var6, var7, var8, var9, var10, var11, var12, var13, var14, var15, var16, var17, var18, var19, var20, var21, var22, var23, var24, var25, var26, var27, var28, var29, var30, var31, var32, var33, var34, var35, var36, var37, var38, var39, var40, var41, var42, var43, var44, var45, var46, var47, var48, var49, var50, var51, var52, var53, var54, var55, var56, var57, var58, var59, var60, var61, var62, var63, var64, var65, var66, var67, var68, var69, var70, var71, var72, var73, var74, var75, var76, var77, var78, var79, var80, var81, var82, var83, var84, var85, var86, var87, var88, var89, var90, var91, var92, var93, var94, var95, var96, var97, var98, var99, var100, var101, var102, var103, var104, var105, var106, var107, var108, var109, var110, var111, var112, var113, var114, var115, var116, var117, var118, var119, var120, var121, var122, var123, var124, var125, var126, var127, var128, var129, var130, var131, var132, var133, var134, var135, var136, var137, var138, var139, var140, var141, var142, var143, var144, var145, var146, var147, var148, var149, var150, var151, var152, var153, var154, var155, var156, var157, var158, var159, var160, var161, var162, var163, var164, var165, var166, var167, var168, var169, var170, var171, var172, var173, var174, var175, var176, var177, var178, var179, var180, var181, var182, var183, var184, var185, var186, var187;

   var2 = 4;
   var2[0] = 22.5f;
   var2[1] = 22.5f;
   var2[2] = (float)16;
   var2[3] = (float)17;
   var7 = 4;
   var7[0 * 3].v0 = -2898.93f;
   var7[0 * 3].v1 = -4.78857f;
   var7[0 * 3].v2 = -188.136f;
   var7[1 * 3].v0 = -2899.11f;
   var7[1 * 3].v1 = -4.78908f;
   var7[1 * 3].v2 = 214.661f;
   var7[2 * 3].v0 = -2709.18f;
   var7[2 * 3].v1 = -4.79841f;
   var7[2 * 3].v2 = 18.1936f;
   var7[3 * 3].v0 = -3028.08f;
   var7[3 * 3].v1 = -27.5867f;
   var7[3 * 3].v2 = 3.19175f;
   var20 = 4;
   var20[0 * 3].v0 = -2865.7f;
   var20[0 * 3].v1 = -4.68832f;
   var20[0 * 3].v2 = -209.424f;
   var20[1 * 3].v0 = -2928.73f;
   var20[1 * 3].v1 = -4.58174f;
   var20[1 * 3].v2 = 194.311f;
   var20[2 * 3].v0 = -2731.71f;
   var20[2 * 3].v1 = -4.79699f;
   var20[2 * 3].v2 = 18.1936f;
   var20[3 * 3].v0 = -3028.04f;
   var20[3 * 3].v1 = -27.9829f;
   var20[3 * 3].v2 = -19.8989f;
   var33 = 16;
   var33[0 * 3].v0 = -2622.09f;
   var33[0 * 3].v1 = -4.6718f;
   var33[0 * 3].v2 = -190.746f;
   var33[1 * 3].v0 = -2622.03f;
   var33[1 * 3].v1 = -4.6718f;
   var33[1 * 3].v2 = -185.746f;
   var33[2 * 3].v0 = -2622.15f;
   var33[2 * 3].v1 = -4.6718f;
   var33[2 * 3].v2 = -195.245f;
   var33[3 * 3].v0 = -2621.98f;
   var33[3 * 3].v1 = -4.6718f;
   var33[3 * 3].v2 = -181.247f;
   var33[4 * 3].v0 = -2613.53f;
   var33[4 * 3].v1 = -4.6718f;
   var33[4 * 3].v2 = -185.851f;
   var33[5 * 3].v0 = -2613.65f;
   var33[5 * 3].v1 = -4.6718f;
   var33[5 * 3].v2 = -195.351f;
   var33[6 * 3].v0 = -2613.48f;
   var33[6 * 3].v1 = -4.6718f;
   var33[6 * 3].v2 = -181.352f;
   var33[7 * 3].v0 = -2613.59f;
   var33[7 * 3].v1 = -4.6718f;
   var33[7 * 3].v2 = -190.851f;
   var33[8 * 3].v0 = -2605.03f;
   var33[8 * 3].v1 = -4.6718f;
   var33[8 * 3].v2 = -185.957f;
   var33[9 * 3].v0 = -2605.15f;
   var33[9 * 3].v1 = -4.6718f;
   var33[9 * 3].v2 = -195.456f;
   var33[10 * 3].v0 = -2605.09f;
   var33[10 * 3].v1 = -4.6718f;
   var33[10 * 3].v2 = -190.956f;
   var33[11 * 3].v0 = -2604.98f;
   var33[11 * 3].v1 = -4.6718f;
   var33[11 * 3].v2 = -181.457f;
   var33[12 * 3].v0 = -2596.53f;
   var33[12 * 3].v1 = -4.6718f;
   var33[12 * 3].v2 = -186.062f;
   var33[13 * 3].v0 = -2596.65f;
   var33[13 * 3].v1 = -4.6718f;
   var33[13 * 3].v2 = -195.561f;
   var33[14 * 3].v0 = -2596.48f;
   var33[14 * 3].v1 = -4.6718f;
   var33[14 * 3].v2 = -181.562f;
   var33[15 * 3].v0 = -2596.59f;
   var33[15 * 3].v1 = -4.6718f;
   var33[15 * 3].v2 = -191.062f;
   var82 = 16;
   var82[0] = 90.7098f;
   var82[1] = 90.7098f;
   var82[2] = 90.7098f;
   var82[3] = 90.7098f;
   var82[4] = 90.7098f;
   var82[5] = 90.7098f;
   var82[6] = 90.7098f;
   var82[7] = 90.7098f;
   var82[8] = 90.7098f;
   var82[9] = 90.7098f;
   var82[10] = 90.7098f;
   var82[11] = 90.7098f;
   var82[12] = 90.7098f;
   var82[13] = 90.7098f;
   var82[14] = 90.7098f;
   var82[15] = 90.7098f;
   var99 = 16;
   var99[0 * 3].v0 = -2622.21f;
   var99[0 * 3].v1 = -9.79796f;
   var99[0 * 3].v2 = 211.975f;
   var99[1 * 3].v0 = -2622.19f;
   var99[1 * 3].v1 = -9.79796f;
   var99[1 * 3].v2 = 216.975f;
   var99[2 * 3].v0 = -2622.23f;
   var99[2 * 3].v1 = -9.79796f;
   var99[2 * 3].v2 = 207.475f;
   var99[3 * 3].v0 = -2622.17f;
   var99[3 * 3].v1 = -9.79796f;
   var99[3 * 3].v2 = 221.475f;
   var99[4 * 3].v0 = -2613.69f;
   var99[4 * 3].v1 = -9.79796f;
   var99[4 * 3].v2 = 216.939f;
   var99[5 * 3].v0 = -2613.73f;
   var99[5 * 3].v1 = -9.79796f;
   var99[5 * 3].v2 = 207.439f;
   var99[6 * 3].v0 = -2613.67f;
   var99[6 * 3].v1 = -9.79796f;
   var99[6 * 3].v2 = 221.439f;
   var99[7 * 3].v0 = -2613.71f;
   var99[7 * 3].v1 = -9.79796f;
   var99[7 * 3].v2 = 211.939f;
   var99[8 * 3].v0 = -2605.19f;
   var99[8 * 3].v1 = -9.79796f;
   var99[8 * 3].v2 = 216.904f;
   var99[9 * 3].v0 = -2605.23f;
   var99[9 * 3].v1 = -9.79796f;
   var99[9 * 3].v2 = 207.404f;
   var99[10 * 3].v0 = -2605.21f;
   var99[10 * 3].v1 = -9.79796f;
   var99[10 * 3].v2 = 211.904f;
   var99[11 * 3].v0 = -2605.17f;
   var99[11 * 3].v1 = -9.79796f;
   var99[11 * 3].v2 = 221.403f;
   var99[12 * 3].v0 = -2596.69f;
   var99[12 * 3].v1 = -9.79796f;
   var99[12 * 3].v2 = 216.868f;
   var99[13 * 3].v0 = -2596.73f;
   var99[13 * 3].v1 = -9.79796f;
   var99[13 * 3].v2 = 207.368f;
   var99[14 * 3].v0 = -2596.67f;
   var99[14 * 3].v1 = -9.79796f;
   var99[14 * 3].v2 = 221.368f;
   var99[15 * 3].v0 = -2596.71f;
   var99[15 * 3].v1 = -9.79796f;
   var99[15 * 3].v2 = 211.868f;
   var148 = 16;
   var148[0] = 90.2408f;
   var148[1] = 90.2408f;
   var148[2] = 90.2408f;
   var148[3] = 90.2408f;
   var148[4] = 90.2408f;
   var148[5] = 90.2408f;
   var148[6] = 90.2408f;
   var148[7] = 90.2408f;
   var148[8] = 90.2408f;
   var148[9] = 90.2408f;
   var148[10] = 90.2408f;
   var148[11] = 90.2408f;
   var148[12] = 90.2408f;
   var148[13] = 90.2408f;
   var148[14] = 90.2408f;
   var148[15] = 90.2408f;
   var165 = 3;
   var165[0 * 3].v0 = -2987.01f;
   var165[0 * 3].v1 = -16.0457f;
   var165[0 * 3].v2 = -9.09969f;
   var165[1 * 3].v0 = -2618.12f;
   var165[1 * 3].v1 = -4.61966f;
   var165[1 * 3].v2 = -188.289f;
   var165[2 * 3].v0 = -2618.18f;
   var165[2 * 3].v1 = -9.79819f;
   var165[2 * 3].v2 = 214.362f;
   var175 = 3;
   var175[0] = "PickUp";
   var175[1] = "DropOff";
   var175[2] = "DropOff";
   var179 = 3;
   var179[0] = 0;
   var179[1] = 2;
   var179[2] = 1;
   var183 = 0;
   var184 = Ctf_GetMap(L[0].v801);
   CtfMap_Init(var184, 1, 2);
   var183 = 0;
   while (var183 < 3)
   {
       CtfMap_AddItem(var184, var175[var183], &(var165[var183 * 3]), var179[var183]);
       var183 = var183 + 1;
   }
   var185 = 0;
   var186 = Race_GetRaceGrid(L[0].v3, 0);
   var187 = Race_GetRaceGrid(L[0].v3, 1);
   var185 = 0;
   while (var185 < 16)
   {
       RaceGrid_SetPosition(var186, var185, &(var33[var185 * 3]), var82[var185]);
       RaceGrid_SetPosition(var187, var185, &(var99[var185 * 3]), var148[var185]);
       var185 = var185 + 1;
   }
   L[0].v2 = PickUpManager_CreatePowerUpSources(4);
   var183 = 0;
   while (var183 < 4)
   {
       PickUpManager_AddPowerUpSource(L[0].v2, &(var7[var183 * 3]), var2[var183], &(var20[var183 * 3]));
       var183 = var183 + 1;
   }
   sub_826(&L[0]);
}

void sub_826(var0)
{
   auto var3, var4, var5, var6, var7, var8, var9, var10, var11, var12, var13, var14, var15, var16;

   var8.v0 = (float)0;
   var8.v1 = (float)1;
   var8.v2 = (float)0;
   var11.v0 = (float)0;
   var11.v1 = (float)0;
   var11.v2 = (float)-1;
   RaceGrid_GetPosition(Race_GetRaceGrid(*(var0 + 12), 0), 0, &var4, &var7);
   Math_VecRotateY(&var11, &var11, var7);
   var11.v0 = var4.v0 + var11.v0;
   var11.v1 = var4.v1 + var11.v1;
   var11.v2 = var4.v2 + var11.v2;
   var8.v0 = var4.v0 + var8.v0;
   var8.v1 = var4.v1 + var8.v1;
   var8.v2 = var4.v2 + var8.v2;
   UILogic_LockStreaming(&var4, &var8, &var11);
   var3 = 0;
   while (var3 < *((var0 + 16) + 3080))
   {
       Racer_SetStreamingLockedIn((*((var0 + 16) + 4))[var3 * 48].v0);
       var3 = var3 + 1;
   }
   var14 = 1;
   while (var14 > 0)
   {
       var14 = *((var0 + 16) + 3080);
       var3 = 0;
       while (var3 < *((var0 + 16) + 3080))
       {
           if (Racer_IsSimStreamed((*((var0 + 16) + 4))[var3 * 48].v0))
           {
               var14 = var14 - 1;
           }
           var3 = var3 + 1;
       }
       if (var14 > 0)
       {
           if (!*((var0 + 16) + 3132))
           {
               sub_93d(1, 0, 0x3f800000, 0);
           }
           WAIT(100);
       }
   }
   while (OpponentManager_StillStreamingOut())
   {
       WAIT(30);
   }
   var3 = 0;
   while (var3 < *((var0 + 16) + 3080))
   {
       if ((*((var0 + 16) + 4))[var3 * 48].v2 == 2)
       {
           PRINTSTRING(" BRAIN CREATED!");
           (*((var0 + 16) + 4))[var3 * 48].v3 = BrainFactory_CreateBrainRacing((*((var0 + 16) + 4))[var3 * 48].v0);
       }
       var3 = var3 + 1;
   }
   var15 = START_NEW_SCRIPT_WITH_ARGS("game/racetypes/BaseWarCore", var0, 802, 1500);
   while (!IsChildFinished(var15))
   {
       WAIT(30);
   }
   var3 = 0;
   while (var3 < *((var0 + 16) + 3080))
   {
       if ((*((var0 + 16) + 4))[var3 * 48].v2 == 2)
       {
           BrainFactory_DeleteBrain((*((var0 + 16) + 4))[var3 * 48].v0);
       }
       var3 = var3 + 1;
   }
}

void sub_93d(var0, var1, var2, var3)
{
   auto var6, var7, var8, var9, var10, var11, var12, var13;

   var6 = null;
   while (var6 == null)
   {
       var6 = UIManager_FindMovie("TRANSITIONMOVIE");
       if (var6 == null)
       {
           PRINTSTRING("SCRIPT: waiting for transition movie to stream in...\n");
           WAITUNWARPED(10);
       }
   }
   var7 = 0;
   var8 = 0;
   var9 = 0;
   FlashHelper_GetGlobalInt(var6, "StartOfTransitionout", &var7);
   FlashHelper_GetGlobalInt(var6, "StartOfTransitionin", &var8);
   FlashHelper_GetGlobalInt(var6, "TransitionOutisReady", &var9);
   PRINTSTRING("FADE DOWN REPORT\n");
   PRINTSTRING("================\n");
   PRINTSTRING("TransitionOut: ");
   PRINTINT(var7);
   PRINTSTRING("\nTransitionIn: ");
   PRINTINT(var8);
   PRINTSTRING("\nnTransitionReady: ");
   PRINTINT(var9);
   PRINTSTRING("\n");
   if ((var8 == 0) && ((var9 == 0) || ((var7 == 1) && (var9 == 2))))
   {
       FlashHelper_SetMovieEnabled(var6, 1);
       FlashHelper_SetGlobalInt(var6, "cur_visibility", 1);
       FlashHelper_SetGlobalInt(var6, "mask_color", var3);
       if (var1)
       {
           FlashHelper_SetGlobalInt(var6, "transition_type", 0);
       }
       else
       {
           FlashHelper_SetGlobalInt(var6, "transition_type", 1);
       }
       FlashHelper_SetGlobalFloat(var6, "fade_speed_in", var2);
       FlashHelper_SetGlobalFloat(var6, "fade_speed_out", 0.01f);
       FlashHelper_SetGlobalInt(var6, "StartOfTransitionout", 0);
       FlashHelper_SetGlobalInt(var6, "TransitionOutisReady", 0);
       FlashHelper_SetGlobalInt(var6, "StartOfTransitionin", 1);
       if (var0)
       {
           var8 = 1;
           while (var8 == 1)
           {
               FlashHelper_GetGlobalInt(var6, "StartOfTransitionin", &var8);
               if (var8 == 1)
               {
                   WAITUNWARPED(10);
               }
           }
       }
   }
}

