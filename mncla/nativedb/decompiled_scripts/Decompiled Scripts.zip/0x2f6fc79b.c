void main()
{
   SplashManager_Splash(0, 4, "Splash Number 1", 0x40000000, 1, 0);
   SplashManager_Splash(0, 4, "Splash Number 2", 0x40000000, 1, 0);
   SplashManager_Splash(0, 4, "Splash Number 3", 0x40000000, 1, 0);
   SplashManager_Splash(0, 4, "Splash Number 4", 0x40000000, 1, 0);
   WAIT(500);
}


