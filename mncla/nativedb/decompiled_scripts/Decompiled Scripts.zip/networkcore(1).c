﻿void main()
{
   auto var2, var3, var4, var5, var6, var7, var8, var9, var10, var11, var12, var13, var14, var15, var16, var17, var18, var19, var20, var21, var22, var23, var24, var25, var26, var27, var28, var29, var30, var31, var32, var33, var34, var35, var36, var37, var38, var39, var40, var41, var42, var43, var44, var45, var46, var47, var48, var49, var50, var51, var52, var53, var54, var55, var56, var57, var58, var59, var60, var61, var62, var63, var64, var65, var66, var67, var68, var69, var70, var71, var72, var73, var74, var75, var76, var77, var78, var79, var80, var81, var82, var83, var84, var85, var86, var87, var88, var89, var90, var91, var92, var93, var94, var95, var96, var97, var98, var99, var100, var101, var102, var103, var104, var105, var106, var107, var108, var109, var110, var111, var112, var113, var114, var115, var116, var117, var118, var119, var120, var121, var122, var123, var124, var125, var126, var127, var128, var129, var130, var131, var132, var133, var134, var135, var136, var137, var138, var139, var140, var141, var142, var143, var144, var145, var146, var147, var148, var149, var150, var151, var152, var153, var154, var155, var156, var157, var158, var159, var160, var161, var162, var163, var164, var165, var166, var167, var168, var169, var170, var171, var172, var173, var174, var175, var176, var177, var178, var179, var180, var181, var182, var183, var184, var185, var186, var187, var188, var189, var190, var191, var192, var193, var194, var195, var196, var197, var198, var199, var200, var201, var202, var203, var204, var205, var206, var207, var208, var209, var210, var211, var212, var213, var214, var215, var216, var217, var218, var219, var220, var221, var222, var223, var224, var225, var226, var227, var228, var229, var230, var231, var232, var233, var234, var235, var236, var237, var238, var239, var240, var241, var242, var243, var244, var245, var246, var247, var248, var249, var250, var251, var252, var253, var254, var255, var256, var257, var258, var259, var260, var261, var262, var263, var264, var265, var266, var267, var268, var269, var270, var271, var272, var273, var274, var275, var276, var277, var278, var279, var280, var281, var282, var283, var284, var285, var286, var287, var288, var289, var290, var291, var292, var293, var294, var295, var296, var297, var298, var299, var300, var301, var302, var303, var304, var305, var306, var307, var308, var309, var310, var311, var312, var313, var314, var315, var316, var317, var318, var319, var320, var321, var322, var323, var324, var325, var326, var327, var328, var329, var330, var331, var332, var333, var334, var335, var336, var337, var338, var339, var340, var341, var342, var343, var344, var345, var346, var347, var348, var349, var350, var351, var352, var353, var354, var355, var356, var357, var358, var359, var360, var361, var362, var363, var364, var365, var366, var367, var368, var369, var370, var371, var372, var373, var374, var375, var376, var377, var378, var379, var380, var381, var382, var383, var384, var385, var386, var387, var388, var389, var390, var391, var392, var393, var394, var395, var396, var397, var398, var399, var400, var401, var402, var403, var404, var405, var406, var407, var408, var409, var410, var411, var412, var413, var414, var415, var416, var417, var418, var419, var420, var421, var422, var423, var424, var425, var426, var427, var428, var429, var430, var431, var432, var433, var434, var435, var436, var437, var438, var439, var440, var441, var442, var443, var444, var445, var446, var447, var448, var449, var450, var451, var452, var453, var454, var455, var456, var457, var458, var459, var460, var461, var462, var463, var464, var465, var466, var467, var468, var469, var470, var471, var472, var473, var474, var475, var476, var477, var478, var479, var480, var481, var482, var483, var484, var485, var486, var487, var488, var489, var490, var491, var492, var493, var494, var495, var496, var497, var498, var499, var500, var501, var502, var503, var504, var505, var506, var507, var508, var509, var510, var511, var512, var513, var514, var515, var516, var517, var518, var519, var520, var521, var522, var523, var524, var525, var526, var527, var528, var529, var530, var531, var532, var533, var534, var535, var536, var537, var538, var539, var540, var541, var542, var543, var544, var545, var546, var547, var548, var549, var550, var551, var552, var553, var554, var555, var556, var557, var558, var559, var560, var561, var562, var563, var564, var565, var566, var567, var568, var569, var570, var571, var572, var573, var574, var575, var576, var577, var578, var579, var580, var581, var582, var583, var584, var585, var586, var587, var588, var589, var590, var591, var592, var593, var594, var595, var596, var597, var598, var599, var600, var601, var602, var603, var604, var605, var606, var607, var608, var609, var610, var611, var612, var613, var614, var615, var616, var617, var618, var619, var620, var621, var622, var623, var624, var625, var626, var627, var628, var629, var630, var631, var632, var633, var634, var635, var636, var637, var638, var639, var640, var641, var642, var643, var644, var645, var646, var647, var648, var649, var650, var651, var652, var653, var654, var655, var656, var657, var658, var659, var660, var661, var662, var663, var664, var665, var666, var667, var668, var669, var670, var671, var672, var673, var674, var675, var676, var677, var678, var679, var680, var681, var682, var683, var684, var685, var686, var687, var688, var689, var690, var691, var692, var693, var694, var695, var696, var697, var698, var699, var700, var701, var702, var703, var704, var705, var706, var707, var708, var709, var710, var711, var712, var713, var714, var715, var716, var717, var718, var719, var720, var721, var722, var723, var724, var725, var726, var727, var728, var729, var730, var731, var732, var733, var734, var735, var736, var737, var738, var739, var740, var741, var742, var743, var744, var745, var746, var747, var748, var749, var750, var751, var752, var753, var754, var755, var756, var757, var758, var759, var760, var761, var762, var763, var764, var765, var766, var767, var768, var769, var770, var771, var772, var773, var774, var775, var776, var777, var778, var779, var780, var781, var782, var783, var784, var785, var786, var787, var788, var789, var790, var791, var792, var793, var794, var795, var796, var797, var798, var799, var800, var801, var802, var803, var804, var805;

   OpponentManager_CleanupOpponentArray();
   sub_18(108, 0x3f000000);
   if (CineScript_IsScenePlaying())
   {
       CineScript_KillScene();
       while (CineScript_IsScenePlaying())
       {
           WAITUNWARPED(10);
       }
   }
   PoliceManager_EndTacticOnPlayer(1);
   PoliceManager_DestroyAllPolice();
   var2 = Graphics_GetAndSetAutoUpdateTimeOfDay(0);
   SetExceptionMask(3);
   var3 = ;
   switch (var3)
   {
       case 0:
       {
           break;
       }
       case 3:
       {
           break;
       }
       default:
       {
           PRINTSTRING("Unhandled exception\n");
           L[0].v0 = L[0].v0;
           var4.v4.v1 = 16;
           var4.v4.v1.v1.v9 = 15;
           var4.v4.v1.v1.v9.v25 = 15;
           var4.v4.v1.v1.v9.v25.v48.v9 = 15;
           var4.v4.v1.v1.v9.v25.v48.v9.v25 = 15;
           var4.v4.v1.v1.v9.v25.v48.v9.v25.v48.v9 = 15;
           var4.v4.v1.v1.v9.v25.v48.v9.v25.v48.v9.v25 = 15;
           var4.v4.v1.v1.v9.v25.v48.v9.v25.v48.v9.v25.v48.v9 = 15;
           var4.v4.v1.v1.v9.v25.v48.v9.v25.v48.v9.v25.v48.v9.v25 = 15;
           var4.v4.v1.v1.v9.v25.v48.v9.v25.v48.v9.v25.v48.v9.v25.v48.v9 = 15;
           var4.v4.v1.v1.v9.v25.v48.v9.v25.v48.v9.v25.v48.v9.v25.v48.v9.v25 = 15;
           var4.v4.v1.v1.v9.v25.v48.v9.v25.v48.v9.v25.v48.v9.v25.v48.v9.v25.v48.v9 = 15;
           var4.v4.v1.v1.v9.v25.v48.v9.v25.v48.v9.v25.v48.v9.v25.v48.v9.v25.v48.v9.v25 = 15;
           var4.v4.v1.v1.v9.v25.v48.v9.v25.v48.v9.v25.v48.v9.v25.v48.v9.v25.v48.v9.v25.v48.v9 = 15;
           var4.v4.v1.v1.v9.v25.v48.v9.v25.v48.v9.v25.v48.v9.v25.v48.v9.v25.v48.v9.v25.v48.v9.v25 = 15;
           var4.v4.v1.v1.v9.v25.v48.v9.v25.v48.v9.v25.v48.v9.v25.v48.v9.v25.v48.v9.v25.v48.v9.v25.v48.v9 = 15;
           var4.v4.v1.v1.v9.v25.v48.v9.v25.v48.v9.v25.v48.v9.v25.v48.v9.v25.v48.v9.v25.v48.v9.v25.v48.v9.v25 = 15;
           var4.v4.v1.v1.v9.v25.v48.v9.v25.v48.v9.v25.v48.v9.v25.v48.v9.v25.v48.v9.v25.v48.v9.v25.v48.v9.v25.v48.v9 = 15;
           var4.v4.v1.v1.v9.v25.v48.v9.v25.v48.v9.v25.v48.v9.v25.v48.v9.v25.v48.v9.v25.v48.v9.v25.v48.v9.v25.v48.v9.v25 = 15;
           var4.v4.v1.v1.v9.v25.v48.v9.v25.v48.v9.v25.v48.v9.v25.v48.v9.v25.v48.v9.v25.v48.v9.v25.v48.v9.v25.v48.v9.v25.v48.v9 = 15;
           var4.v4.v1.v1.v9.v25.v48.v9.v25.v48.v9.v25.v48.v9.v25.v48.v9.v25.v48.v9.v25.v48.v9.v25.v48.v9.v25.v48.v9.v25.v48.v9.v25 = 15;
           var4.v4.v1.v1.v9.v25.v48.v9.v25.v48.v9.v25.v48.v9.v25.v48.v9.v25.v48.v9.v25.v48.v9.v25.v48.v9.v25.v48.v9.v25.v48.v9.v25.v48.v9 = 15;
           var4.v4.v1.v1.v9.v25.v48.v9.v25.v48.v9.v25.v48.v9.v25.v48.v9.v25.v48.v9.v25.v48.v9.v25.v48.v9.v25.v48.v9.v25.v48.v9.v25.v48.v9.v25 = 15;
           var4.v4.v1.v1.v9.v25.v48.v9.v25.v48.v9.v25.v48.v9.v25.v48.v9.v25.v48.v9.v25.v48.v9.v25.v48.v9.v25.v48.v9.v25.v48.v9.v25.v48.v9.v25.v48.v9 = 15;
           var4.v4.v1.v1.v9.v25.v48.v9.v25.v48.v9.v25.v48.v9.v25.v48.v9.v25.v48.v9.v25.v48.v9.v25.v48.v9.v25.v48.v9.v25.v48.v9.v25.v48.v9.v25.v48.v9.v25 = 15;
           var4.v4.v1.v1.v9.v25.v48.v9.v25.v48.v9.v25.v48.v9.v25.v48.v9.v25.v48.v9.v25.v48.v9.v25.v48.v9.v25.v48.v9.v25.v48.v9.v25.v48.v9.v25.v48.v9.v25.v48.v9 = 15;
           var4.v4.v1.v1.v9.v25.v48.v9.v25.v48.v9.v25.v48.v9.v25.v48.v9.v25.v48.v9.v25.v48.v9.v25.v48.v9.v25.v48.v9.v25.v48.v9.v25.v48.v9.v25.v48.v9.v25.v48.v9.v25 = 15;
           var4.v4.v1.v1.v9.v25.v48.v9.v25.v48.v9.v25.v48.v9.v25.v48.v9.v25.v48.v9.v25.v48.v9.v25.v48.v9.v25.v48.v9.v25.v48.v9.v25.v48.v9.v25.v48.v9.v25.v48.v9.v25.v48.v9 = 15;
           var4.v4.v1.v1.v9.v25.v48.v9.v25.v48.v9.v25.v48.v9.v25.v48.v9.v25.v48.v9.v25.v48.v9.v25.v48.v9.v25.v48.v9.v25.v48.v9.v25.v48.v9.v25.v48.v9.v25.v48.v9.v25.v48.v9.v25 = 15;
           var4.v4.v1.v1.v9.v25.v48.v9.v25.v48.v9.v25.v48.v9.v25.v48.v9.v25.v48.v9.v25.v48.v9.v25.v48.v9.v25.v48.v9.v25.v48.v9.v25.v48.v9.v25.v48.v9.v25.v48.v9.v25.v48.v9.v25.v48.v9 = 15;
           var4.v4.v1.v1.v9.v25.v48.v9.v25.v48.v9.v25.v48.v9.v25.v48.v9.v25.v48.v9.v25.v48.v9.v25.v48.v9.v25.v48.v9.v25.v48.v9.v25.v48.v9.v25.v48.v9.v25.v48.v9.v25.v48.v9.v25.v48.v9.v25 = 15;
           var4.v4.v1.v1.v9.v25.v48.v9.v25.v48.v9.v25.v48.v9.v25.v48.v9.v25.v48.v9.v25.v48.v9.v25.v48.v9.v25.v48.v9.v25.v48.v9.v25.v48.v9.v25.v48.v9.v25.v48.v9.v25.v48.v9.v25.v48.v9.v25.v48.v9 = 15;
           var4.v4.v1.v1.v9.v25.v48.v9.v25.v48.v9.v25.v48.v9.v25.v48.v9.v25.v48.v9.v25.v48.v9.v25.v48.v9.v25.v48.v9.v25.v48.v9.v25.v48.v9.v25.v48.v9.v25.v48.v9.v25.v48.v9.v25.v48.v9.v25.v48.v9.v25 = 15;
           var4.v4.v1.v1.v9.v25.v48.v9.v25.v48.v9.v25.v48.v9.v25.v48.v9.v25.v48.v9.v25.v48.v9.v25.v48.v9.v25.v48.v9.v25.v48.v9.v25.v48.v9.v25.v48.v9.v25.v48.v9.v25.v48.v9.v25.v48.v9.v25.v48.v9.v25.v48.v791 = 3;
           while (1)
           {
               sub_2a2(&var4);
           }
           break;
       }
   }
   PRINTSTRING("NetworkCore script terminating...\n");
   sub_1b74(&var4);
   Net_UnlockRacerList();
   Net_ClearRaceResults();
   PRINTSTRING("NetworkCore script terminating...\n");
   Net_ClearRaceRequest();
   PRINTSTRING("Script: NetworkCore.sc: Re-enabling traffic\n");
   AmbientMgr_SetTrafficEnable(1);
   Graphics_GetAndSetAutoUpdateTimeOfDay(var2);
}

void sub_18(var0, var1)
{
   auto var4, var5, var6;

   PRINTSTRING("EASE FROM PAUSE YO1\n");
   var4 = Form_GetForm(var0);
   PerspectiveForm_SetSlowMotion(var4, 1.0f, 1.0f / var1, 0, 1, 1.0f);
   Ctrl_SetVisible(Form_ToCtrl(var4), 0);
   PRINTSTRING("EASE FROM PAUSE YO\n");
}

void sub_2a2(var0)
{
   auto var3, var4, var5, var6, var7, var8, var9, var10, var11, var12, var13, var14, var15, var16, var17, var18, var19, var20, var21, var22, var23, var24, var25;

   var3 = 0;
   var4 = 0;
   var5 = 0;
   PRINTSTRING("Script: Starting Cruise Loop\n");
   while ((!var3) && (!var5))
   {
       sub_2e7();
       if (sub_3dd())
       {
           var3 = Net_RaceRequested(&var6);
           if (sub_411())
           {
               if (!Net_IsLocalPlayerInRace())
               {
                   var5 = 1;
                   PRINTSTRING("Script: Looks like we joined a lobby with an in-progress event, waiting for it to end...\n");
                   if ((!Net_IsCruiseMode()) && (!Racer_IsObserverMode(sub_4c6())))
                   {
                       PRINTSTRING("Script: Hiding local racer (ObserverMode)...\n");
                       Racer_EnterObserverMode(sub_4c6());
                   }
               }
           }
       }
       if ((!var3) && (!var5))
       {
           WAIT(100);
       }
   }
   if (!var5)
   {
       var22 = 0;
       while (!Net_IsSessionStarted())
       {
           if (Net_IsHost() && (!var22))
           {
               PRINTSTRING("Script: Starting the session...\n");
               var22 = 1;
               Net_StartSession();
           }
           PRINTSTRING("Script: Networking/NetworkCore.sc: Waiting for Session Start\n");
           WAIT(30);
       }
   }
   Net_ClearRaceRequest();
   Net_LockRacerList();
   if (!var5)
   {
       PRINTSTRING("Script: Networking/NetworkCore.sc: Launching race ");
       PRINTSTRING(&var6);
       PRINTSTRING("\n");
       Notify(0);
   }
   var4 = Net_IsLocalPlayerInRace();
   if (var4)
   {
       PRINTSTRING("Script: Local player is in this race...\n");
       sub_6b0(var0, &var6);
       var23 = START_NEW_SCRIPT_WITH_ARGS(&var6, var0, 802, 3800);
       while (!IsChildFinished(var23))
       {
           WAIT(100);
       }
       Race_GetRaceData(*(var0 + 12), var0 + 16);
       var24 = 0;
       Registry_GetValueInt("raceOverTrigger", &var24);
       PRINTSTRING("Script: NetworkCore.sc: Event is over, raceOverTrigger=");
       PRINTINT(var24);
       PRINTSTRING("\n");
       if (var24 == 0)
       {
           mcEvent_PostEventRaceResults("GENERIC_RACE_COMPLETE", var0 + 16);
           mcEvent_PostEventRaceResults("RACE_EVENT", var0 + 16);
           sub_bf8(var0, 0, 1, 1);
           UIManager_SendEvent("raceEnd");
       }
   }
   else
   {
       PRINTSTRING("Script: Local player is sitting out of race...\n");
   }
   PRINTSTRING("Script: NetworkCore.sc: Local racer done with event, waiting for others to finish\n");
   while (!Net_IsRaceFinished())
   {
       WAIT(100);
   }
   PRINTSTRING("Script: Waiting for everyone to complete stats writing\n");
   PRINTSTRING("Script: Game Type was : ");
   PRINTINT(*((var0 + 16) + 3092));
   PRINTSTRING("\n");
   Net_WriteStats(*((var0 + 16) + 3092));
   while (!Net_EveryoneDoneWritingStats())
   {
       WAIT(100);
   }
   PRINTSTRING("Script: Everyone seems to be done writing stats so ending session\n");
   Net_EndSession();
   PRINTSTRING("Script: Post race stage started\n");
   while (!Net_IsPostRaceDone())
   {
       WAIT(100);
   }
   PRINTSTRING("Script: Post race done\n");
   PRINTSTRING("Script: calling PostRaceCleanup()\n");
   sub_1b74(var0);
   PRINTSTRING("Script: calling Net_PostRaceCleanup()\n");
   Net_PostRaceCleanup();
   PRINTSTRING("Script: Post race stage completed\n");
   Notify(1);
   PRINTSTRING("Script: Network race finished...\n");
   Net_UnlockRacerList();
   Net_ClearRaceResults();
}

void sub_2e7()
{
   auto var2;

   if (Net_IsHostDataFieldValid("TrafficEnabled"))
   {
       var2 = Net_GetHostDataAsInt("TrafficEnabled");
       if (var2 >= 0)
       {
           if ((var2 == 1) && (!AmbientMgr_GetTrafficEnable()))
           {
               PRINTSTRING("Script: NetworkCore.sc: Host set traffic on\n");
               AmbientMgr_SetTrafficEnable(1);
           }
           else if ((var2 == 0) && AmbientMgr_GetTrafficEnable())
           {
               PRINTSTRING("Script: NetworkCore.sc: Host set traffic off\n");
               AmbientMgr_SetTrafficEnable(0);
           }
       }
   }
}

function sub_3dd()
{
   return Net_IsHostDataFieldValid("GameStatus");
}

function sub_411()
{
   auto var2;

   var2 = Net_GetHostDataAsInt("GameStatus");
   if (var2 == 2)
   {
       return 1;
   }
   else
   {
       return 0;
   }
}

function sub_4c6()
{
   return Player_FindRacerObject(0);
}

void sub_6b0(var0, var1)
{
   auto var4, var5, var6, var7, var8, var9, var10, var11;

   PRINTSTRING("============= PreRaceInit ===================\n");
   mcRaceScriptParam_Clear(var0);
   var4 = Race_Create();
   *(var0 + 12) = var4;
   Race_SetCurrentRace(var4);
   Race_ToggleStarterCinematic(var4, 0);
   var5 = LookupCity(GetCurrentCity());
   *((var0 + 16) + 0) = CityDescription_GetRaceIndexByName(var5, var1);
   *((var0 + 16) + 3080) = Net_NumRacers();
   *((var0 + 16) + 3120) = 1;
   *((var0 + 16) + 3160) = Net_CreateOptions();
   *((var0 + 16) + 3116) = Net_GetLapCount();
   *((var0 + 16) + 3112) = Net_GetRaceLayout();
   if (*((var0 + 16) + 0) >= 0)
   {
       var6 = CityDescription_LookupRaceByIndex(var5, *((var0 + 16) + 0));
       if (*((var0 + 16) + 3112) == 0)
       {
           strcpy(var1, 64, RaceDescription_GetEasyRaceName(var6));
           if (StringCompare(var1, ""))
           {
               strcpy(var1, 64, CityDescription_GetRaceNameByIndex(var5, *((var0 + 16) + 0)));
           }
       }
       var7 = RaceDescription_GetRaceGridType(var6);
       *(var0 + 3196) = CineScript_GetFirstRacestartCutsceneFromGridEnum(var7);
       if (StringCompare(*(var0 + 3196), ""))
       {
           *(var0 + 3196) = "game/cinescripts/generated/racestart/gen_prerace_grid_3x3_04_generated";
       }
       *((var0 + 16) + 3088) = RaceDescription_GetRaceType(var6);
       *((var0 + 16) + 3092) = RaceDescription_GetRaceSubType(var6);
       *((var0 + 16) + 3096) = 1;
   }
   if (*((var0 + 16) + 3088) == 3)
   {
       *(var0 + 3204) = Ctf_Create(var4);
       Ctf_SetCurrentCtf(*(var0 + 3204));
   }
   var8 = 0;
   var8 = 0;
   while (var8 < *((var0 + 16) + 3080))
   {
       (*((var0 + 16) + 4))[var8 * 48].v0 = Net_GetRacerFromList(var8);
       (*((var0 + 16) + 4))[var8 * 48].v5 = 1;
       (*((var0 + 16) + 4))[var8 * 48].v42 = Net_GetRacerTeamColor((*((var0 + 16) + 4))[var8 * 48].v0);
       (*((var0 + 16) + 4))[var8 * 48].v4 = mcHudMapServer_GetVehicleElement((*((var0 + 16) + 4))[var8 * 48].v0);
       if (var8 == 0)
       {
           (*((var0 + 16) + 4))[var8 * 48].v2 = 0;
       }
       else
       {
           (*((var0 + 16) + 4))[var8 * 48].v2 = 1;
       }
       var8 = var8 + 1;
   }
   if (*((var0 + 16) + 0) >= 0)
   {
       if (*((var0 + 16) + 3088) != 3)
       {
           sub_9b9();
       }
   }
   Race_SetRaceData(var4, var0 + 16);
   var9 = Race_GetCheckpointList(var4);
   CheckpointManager_SetActiveCheckpointList(var9);
}

void sub_9b9()
{
   auto var2, var3;

   var2 = UIManager_GetState("GPSScene");
   var3 = vhsmState_IsActive(var2);
   if (!Warper_IsReadyToLoadStuff())
   {
       PRINTSTRING("Waiting for previous warp to complete\n");
       while (!Warper_IsReadyToLoadStuff())
       {
           WAITUNWARPED(100);
           PRINTSTRING("Waiting for previous warp\n");
       }
       PRINTSTRING("Previous Warp is complete\n");
   }
   if (var3)
   {
       mcUINavMap_DisableExitTransition();
       Warper_Warp("EXIT_TO_CUT");
   }
   else
   {
       Warper_Warp("DEFAULT_WITH_CUT");
   }
}

void sub_bf8(var0, var1, var2, var3)
{
   auto var6, var7, var8, var9, var10, var11, var12, var13, var14, var15, var16, var17, var18, var19, var20, var21, var22, var23, var24, var25, var26, var27, var28, var29, var30, var31, var32, var33, var34, var35, var36, var37, var38, var39, var40, var41, var42, var43, var44, var45, var46, var47, var48, var49, var50, var51, var52, var53, var54, var55, var56, var57, var58, var59, var60, var61, var62, var63, var64, var65, var66, var67, var68, var69, var70, var71, var72;

   while (FlashNavigator_IsTransitioning())
   {
       PRINTSTRING("RaceOver.sch: WAITING TO END TRANSITION\n");
       WAITUNWARPED(200);
   }
   SplashManager_Cleanup();
   var6 = *((var0 + 16) + 3096);
   var7 = UIManager_FindMovie("PAUSEMOVIE");
   var8 = (17 == var6) || (16 == var6);
   var9 = 0;
   if (var6 == 11)
   {
       var9 = 0;
   }
   else
   {
       var9 = Race_IsTeamGame(var0 + 16);
   }
   var10 = Race_IsDamagedOut(*(var0 + 12));
   var11 = 1;
   var12 = Race_HasBeenArrested(*(var0 + 12));
   var13 = 0;
   var14 = Registry_GetValueBool("bComplete");
   var15 = Registry_GetValueBool("bFailure");
   var16 = Registry_GetValueBool("nPlayerCaught");
   var17 = var6 == 6;
   var18 = var6 == 2;
   var19 = var6 == 7;
   var20 = (var6 == 13) || (var6 == 14);
   var21 = var6 == 9;
   var22 = var6 == 10;
   var23 = var6 == 4;
   var24 = var6 == 3;
   PRINTSTRING("SCRIPT: Starting EndOfRaceSequence() for race type ");
   PRINTINT(*((var0 + 16) + 3096));
   if (var9)
   {
       PRINTSTRING(" (TEAM GAME) ");
   }
   else
   {
       PRINTSTRING(" (FFA GAME) ");
   }
   if (var10)
   {
       PRINTSTRING(" (DAMAGED OUT)\n");
   }
   else
   {
       PRINTSTRING(" (RACE SAFE)\n");
   }
   if (var15)
   {
       PRINTSTRING(" (FAILURE)\n");
   }
   else
   {
       PRINTSTRING(" (SUCCESS)\n");
   }
   if (((*((var0 + 16) + 4))[var1 * 48].v8 == 0x7fffffff) && (!var8))
   {
       if (!((var24 || var23) && (var14 || var15)))
       {
           PRINTSTRING("SCRIPT: skipping sequence because did not finish\n");
           var11 = 0;
       }
   }
   if (var12 && (!var16))
   {
       PRINTSTRING("SCRIPT: skipping sequence because damaged out or arrested\n");
       var11 = 0;
   }
   Notify(2);
   if (var11)
   {
       var25 = (*((var0 + 16) + 4))[var1 * 48].v41;
       var26 = (*((var0 + 16) + 4))[var1 * 48].v8;
       PRINTSTRING("nFinishTime = ");
       PRINTINT(var26);
       if (var3)
       {
           if ((var18 || var17) || var19)
           {
               if (var15)
               {
                   mcPlayerAudioEntity_PlayEndRaceSpeechLose();
               }
               else
               {
                   mcPlayerAudioEntity_PlayEndRaceSpeechWin();
               }
           }
           else if (var25 == 1)
           {
               mcPlayerAudioEntity_PlayEndRaceSpeechWin();
           }
           else if ((var25 == 2) && ((var26 - Race_GetWinningTime(*(var0 + 12))) <= 300))
           {
               mcPlayerAudioEntity_PlayEndRaceSpeechClose();
           }
           else
           {
               mcPlayerAudioEntity_PlayEndRaceSpeechLose();
           }
           WAITUNWARPED(200);
       }
       var27 = !*((var0 + 16) + 3120);
       var28 = 16;
       var45 = Form_GetForm(-1);
       var28[9] = Form_GetForm(51);
       var28[0] = Form_GetForm(60);
       var28[1] = Form_GetForm(54);
       var28[2] = Form_GetForm(57);
       var28[3] = Form_GetForm(58);
       var28[5] = Form_GetForm(42);
       var28[6] = Form_GetForm(53);
       var28[7] = Form_GetForm(49);
       var28[8] = Form_GetForm(50);
       var28[10] = Form_GetForm(46);
       var28[11] = Form_GetForm(47);
       var28[12] = Form_GetForm(56);
       var28[13] = Form_GetForm(49);
       var28[14] = Form_GetForm(50);
       var28[15] = Form_GetForm(52);
       UIManager_SendEvent("raceEnding");
       PRINTSTRING("SCRIPT : I start the race over sequence for raceType: ");
       PRINTINT(*((var0 + 16) + 3092));
       PRINTSTRING("\n");
       PerspectiveForm_SetCameraIndex(var28[0], 0);
       Form_ShowForm(var45, var28[0]);
       if (var27)
       {
           var46 = 0.5f;
           PerspectiveForm_SetSlowMotion(var28[0], 0.0f, 1.0f / var46, 0, 1, 0.4f);
       }
       else
       {
           WAITUNWARPED(100);
       }
       var47 = 5;
       var53 = 5;
       var59 = 0;
       var60 = 0;
       var61 = 0;
       var62 = 0;
       if (!var20)
       {
           if (Form_GetFormResult(var28[2]) == 3)
           {
               var61 = 1;
               PropertyCtrl_SetPropertyInt(Form_ToCtrl(var28[2]), 0, 0);
           }
           if (Form_GetFormResult(var28[6]) == 3)
           {
               var62 = 1;
           }
       }
       if (var12 || var13)
       {
           var61 = 0;
           var62 = 0;
           var23 = 0;
           var24 = 0;
           var18 = 0;
           var9 = 0;
       }
       var47[0] = 0;
       var47[1] = 0;
       var47[2] = 0;
       var47[3] = 0;
       var47[4] = 0;
       if (var9)
       {
           var47[0] = 3;
           var60 = var60 + 1;
       }
       else if (var12 && (!var16))
       {
           var47[0] = 10;
           var60 = var60 + 1;
       }
       else if (var13 && (!var16))
       {
           var47[0] = 11;
           var60 = var60 + 1;
       }
       else if (!var10)
       {
           if ((((!var18) && (!var19)) && (!var17)) && ((*((var0 + 16) + 4))[var1 * 48].v8 != 0x7fffffff))
           {
               strcpy(&var63, 16, "");
               strcati(&var63, 16, (*((var0 + 16) + 4))[var1 * 48].v41);
               Form_SetText(var28[1], &var63);
               PRINTSTRING("POSITION=");
               PRINTSTRING(&var63);
               PRINTSTRING("\n");
               var47[0] = 1;
               var60 = var60 + 1;
           }
       }
       if (var17 && (!var10))
       {
           if (var14 || var15)
           {
               var47[var60] = 12;
               var60 = var60 + 1;
           }
           var47[var60] = 9;
           var60 = var60 + 1;
       }
       else if (var18 && (!var10))
       {
           if (var14 || var15)
           {
               var47[var60] = 12;
               var60 = var60 + 1;
           }
           var47[var60] = 5;
           var60 = var60 + 1;
       }
       else if (var19)
       {
           if (((var14 || var15) || var16) || var10)
           {
               PRINTSTRING("PAYBACK  eP_EventResultsPanel \n A: ");
               var47[var60] = 12;
               var60 = var60 + 1;
           }
       }
       else if (var23)
       {
           if (var14 || var15)
           {
               var47[var60] = 12;
               var60 = var60 + 1;
           }
           var47[var60] = 13;
           var60 = var60 + 1;
       }
       else if (var24)
       {
           if (var14 || var15)
           {
               var47[var60] = 12;
               var60 = var60 + 1;
           }
           var47[var60] = 14;
           var60 = var60 + 1;
       }
       else if (var21)
       {
           if (var14 || var15)
           {
               var47[var60] = 12;
               var60 = var60 + 1;
           }
       }
       else if (var22)
       {
           if (var14 || var15)
           {
               var47[var60] = 12;
               var60 = var60 + 1;
           }
       }
       if (var61)
       {
           var47[var60] = 2;
           var60 = var60 + 1;
       }
       if (var62)
       {
           var47[var60] = 6;
           var60 = var60 + 1;
       }
       var67 = 0;
       while (var67 <= (var60 - 1))
       {
           if (var47[var67] == 3)
           {
               var53[var67] = 4400;
           }
           else if (var47[var67] == 9)
           {
               var53[var67] = 5000;
           }
           else if (var47[var67] == 12)
           {
               var53[var67] = 3500;
           }
           else
           {
               var53[var67] = 2200;
           }
           var67 = var67 + 1;
       }
       AudioManager_SetActiveEndRace(1, var20);
       var68 = null;
       var67 = 0;
       while (var67 <= (var60 - 1))
       {
           Registry_GetValueInt("NET_UNLOADCAREER", &var59);
           if ((var59 > 0) || Net_IsConnecting())
           {
           }
           else
           {
               PRINTSTRING("SHOWING FORM AT INDEX: ");
               PRINTINT(var67);
               PRINTSTRING(", FORM: ");
               PRINTINT(var47[var67]);
               PRINTSTRING(", WAIT:");
               PRINTINT(var53[var67]);
               PRINTSTRING("\n");
               var68 = var28[var47[var67]];
               if (var47[var67] == 1)
               {
                   Form_ShowForm(var45, var68);
                   WAITUNWARPED(var53[var67]);
               }
               else if ((var47[var67] == 3) || (var47[var67] == 12))
               {
                   Form_ShowForm(var28[0], var68);
                   WAITUNWARPED(var53[var67]);
               }
               else
               {
                   sub_1834(var28[0], var68);
               }
               if (!(var47[var67] == 0))
               {
                   Form_CloseForm(var68);
                   PRINTSTRING("CLOSEFORM\n");
               }
               var67 = var67 + 1;
           }
       }
       Form_CloseForm(var28[0]);
   }
   if (var2)
   {
       mcEvent_PostEventStr("CAREER_AUTOSAVE", "");
   }
   PRINTSTRING("SCRIPT: End EndOfRaceSequence()\n");
}

void sub_1834(var0, var1)
{
   auto var4, var5, var6;

   var4 = 1;
   Form_ShowForm(var0, var1);
   while (var4)
   {
       var4 = Form_GetFormVisible(var1);
       WAITUNWARPED(100);
   }
}

void sub_1b74(var0)
{
   auto var3, var4;

   PRINTSTRING("============= PostRaceCleanup ===================\n");
   if (*(var0 + 3204) != null)
   {
       PRINTSTRING("Script: Destroying Ctf Object\n");
       Ctf_Destroy(*(var0 + 3204));
       *(var0 + 3204) = null;
       PRINTSTRING("Script: Destroyed Ctf Object\n");
   }
   if (*(var0 + 12) != null)
   {
       if (*(var0 + 12) == Race_GetCurrentRace())
       {
           PRINTSTRING("ClearActiveCheckpointList and ResetCurrentRace\n");
           CheckpointManager_ClearActiveCheckpointList();
           Race_ResetCurrentRace();
       }
       PRINTSTRING("Script: Destroying Race Object\n");
       Race_Destroy(*(var0 + 12));
       *(var0 + 12) = null;
       PRINTSTRING("Script: Destroyed Race Object\n");
       if (!Net_IsCruiseMode())
       {
           var3 = sub_4c6();
           if (var3 != null)
           {
               PRINTSTRING("Script: Resetting local racer post race\n");
               Racer_SetResetPositionFromRecoveryMatrix(var3);
               Net_ResetLocalPlayer();
           }
       }
   }
   if (*((var0 + 16) + 3160) != null)
   {
       PRINTSTRING("Script: Destroying EventOptions Object\n");
       EventOptions_DestroyOptions(*((var0 + 16) + 3160));
       *((var0 + 16) + 3160) = null;
       PRINTSTRING("Script: Destroyed EventOptions Object\n");
   }
   if (Racer_IsObserverMode(sub_4c6()))
   {
       PRINTSTRING("Script: Local racer exiting ObserverMode...\n");
       Racer_ExitObserverMode(sub_4c6());
   }
}

