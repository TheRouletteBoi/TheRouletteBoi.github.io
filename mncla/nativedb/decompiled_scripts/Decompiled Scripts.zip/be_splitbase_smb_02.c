﻿void main()
{
   auto var2, var3, var4, var5, var6, var7, var8, var9, var10, var11, var12, var13, var14, var15, var16, var17, var18, var19, var20, var21, var22, var23, var24, var25, var26, var27, var28, var29, var30, var31, var32, var33, var34, var35, var36, var37, var38, var39, var40, var41, var42, var43, var44, var45, var46, var47, var48, var49, var50, var51, var52, var53, var54, var55, var56, var57, var58, var59, var60, var61, var62, var63, var64, var65, var66, var67, var68, var69, var70, var71, var72, var73, var74, var75, var76, var77, var78, var79, var80, var81, var82, var83, var84, var85, var86, var87, var88, var89, var90, var91, var92, var93, var94, var95, var96, var97, var98, var99, var100, var101, var102, var103, var104, var105, var106, var107, var108, var109, var110, var111, var112, var113, var114, var115, var116, var117, var118, var119, var120, var121, var122, var123, var124, var125, var126, var127, var128, var129, var130, var131, var132, var133, var134, var135, var136, var137, var138, var139, var140, var141, var142, var143, var144, var145, var146, var147, var148, var149, var150, var151, var152, var153, var154, var155, var156, var157, var158, var159, var160, var161, var162, var163, var164, var165, var166, var167, var168, var169, var170, var171, var172, var173, var174, var175, var176, var177, var178, var179, var180, var181, var182, var183, var184, var185, var186, var187, var188, var189, var190, var191, var192, var193, var194, var195, var196, var197, var198, var199, var200, var201, var202, var203, var204, var205, var206, var207, var208, var209, var210, var211, var212, var213, var214, var215, var216, var217, var218, var219, var220, var221, var222, var223, var224, var225, var226, var227, var228, var229, var230;

   var2 = 8;
   var2[0] = (float)9;
   var2[1] = (float)8;
   var2[2] = (float)8;
   var2[3] = (float)17;
   var2[4] = (float)20;
   var2[5] = 12.5f;
   var2[6] = 13.5f;
   var2[7] = (float)13;
   var11 = 8;
   var11[0 * 3].v0 = -3030.11f;
   var11[0 * 3].v1 = -19.7345f;
   var11[0 * 3].v2 = 561.638f;
   var11[1 * 3].v0 = -3157.62f;
   var11[1 * 3].v1 = -19.7345f;
   var11[1 * 3].v2 = 522.324f;
   var11[2 * 3].v0 = -3160.1f;
   var11[2 * 3].v1 = -19.7345f;
   var11[2 * 3].v2 = 604.116f;
   var11[3 * 3].v0 = -3251.78f;
   var11[3 * 3].v1 = -19.7346f;
   var11[3 * 3].v2 = 562.576f;
   var11[4 * 3].v0 = -3292.82f;
   var11[4 * 3].v1 = -30.9526f;
   var11[4 * 3].v2 = 562.068f;
   var11[5 * 3].v0 = -2543.78f;
   var11[5 * 3].v1 = -7.82715f;
   var11[5 * 3].v2 = 515.579f;
   var11[6 * 3].v0 = -2811.18f;
   var11[6 * 3].v1 = -4.94157f;
   var11[6 * 3].v2 = 390.25f;
   var11[7 * 3].v0 = -2808.39f;
   var11[7 * 3].v1 = -13.5171f;
   var11[7 * 3].v2 = 689.527f;
   var36 = 8;
   var36[0 * 3].v0 = (float)0;
   var36[0 * 3].v1 = (float)0;
   var36[0 * 3].v2 = (float)0;
   var36[1 * 3].v0 = (float)0;
   var36[1 * 3].v1 = (float)0;
   var36[1 * 3].v2 = (float)0;
   var36[2 * 3].v0 = (float)0;
   var36[2 * 3].v1 = (float)0;
   var36[2 * 3].v2 = (float)0;
   var36[3 * 3].v0 = -3250.14f;
   var36[3 * 3].v1 = -19.7345f;
   var36[3 * 3].v2 = 615.421f;
   var36[4 * 3].v0 = -3291.48f;
   var36[4 * 3].v1 = -30.9693f;
   var36[4 * 3].v2 = 585.483f;
   var36[5 * 3].v0 = (float)0;
   var36[5 * 3].v1 = (float)0;
   var36[5 * 3].v2 = (float)0;
   var36[6 * 3].v0 = (float)0;
   var36[6 * 3].v1 = (float)0;
   var36[6 * 3].v2 = (float)0;
   var36[7 * 3].v0 = (float)0;
   var36[7 * 3].v1 = (float)0;
   var36[7 * 3].v2 = (float)0;
   var61 = 16;
   var61[0 * 3].v0 = -2464.99f;
   var61[0 * 3].v1 = -9.73267f;
   var61[0 * 3].v2 = 361.53f;
   var61[1 * 3].v0 = -2459.99f;
   var61[1 * 3].v1 = -9.73267f;
   var61[1 * 3].v2 = 361.572f;
   var61[2 * 3].v0 = -2469.49f;
   var61[2 * 3].v1 = -9.73267f;
   var61[2 * 3].v2 = 361.492f;
   var61[3 * 3].v0 = -2455.49f;
   var61[3 * 3].v1 = -9.73267f;
   var61[3 * 3].v2 = 361.609f;
   var61[4 * 3].v0 = -2459.92f;
   var61[4 * 3].v1 = -9.73267f;
   var61[4 * 3].v2 = 353.072f;
   var61[5 * 3].v0 = -2469.42f;
   var61[5 * 3].v1 = -9.73267f;
   var61[5 * 3].v2 = 352.992f;
   var61[6 * 3].v0 = -2455.42f;
   var61[6 * 3].v1 = -9.73267f;
   var61[6 * 3].v2 = 353.11f;
   var61[7 * 3].v0 = -2464.92f;
   var61[7 * 3].v1 = -9.73267f;
   var61[7 * 3].v2 = 353.03f;
   var61[8 * 3].v0 = -2459.85f;
   var61[8 * 3].v1 = -9.73267f;
   var61[8 * 3].v2 = 344.572f;
   var61[9 * 3].v0 = -2469.35f;
   var61[9 * 3].v1 = -9.73267f;
   var61[9 * 3].v2 = 344.492f;
   var61[10 * 3].v0 = -2464.85f;
   var61[10 * 3].v1 = -9.73267f;
   var61[10 * 3].v2 = 344.53f;
   var61[11 * 3].v0 = -2455.35f;
   var61[11 * 3].v1 = -9.73267f;
   var61[11 * 3].v2 = 344.61f;
   var61[12 * 3].v0 = -2459.78f;
   var61[12 * 3].v1 = -9.73267f;
   var61[12 * 3].v2 = 336.073f;
   var61[13 * 3].v0 = -2469.28f;
   var61[13 * 3].v1 = -9.73267f;
   var61[13 * 3].v2 = 335.993f;
   var61[14 * 3].v0 = -2455.28f;
   var61[14 * 3].v1 = -9.73267f;
   var61[14 * 3].v2 = 336.11f;
   var61[15 * 3].v0 = -2464.78f;
   var61[15 * 3].v1 = -9.73267f;
   var61[15 * 3].v2 = 336.031f;
   var110 = 16;
   var110[0] = 179.518f;
   var110[1] = 179.518f;
   var110[2] = 179.518f;
   var110[3] = 179.518f;
   var110[4] = 179.518f;
   var110[5] = 179.518f;
   var110[6] = 179.518f;
   var110[7] = 179.518f;
   var110[8] = 179.518f;
   var110[9] = 179.518f;
   var110[10] = 179.518f;
   var110[11] = 179.518f;
   var110[12] = 179.518f;
   var110[13] = 179.518f;
   var110[14] = 179.518f;
   var110[15] = 179.518f;
   var127 = 16;
   var127[0 * 3].v0 = -2460.33f;
   var127[0 * 3].v1 = -7.13206f;
   var127[0 * 3].v2 = 712.773f;
   var127[1 * 3].v0 = -2465.33f;
   var127[1 * 3].v1 = -7.13206f;
   var127[1 * 3].v2 = 712.773f;
   var127[2 * 3].v0 = -2455.83f;
   var127[2 * 3].v1 = -7.13206f;
   var127[2 * 3].v2 = 712.773f;
   var127[3 * 3].v0 = -2469.83f;
   var127[3 * 3].v1 = -7.13206f;
   var127[3 * 3].v2 = 712.773f;
   var127[4 * 3].v0 = -2465.33f;
   var127[4 * 3].v1 = -7.13206f;
   var127[4 * 3].v2 = 721.273f;
   var127[5 * 3].v0 = -2455.83f;
   var127[5 * 3].v1 = -7.13206f;
   var127[5 * 3].v2 = 721.273f;
   var127[6 * 3].v0 = -2469.83f;
   var127[6 * 3].v1 = -7.13206f;
   var127[6 * 3].v2 = 721.273f;
   var127[7 * 3].v0 = -2460.33f;
   var127[7 * 3].v1 = -7.13206f;
   var127[7 * 3].v2 = 721.273f;
   var127[8 * 3].v0 = -2465.33f;
   var127[8 * 3].v1 = -7.13206f;
   var127[8 * 3].v2 = 729.773f;
   var127[9 * 3].v0 = -2455.83f;
   var127[9 * 3].v1 = -7.13206f;
   var127[9 * 3].v2 = 729.773f;
   var127[10 * 3].v0 = -2460.33f;
   var127[10 * 3].v1 = -7.13206f;
   var127[10 * 3].v2 = 729.773f;
   var127[11 * 3].v0 = -2469.83f;
   var127[11 * 3].v1 = -7.13206f;
   var127[11 * 3].v2 = 729.773f;
   var127[12 * 3].v0 = -2465.33f;
   var127[12 * 3].v1 = -7.13206f;
   var127[12 * 3].v2 = 738.273f;
   var127[13 * 3].v0 = -2455.83f;
   var127[13 * 3].v1 = -7.13206f;
   var127[13 * 3].v2 = 738.273f;
   var127[14 * 3].v0 = -2469.83f;
   var127[14 * 3].v1 = -7.13206f;
   var127[14 * 3].v2 = 738.273f;
   var127[15 * 3].v0 = -2460.33f;
   var127[15 * 3].v1 = -7.13206f;
   var127[15 * 3].v2 = 738.273f;
   var176 = 16;
   var176[0] = (float)0;
   var176[1] = (float)0;
   var176[2] = (float)0;
   var176[3] = (float)0;
   var176[4] = (float)0;
   var176[5] = (float)0;
   var176[6] = (float)0;
   var176[7] = (float)0;
   var176[8] = (float)0;
   var176[9] = (float)0;
   var176[10] = (float)0;
   var176[11] = (float)0;
   var176[12] = (float)0;
   var176[13] = (float)0;
   var176[14] = (float)0;
   var176[15] = (float)0;
   var193 = 6;
   var193[0 * 3].v0 = -3439.63f;
   var193[0 * 3].v1 = -24.6385f;
   var193[0 * 3].v2 = 561.705f;
   var193[1 * 3].v0 = -2462.49f;
   var193[1 * 3].v1 = -9.76431f;
   var193[1 * 3].v2 = 357.156f;
   var193[2 * 3].v0 = -2462.81f;
   var193[2 * 3].v1 = -7.27387f;
   var193[2 * 3].v2 = 717.131f;
   var193[3 * 3].v0 = -3304.33f;
   var193[3 * 3].v1 = -31.482f;
   var193[3 * 3].v2 = 562.174f;
   var193[4 * 3].v0 = -3252.14f;
   var193[4 * 3].v1 = -19.7348f;
   var193[4 * 3].v2 = 562.421f;
   var193[5 * 3].v0 = -3030.58f;
   var193[5 * 3].v1 = -19.7348f;
   var193[5 * 3].v2 = 561.602f;
   var212 = 6;
   var212[0] = "PickUp";
   var212[1] = "DropOff";
   var212[2] = "DropOff";
   var212[3] = "PickUp";
   var212[4] = "PickUp";
   var212[5] = "PickUp";
   var219 = 6;
   var219[0] = 0;
   var219[1] = 2;
   var219[2] = 1;
   var219[3] = 0;
   var219[4] = 0;
   var219[5] = 0;
   var226 = 0;
   var227 = Ctf_GetMap(L[0].v801);
   CtfMap_Init(var227, 4, 2);
   var226 = 0;
   while (var226 < 6)
   {
       CtfMap_AddItem(var227, var212[var226], &(var193[var226 * 3]), var219[var226]);
       var226 = var226 + 1;
   }
   var228 = 0;
   var229 = Race_GetRaceGrid(L[0].v3, 0);
   var230 = Race_GetRaceGrid(L[0].v3, 1);
   var228 = 0;
   while (var228 < 16)
   {
       RaceGrid_SetPosition(var229, var228, &(var61[var228 * 3]), var110[var228]);
       RaceGrid_SetPosition(var230, var228, &(var127[var228 * 3]), var176[var228]);
       var228 = var228 + 1;
   }
   L[0].v2 = PickUpManager_CreatePowerUpSources(8);
   var226 = 0;
   while (var226 < 8)
   {
       PickUpManager_AddPowerUpSource(L[0].v2, &(var11[var226 * 3]), var2[var226], &(var36[var226 * 3]));
       var226 = var226 + 1;
   }
   sub_931(&L[0]);
}

void sub_931(var0)
{
   auto var3, var4, var5, var6, var7, var8, var9, var10, var11, var12, var13, var14, var15, var16;

   var8.v0 = (float)0;
   var8.v1 = (float)1;
   var8.v2 = (float)0;
   var11.v0 = (float)0;
   var11.v1 = (float)0;
   var11.v2 = (float)-1;
   RaceGrid_GetPosition(Race_GetRaceGrid(*(var0 + 12), 0), 0, &var4, &var7);
   Math_VecRotateY(&var11, &var11, var7);
   var11.v0 = var4.v0 + var11.v0;
   var11.v1 = var4.v1 + var11.v1;
   var11.v2 = var4.v2 + var11.v2;
   var8.v0 = var4.v0 + var8.v0;
   var8.v1 = var4.v1 + var8.v1;
   var8.v2 = var4.v2 + var8.v2;
   UILogic_LockStreaming(&var4, &var8, &var11);
   var3 = 0;
   while (var3 < *((var0 + 16) + 3080))
   {
       Racer_SetStreamingLockedIn((*((var0 + 16) + 4))[var3 * 48].v0);
       var3 = var3 + 1;
   }
   var14 = 1;
   while (var14 > 0)
   {
       var14 = *((var0 + 16) + 3080);
       var3 = 0;
       while (var3 < *((var0 + 16) + 3080))
       {
           if (Racer_IsSimStreamed((*((var0 + 16) + 4))[var3 * 48].v0))
           {
               var14 = var14 - 1;
           }
           var3 = var3 + 1;
       }
       if (var14 > 0)
       {
           if (!*((var0 + 16) + 3132))
           {
               sub_a48(1, 0, 0x3f800000, 0);
           }
           WAIT(100);
       }
   }
   while (OpponentManager_StillStreamingOut())
   {
       WAIT(30);
   }
   var3 = 0;
   while (var3 < *((var0 + 16) + 3080))
   {
       if ((*((var0 + 16) + 4))[var3 * 48].v2 == 2)
       {
           PRINTSTRING(" BRAIN CREATED!");
           (*((var0 + 16) + 4))[var3 * 48].v3 = BrainFactory_CreateBrainRacing((*((var0 + 16) + 4))[var3 * 48].v0);
       }
       var3 = var3 + 1;
   }
   var15 = START_NEW_SCRIPT_WITH_ARGS("game/racetypes/BaseWarCore", var0, 802, 1500);
   while (!IsChildFinished(var15))
   {
       WAIT(30);
   }
   var3 = 0;
   while (var3 < *((var0 + 16) + 3080))
   {
       if ((*((var0 + 16) + 4))[var3 * 48].v2 == 2)
       {
           BrainFactory_DeleteBrain((*((var0 + 16) + 4))[var3 * 48].v0);
       }
       var3 = var3 + 1;
   }
}

void sub_a48(var0, var1, var2, var3)
{
   auto var6, var7, var8, var9, var10, var11, var12, var13;

   var6 = null;
   while (var6 == null)
   {
       var6 = UIManager_FindMovie("TRANSITIONMOVIE");
       if (var6 == null)
       {
           PRINTSTRING("SCRIPT: waiting for transition movie to stream in...\n");
           WAITUNWARPED(10);
       }
   }
   var7 = 0;
   var8 = 0;
   var9 = 0;
   FlashHelper_GetGlobalInt(var6, "StartOfTransitionout", &var7);
   FlashHelper_GetGlobalInt(var6, "StartOfTransitionin", &var8);
   FlashHelper_GetGlobalInt(var6, "TransitionOutisReady", &var9);
   PRINTSTRING("FADE DOWN REPORT\n");
   PRINTSTRING("================\n");
   PRINTSTRING("TransitionOut: ");
   PRINTINT(var7);
   PRINTSTRING("\nTransitionIn: ");
   PRINTINT(var8);
   PRINTSTRING("\nnTransitionReady: ");
   PRINTINT(var9);
   PRINTSTRING("\n");
   if ((var8 == 0) && ((var9 == 0) || ((var7 == 1) && (var9 == 2))))
   {
       FlashHelper_SetMovieEnabled(var6, 1);
       FlashHelper_SetGlobalInt(var6, "cur_visibility", 1);
       FlashHelper_SetGlobalInt(var6, "mask_color", var3);
       if (var1)
       {
           FlashHelper_SetGlobalInt(var6, "transition_type", 0);
       }
       else
       {
           FlashHelper_SetGlobalInt(var6, "transition_type", 1);
       }
       FlashHelper_SetGlobalFloat(var6, "fade_speed_in", var2);
       FlashHelper_SetGlobalFloat(var6, "fade_speed_out", 0.01f);
       FlashHelper_SetGlobalInt(var6, "StartOfTransitionout", 0);
       FlashHelper_SetGlobalInt(var6, "TransitionOutisReady", 0);
       FlashHelper_SetGlobalInt(var6, "StartOfTransitionin", 1);
       if (var0)
       {
           var8 = 1;
           while (var8 == 1)
           {
               FlashHelper_GetGlobalInt(var6, "StartOfTransitionin", &var8);
               if (var8 == 1)
               {
                   WAITUNWARPED(10);
               }
           }
       }
   }
}

