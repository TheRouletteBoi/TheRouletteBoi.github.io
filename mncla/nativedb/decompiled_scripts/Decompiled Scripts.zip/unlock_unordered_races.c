void main()
{
   mcCareer_UnlockDistrictRaces(6, 4, -1);
}


