﻿void main()
{
   auto var2, var3, var4, var5, var6, var7, var8, var9, var10, var11;

   START_NEW_SCRIPT_WITH_ARGS("game/Garages/Garage1Setup", &var2, 1, 0);
   START_NEW_SCRIPT_WITH_ARGS("game/Garages/RateMyRide1Setup", &var2, 1, 0);
   START_NEW_SCRIPT_WITH_ARGS("Game/Hangouts/Hangout1Setup", &var2, 1, 0);
   sub_84();
   START_NEW_SCRIPT_WITH_ARGS("Game/CruisingHookmen/MissionHookman1", &var3, 9, 0);
   START_NEW_SCRIPT_WITH_ARGS("Game/CruisingHookmen/LocalRaceHookman1", &var3, 9, 0);
   START_NEW_SCRIPT_WITH_ARGS("Game/CruisingHookmen/LocalRaceHookman2", &var3, 9, 0);
}

void sub_84()
{
   auto var2, var3, var4, var5, var6, var7, var8, var9, var10, var11, var12, var13, var14, var15, var16, var17, var18, var19, var20, var21, var22, var23, var24, var25, var26, var27, var28, var29, var30, var31, var32, var33, var34;

   var2 = 3;
   var6 = 3;
   var16 = 3;
   var20 = 3;
   var2[0] = "vp_chv_police_96";
   var6[0 * 3].v0 = 2030.1f;
   var6[0 * 3].v1 = 6.8f;
   var6[0 * 3].v2 = -813.7f;
   var16[0] = (float)90;
   var20[0 * 3].v0 = -510.0f;
   var20[0 * 3].v1 = 9.5f;
   var20[0 * 3].v2 = -400.0f;
   var2[1] = "vp_chv_police_96";
   var6[1 * 3].v0 = -646.8f;
   var6[1 * 3].v1 = 18.5f;
   var6[1 * 3].v2 = -643.8f;
   var16[1] = (float)90;
   var20[1 * 3].v0 = -500.0f;
   var20[1 * 3].v1 = 9.5f;
   var20[1 * 3].v2 = -400.0f;
   var2[2] = "vp_chv_police_96";
   var6[2 * 3].v0 = -2434.4f;
   var6[2 * 3].v1 = 1.9f;
   var6[2 * 3].v2 = -577.9f;
   var16[2] = 84.9f;
   var20[2 * 3].v0 = -490.0f;
   var20[2 * 3].v1 = 9.5f;
   var20[2 * 3].v2 = -400.0f;
   var30 = 3;
   var34 = 0;
   while (var34 < 3)
   {
       var30[var34] = PoliceManager_CreatePolice(var2[var34], 1, &(var6[var34 * 3]), var16[var34], &(var20[var34 * 3]), 400 + var34);
       var34 = var34 + 1;
   }
}

